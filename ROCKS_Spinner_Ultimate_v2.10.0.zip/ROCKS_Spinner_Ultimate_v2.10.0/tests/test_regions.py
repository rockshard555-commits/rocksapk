"""Smoke checks for ROCKS' bundled region registry and spin metadata."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REGIONS = [
    ("IND", "India", "🇮🇳"), ("BD", "Bangladesh", "🇧🇩"),
    ("PK", "Pakistan", "🇵🇰"), ("ME", "Middle East", "🌍"),
    ("BR", "Brazil", "🇧🇷"), ("US", "United States", "🇺🇸"),
    ("ID", "Indonesia", "🇮🇩"), ("SG", "Singapore", "🇸🇬"),
    ("TH", "Thailand", "🇹🇭"), ("VN", "Vietnam", "🇻🇳"),
    ("TW", "Taiwan", "🇹🇼"), ("CIS", "CIS Countries", "🌐"),
    ("EU", "Europe", "🇪🇺"), ("SAC", "South America", "🌎"),
    ("NA", "North America", "🌎"), ("RU", "Russia", "🇷🇺"),
]


def _setup_test_db(tmp_path, monkeypatch, rocks):
    users_dir = tmp_path / "users"
    avatars_dir = tmp_path / "avatars"
    users_dir.mkdir(exist_ok=True)
    avatars_dir.mkdir(exist_ok=True)
    monkeypatch.setattr(rocks, "DB_PATH", tmp_path / "rocks.sqlite3")
    monkeypatch.setattr(rocks, "DATA_DIR", tmp_path)
    monkeypatch.setattr(rocks, "USERS_DIR", users_dir)
    monkeypatch.setattr(rocks, "AVATARS_DIR", avatars_dir)
    rocks.init_db()


def test_bundled_region_registry_is_exact_and_unique():
    data = json.loads((ROOT / "backend/data/rocks_catalogue.json").read_text(encoding="utf-8"))
    actual = [(r["code"], r["name"], r["flag"]) for r in data["regions"]]
    assert actual == REGIONS
    assert len({r["code"] for r in data["regions"]}) == 16
    assert all(r.get("endpoint_url", "").startswith("https://") for r in data["regions"])
    assert all(r.get("endpoint_live_verified") is False for r in data["regions"])
    expected_urls = {
        "IND": "https://client.ind.freefiremobile.com/PurchaseGacha",
        "US": "https://client.us.freefiremobile.com/PurchaseGacha",
        "NA": "https://client.us.freefiremobile.com/PurchaseGacha",
        "SAC": "https://client.us.freefiremobile.com/PurchaseGacha",
        "BR": "https://client.us.freefiremobile.com/PurchaseGacha",
        "TH": "https://clientbp.ggpolarbear.com/PurchaseGacha",
        "ME": "https://clientbp.ggpolarbear.com/PurchaseGacha",
        "EU": "https://clientbp.ggpolarbear.com/PurchaseGacha",
        "VN": "https://clientbp.ggpolarbear.com/PurchaseGacha",
        "BD": "https://clientbp.ggpolarbear.com/PurchaseGacha",
        "TW": "https://clientbp.ggpolarbear.com/PurchaseGacha",
        "RU": "https://clientbp.ggpolarbear.com/PurchaseGacha",
        "SG": "https://clientbp.ggpolarbear.com/PurchaseGacha",
        "PK": "https://clientbp.ggpolarbear.com/PurchaseGacha",
        "ID": "https://clientbp.ggpolarbear.com/PurchaseGacha",
        "CIS": "https://clientbp.ggpolarbear.com/PurchaseGacha",
    }
    assert {r["code"]: r["endpoint_url"] for r in data["regions"]} == expected_urls


def test_catalogue_categories_are_present_and_gold_has_user_provided_rewards():
    data = json.loads((ROOT / "backend/data/rocks_catalogue.json").read_text(encoding="utf-8"))
    event_keys = {event["key"] for event in data["events"]}
    item_categories = {item["category"] for item in data["items"]}
    assert {"m4a1", "emote_royale", "gold_royale", "ghost", "evo", "thailand_free", "vietnam_free", "cobra"} <= event_keys
    assert {"m4a1", "emote_royale", "gold_royale", "ghost", "evo", "thailand_free", "vietnam_free", "cobra"} <= item_categories
    gold = next(event for event in data["events"] if event["key"] == "gold_royale")
    assert gold["catalog_complete"] is True
    assert gold["missing_catalog_fields"] == []
    assert gold["mode"] == "FREE (0 Gold)"
    assert set(gold["reward_item_ids"]) == {"710054027", "907102829"}
    assert {x["item_id"] for x in data["items"] if x["category"] == "gold_royale"} == {"710054027", "907102829"}
    assert not any(item["item_id"] in {"gold-royale-demo", "830000002"} for item in data["items"])


def test_event_region_coverage_matches_user_supplied_configuration():
    data = json.loads((ROOT / "backend/data/rocks_catalogue.json").read_text(encoding="utf-8"))
    by_key = {e["key"]: e for e in data["events"]}
    assert by_key["m4a1"]["supported_regions"] == ["IND", "BD", "PK", "ID", "TH", "VN", "SG", "ME", "EU", "RU", "NA", "SAC"]
    assert by_key["emote_royale"]["supported_regions"] == ["BD", "SG", "EU", "RU", "NA"]
    assert by_key["gold_royale"]["supported_regions"] == ["IND", "BD", "PK", "ID", "TH", "VN", "SG", "ME", "EU", "RU", "NA", "SAC"]
    assert by_key["thailand_free"]["supported_regions"] == ["TH"]
    assert by_key["vietnam_free"]["supported_regions"] == ["VN"]
    assert by_key["evo"]["supported_regions"] == ["ME"]
    assert by_key["ghost"]["supported_regions"] == ["TW"]
    assert by_key["cobra"]["name"] == "Token Tower"
    assert by_key["cobra"]["title"] == "Cobra Rage Bundle"
    assert by_key["cobra"]["event_number"] == 10
    assert by_key["cobra"]["mode"] == "FREE (0 Diamonds)"
    assert by_key["cobra"]["status"] == "USER-PROVIDED METADATA · LIVE UNVERIFIED"
    assert by_key["cobra"]["supported_regions"] == ["TW"]
    assert by_key["cobra"]["supported_region_names"] == ["Taiwan"]
    assert by_key["cobra"]["payload_hex_reference"] == "0822100118ff2a200160006802"
    assert by_key["cobra"]["payloads_by_region"] == {"TW": "0822100118ff2a200160006802"}
    assert by_key["cobra"]["payload_execution_enabled"] is False
    assert [x["item_id"] for x in data["items"] if x["category"] == "cobra"] == ["710026009"]
    assert by_key["thailand_free"]["event_name_by_region"] == {"TH": "Ballsy Skaterboi Royale"}
    assert by_key["vietnam_free"]["event_name_by_region"] == {"VN": "Infernosaur Royale"}


def test_cobra_metadata_is_taiwan_only_and_non_executable():
    data = json.loads((ROOT / "backend/data/rocks_catalogue.json").read_text(encoding="utf-8"))
    event = next(e for e in data["events"] if e["key"] == "cobra")
    assert event["supported_regions"] == ["TW"]
    assert event["payload_execution_enabled"] is False
    assert event["payload_hex_reference"] == "0822100118ff2a200160006802"


def test_live_spin_api_is_disabled_until_authorized_connector_exists(tmp_path, monkeypatch):
    import sys
    from datetime import timedelta
    from fastapi.testclient import TestClient
    sys.path.insert(0, str(ROOT))
    from backend import app as rocks
    _setup_test_db(tmp_path, monkeypatch, rocks)
    user = rocks.find_or_create_user(821400, "liveonly", "Live Only")
    token = "regions-live-only-session"
    expiry = (rocks.utcnow() + timedelta(days=1)).isoformat(timespec="seconds")
    with rocks.connect() as con:
        con.execute("INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)",
                    (rocks.hash_value(token), user["id"], expiry, rocks.iso_now()))
    with TestClient(rocks.app) as client:
        headers = {"Authorization": f"Bearer {token}"}
        status = client.get("/api/live/status", headers=headers)
        assert status.status_code == 200
        assert status.json()["status"] == "NOT CONNECTED"
        assert status.json()["live_actions_enabled"] is False
        response = client.post("/api/spins", headers=headers, json={
            "account_id": 1, "event_key": "emote_royale", "region_code": "IND", "count": 1
        })
        assert response.status_code == 503
        assert "No request was sent" in response.json()["detail"]
        for route, body in (
            ("/api/tools/evo/spin", {"account_id": 1, "region_code": "ME", "count": 1}),
            ("/api/tools/ghost/spin", {"account_id": 1, "region_code": "TW", "count": 1}),
        ):
            module_response = client.post(route, headers=headers, json=body)
            assert module_response.status_code == 503
            assert "no result was created" in module_response.json()["detail"].lower()
        with rocks.connect() as con:
            assert con.execute("SELECT COUNT(*) FROM spins").fetchone()[0] == 0


def test_regional_payload_references_match_configured_regions_and_are_non_executable():
    data = json.loads((ROOT / "backend/data/rocks_catalogue.json").read_text(encoding="utf-8"))
    for event in data["events"]:
        assert event.get("payload_execution_enabled") is False
        supported = set(event.get("supported_regions", []))
        payload_regions = set(event.get("payloads_by_region", {}))
        assert payload_regions <= supported, (event["key"], payload_regions, supported)
        for region, payload in event.get("payloads_by_region", {}).items():
            assert payload and re.fullmatch(r"[0-9A-Fa-f]+", payload), (event["key"], region, payload)
    by_key = {e["key"]: e for e in data["events"]}
    assert by_key["gold_royale"]["payloads_by_region"]["IND"] == "0806100118b104200160e8076801"
    assert by_key["gold_royale"]["payloads_by_region"]["TH"] == "0804100118fd2a200160e8076801"
    assert by_key["thailand_free"]["payloads_by_region"] == {"TH":"083e100118ff2a200160006802"}
    assert by_key["vietnam_free"]["payloads_by_region"] == {"VN":"083d100118842b200160006802"}


def test_supplied_payload_values_are_preserved_without_execution():
    data = json.loads((ROOT / "backend/data/rocks_catalogue.json").read_text(encoding="utf-8"))
    by_key = {event["key"]: event for event in data["events"]}
    assert by_key["m4a1"]["payloads_by_region"]["TH"] == "085d100118e803200160006802"
    assert by_key["m4a1"]["payloads_by_region"]["RU"] == "085d100118d703200160006802"
    assert "CIS" not in by_key["m4a1"]["payloads_by_region"]
    assert by_key["emote_royale"]["payloads_by_region"] == {
        "BD": "080b100118ab04200160006802", "SG": "080b100118ab04200160006802",
        "EU": "080b100118ab04200160006802", "RU": "080b100118ab04200160006802",
        "NA": "080b100118ab04200160006802",
    }
    assert by_key["gold_royale"]["payloads_by_region"] == {
        "IND": "0806100118b104200160e8076801", "BD": "0806100118a904200160e8076801",
        "PK": "0806100118a904200160e8076801", "ID": "0806100118a704200160e8076801",
        "TH": "0804100118fd2a200160e8076801", "VN": "0806100118822b200160e8076801",
        "SG": "0806100118a904200160e8076801", "ME": "0806100118a704200160e8076801",
        "EU": "0806100118a904200160e8076801", "RU": "0806100118a904200160e8076801",
        "NA": "0806100118a904200160e8076801", "SAC": "0806100118a704200160e8076801",
    }
    assert by_key["thailand_free"]["payloads_by_region"] == {"TH": "083e100118ff2a200160006802"}
    assert by_key["vietnam_free"]["payloads_by_region"] == {"VN": "083d100118842b200160006802"}
    assert all(event.get("payload_execution_enabled") is False for event in data["events"])


def test_original_gen_script_is_preserved_and_excluded_file_stays_excluded():
    import hashlib
    supplied = ROOT / "supplied_inputs"
    source = supplied / "Gen.py"
    assert hashlib.sha256(source.read_bytes()).hexdigest() == "e6d65c0bae778ffa27afd69b0c3a03ec8038367eaa0223470f0cd22c6e8b0b69"
    assert (supplied / "Evo_Spin.zip").is_file()
    assert (supplied / "Ghost_Spin.zip").is_file()
    assert (supplied / "FF Ultimate Spinner_3.6.2.apk").is_file() is False
    assert (supplied / "Reference_only_FF_Ultimate_Spinner_3.6.2.apk").is_file()
    assert not (supplied / "Cobra.txt").exists()


def test_item_image_metadata_uses_requested_sources_and_id_matched_gold_images():
    data = json.loads((ROOT / "backend/data/rocks_catalogue.json").read_text(encoding="utf-8"))
    for item in data["items"]:
        assert item["ff_item_library_url"] == "https://ff-item.netlify.app/"
        assert item["freefiremania_search_url"] == "https://www.freefiremania.com.br/free-fire-items.html"
        assert item["image_lookup_id"] == str(item["item_id"])
        if item["image_url"]:
            assert item["image_url"].startswith("https://www.freefiremania.com.br/images/itens/")
    cobra = next(item for item in data["items"] if item["item_id"] == "710026009")
    assert cobra["image_url"].endswith("Icon_bundle_male_Cobra_Red_26.png")
    mag7 = next(item for item in data["items"] if item["item_id"] == "907103324")
    assert mag7["image_url"] is None
    assert mag7["freefiremania_item_url"].endswith("mag-7-villano-de-las-sombras.html")
    male_uniform = next(item for item in data["items"] if item["item_id"] == "710000021")
    female_uniform = next(item for item in data["items"] if item["item_id"] == "710000022")
    assert male_uniform["image_url"].endswith("Icon_Male_JKPackage.png")
    assert female_uniform["image_url"].endswith("Icon_Female_JKPackage.png")
    assert male_uniform["freefiremania_item_url"].endswith("english-uniform-bundle-male-710000021.html")
    assert female_uniform["freefiremania_item_url"].endswith("conjunto-britanico-feminino-710000022.html")
    assert next(item for item in data["items"] if item["item_id"] == "205055021")["image_url"] is None
    electro = next(item for item in data["items"] if item["item_id"] == "710054027")
    thompson = next(item for item in data["items"] if item["item_id"] == "907102829")
    assert electro["image_url"].endswith("Icon_bundle_female_Metamorphosis_54.png")
    assert electro["freefiremania_item_url"].endswith("electro-butterfly-bundle.html")
    assert electro["source_rarity"] == "Epic++" and electro["rarity"] == "ultra_rare"
    assert thompson["image_url"].endswith("Icon_Thompson_Fireskull.png")
    assert thompson["freefiremania_item_url"].endswith("thompson-freezing-flame.html")
    assert thompson["source_rarity"] == "Epic" and thompson["rarity"] == "ultra_rare"


def test_gold_royale_catalogue_contains_user_provided_rewards_not_fake_draws():
    data = json.loads((ROOT / "backend/data/rocks_catalogue.json").read_text(encoding="utf-8"))
    gold = {x["item_id"] for x in data["items"] if x["category"] == "gold_royale"}
    assert gold == {"710054027", "907102829"}
    assert not any("demo" in str(x.get("item_id", "")).lower() for x in data["items"])


def test_api_catalog_returns_item_image_and_both_lookup_sources(tmp_path, monkeypatch):
    import sys
    sys.path.insert(0, str(ROOT))
    from backend import app as rocks
    _setup_test_db(tmp_path, monkeypatch, rocks)
    user = rocks.find_or_create_user(821501, "imageaudit", "Image Audit")
    rows = rocks.get_catalog(user=user)["items"]
    cobra = next(row for row in rows if row["item_id"] == "710026009")
    assert cobra["image_url"].endswith("Icon_bundle_male_Cobra_Red_26.png")
    assert cobra["ff_item_library_url"] == "https://ff-item.netlify.app/"
    assert cobra["freefiremania_item_url"].endswith("conjunto-cobra-modo-furia.html")
    mag7 = next(row for row in rows if row["item_id"] == "907103324")
    assert mag7["image_url"] is None
    assert mag7["freefiremania_item_url"].endswith("mag-7-villano-de-las-sombras.html")
    gold_items = {row["item_id"]: row for row in rows if row["category"] == "gold_royale"}
    assert gold_items["710054027"]["image_url"].endswith("Icon_bundle_female_Metamorphosis_54.png")
    assert gold_items["907102829"]["image_url"].endswith("Icon_Thompson_Fireskull.png")


def test_database_upgrade_removes_old_fake_gold_and_excluded_cobra_entry(tmp_path, monkeypatch):
    import sys
    sys.path.insert(0, str(ROOT))
    from backend import app as rocks
    _setup_test_db(tmp_path, monkeypatch, rocks)
    with rocks.connect() as con:
        con.execute("INSERT OR IGNORE INTO catalog(category,item_id,name,rarity,enabled,created_at) VALUES(?,?,?,?,1,?)",
                    ("gold_royale", "gold-royale-demo", "Gold Royale Reward Placeholder", "demo", rocks.iso_now()))
        con.execute("INSERT OR IGNORE INTO catalog(category,item_id,name,rarity,enabled,created_at) VALUES(?,?,?,?,1,?)",
                    ("cobra", "830000002", "Unrelated entry", "rare", rocks.iso_now()))
    rocks.init_db()
    with rocks.connect() as con:
        assert con.execute("SELECT 1 FROM catalog WHERE category='gold_royale' AND item_id='gold-royale-demo'").fetchone() is None
        assert con.execute("SELECT 1 FROM catalog WHERE category='cobra' AND item_id='830000002'").fetchone() is None
        assert con.execute("SELECT 1 FROM catalog WHERE category='cobra' AND item_id='710026009'").fetchone() is not None


def test_cobra_api_shows_free_status_and_taiwan_payload_only(tmp_path, monkeypatch):
    import sys
    sys.path.insert(0, str(ROOT))
    from backend import app as rocks
    _setup_test_db(tmp_path, monkeypatch, rocks)
    user = rocks.find_or_create_user(821502, "cobra", "Cobra User")
    events = rocks.get_events(user=user)["events"]
    cobra = next(event for event in events if event["key"] == "cobra")
    assert cobra["name"] == "Token Tower"
    assert cobra["event_number"] == 10
    assert cobra["mode"] == "FREE (0 Diamonds)"
    assert cobra["status"] == "USER-PROVIDED METADATA · LIVE UNVERIFIED"
    assert cobra["payloads_by_region"] == {"TW": "0822100118ff2a200160006802"}
    assert cobra["payload_execution_enabled"] is False


def test_ui_uses_id_based_item_art_and_neutral_lookup_links():
    js = (ROOT / "backend/static/app.js").read_text(encoding="utf-8")
    app = (ROOT / "backend/app.py").read_text(encoding="utf-8")
    assert "https://www.freefiremania.com.br/images/itens/Icon_bundle_male_Cobra_Red_26.png" in js
    assert "Image Reference" in js and "More References" in js
    assert "Artwork lookup pending" in js
    assert "https://www.freefiremania.com.br;" in app
