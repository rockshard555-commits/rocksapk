"""Operational backup/restore utility tests; no live deployment/database is touched."""
import sqlite3
import os
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from scripts.backup_db import backup_database, verify_database, verify_rocks_schema
from scripts.restore_db import restore_database


def make_db(path: Path, value: str) -> None:
    with sqlite3.connect(path) as con:
        con.execute("CREATE TABLE sample (value TEXT NOT NULL)")
        con.execute("INSERT INTO sample(value) VALUES(?)", (value,))


def make_rocks_db(path: Path, value: str) -> None:
    with sqlite3.connect(path) as con:
        con.executescript("""
        CREATE TABLE sample (value TEXT NOT NULL);
        CREATE TABLE users (id INTEGER PRIMARY KEY, telegram_id INTEGER, username TEXT, first_name TEXT, avatar_path TEXT, status TEXT, created_at TEXT, last_seen_at TEXT);
        CREATE TABLE catalog (id INTEGER PRIMARY KEY, category TEXT, item_id TEXT, name TEXT, rarity TEXT, enabled INTEGER, created_at TEXT);
        CREATE TABLE accounts (id INTEGER PRIMARY KEY, user_id INTEGER, label TEXT, game_uid TEXT, created_at TEXT);
        CREATE TABLE spins (id INTEGER PRIMARY KEY, user_id INTEGER, account_id INTEGER, event_key TEXT, event_name TEXT, item_id TEXT, item_name TEXT, draw_number INTEGER, created_at TEXT);
        """)
        con.execute("INSERT INTO sample(value) VALUES(?)", (value,))


def read_value(path: Path) -> str:
    with sqlite3.connect(path) as con:
        return con.execute("SELECT value FROM sample").fetchone()[0]


def test_backup_is_verified_private_and_does_not_overwrite(tmp_path):
    source = tmp_path / "rocks.sqlite3"
    target = tmp_path / "backups" / "rocks-test.sqlite3"
    make_db(source, "source-state")
    result = backup_database(source, target)
    assert result == target.resolve()
    verify_database(target)
    assert read_value(target) == "source-state"
    if target.stat().st_mode & 0o777:
        assert target.stat().st_mode & 0o077 == 0
    with pytest.raises(FileExistsError):
        backup_database(source, target)


def test_restore_requires_force_and_snapshots_previous_database(tmp_path):
    source = tmp_path / "backup.sqlite3"
    destination = tmp_path / "data" / "rocks.sqlite3"
    make_rocks_db(source, "backup-state")
    destination.parent.mkdir(parents=True)
    make_rocks_db(destination, "current-state")
    with pytest.raises(FileExistsError):
        restore_database(source, destination)
    restored = restore_database(source, destination, force=True)
    assert restored == destination.resolve()
    assert read_value(destination) == "backup-state"
    before_restore = list((destination.parent / "backups").glob("rocks-pre-restore-*.sqlite3"))
    assert len(before_restore) == 1
    assert read_value(before_restore[0]) == "current-state"


def test_user_directory_and_database_permissions_are_private_on_posix(tmp_path, monkeypatch):
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from backend import app as rocks

    users_dir = tmp_path / "users"
    avatars_dir = tmp_path / "avatars"
    users_dir.mkdir()
    avatars_dir.mkdir()
    monkeypatch.setattr(rocks, "DB_PATH", tmp_path / "rocks.sqlite3")
    monkeypatch.setattr(rocks, "DATA_DIR", tmp_path)
    monkeypatch.setattr(rocks, "USERS_DIR", users_dir)
    monkeypatch.setattr(rocks, "AVATARS_DIR", avatars_dir)
    rocks.init_db()
    user = rocks.find_or_create_user(823001, "private", "Private")
    rocks.add_account(rocks.AccountBody(label="private profile", game_uid="PRIVATE-UID"), user)
    private_file = users_dir / str(user["id"]) / "accounts.json"
    if os.name == "posix":
        assert tmp_path.stat().st_mode & 0o077 == 0
        assert users_dir.stat().st_mode & 0o077 == 0
        assert (tmp_path / "rocks.sqlite3").stat().st_mode & 0o077 == 0
        assert private_file.stat().st_mode & 0o077 == 0


def test_restore_rejects_unrelated_sqlite_file(tmp_path):
    source = tmp_path / "not-rocks.sqlite3"
    destination = tmp_path / "data" / "rocks.sqlite3"
    make_db(source, "unrelated")
    with pytest.raises(RuntimeError, match="Not a ROCKS database"):
        restore_database(source, destination)
    assert not destination.exists()

def test_rocks_schema_verification_accepts_core_tables(tmp_path):
    source = tmp_path / "rocks.sqlite3"
    make_rocks_db(source, "valid")
    verify_rocks_schema(source)


def test_schema_verification_does_not_create_missing_database(tmp_path):
    missing = tmp_path / "missing.sqlite3"
    with pytest.raises(FileNotFoundError):
        verify_rocks_schema(missing)
    assert not missing.exists()
