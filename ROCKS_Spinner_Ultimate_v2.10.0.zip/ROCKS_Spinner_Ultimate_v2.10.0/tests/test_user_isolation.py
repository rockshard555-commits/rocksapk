"""Regression tests for per-user ROCKS settings, profiles, and demo results."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from backend import app as rocks


def test_users_have_separate_theme_profiles_and_results(tmp_path, monkeypatch):
    db = tmp_path / "rocks.sqlite3"
    users_dir = tmp_path / "users"
    avatars_dir = tmp_path / "avatars"
    tmp_path.mkdir(exist_ok=True)
    users_dir.mkdir()
    avatars_dir.mkdir()
    monkeypatch.setattr(rocks, "DB_PATH", db)
    monkeypatch.setattr(rocks, "DATA_DIR", tmp_path)
    monkeypatch.setattr(rocks, "USERS_DIR", users_dir)
    monkeypatch.setattr(rocks, "AVATARS_DIR", avatars_dir)
    rocks.init_db()

    user_a = rocks.find_or_create_user(701001, "alpha", "Alpha")
    user_b = rocks.find_or_create_user(701002, "bravo", "Bravo")

    # Preferences are scoped by the authenticated user passed by the session dependency.
    rocks.update_preferences(rocks.PreferencesBody(theme="midnight", region_general="TW"), user_a)
    assert rocks.get_preferences(user_a)["theme"] == "midnight"
    assert rocks.get_preferences(user_a)["region_general"] == "TW"
    assert rocks.get_preferences(user_b)["theme"] == "hacker"
    assert rocks.get_preferences(user_b)["region_general"] == "IND"
    rocks.update_preferences(rocks.PreferencesBody(theme="rose", region_general="BR"), user_b)
    assert rocks.get_preferences(user_a)["theme"] == "midnight"
    assert rocks.get_preferences(user_a)["region_general"] == "TW"
    assert rocks.get_preferences(user_b)["theme"] == "rose"
    assert rocks.get_preferences(user_b)["region_general"] == "BR"

    account_a = rocks.add_account(rocks.AccountBody(label="Alpha main", game_uid="111111"), user_a)["account"]
    assert [x["game_uid"] for x in rocks.get_accounts(user_a)["accounts"]] == ["111111"]
    assert rocks.get_accounts(user_b)["accounts"] == []

    # Result isolation is tested using a pre-existing verified-result record;
    # the app no longer fabricates results when the live connector is unavailable.
    with rocks.connect() as con:
        con.execute(
            "INSERT INTO spins(user_id,account_id,event_key,event_name,item_id,item_name,draw_number,region_code,demo,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,0,?)",
            (user_a["id"], account_a["id"], "cobra", "Token Tower", "710026009", "Cobra Rage Bundle", 1, "TW", rocks.iso_now()),
        )
    assert len(rocks.get_results(limit=100, user=user_a)["results"]) == 1
    assert rocks.get_results(limit=100, user=user_b)["results"] == []

    # User B cannot delete User A's profile through the account endpoint logic.
    import pytest
    from fastapi import HTTPException

    # User B cannot delete User A's profile through the account endpoint logic.
    with pytest.raises(HTTPException) as exc2:
        rocks.delete_account(account_a["id"], user_b)
    assert exc2.value.status_code == 404
    assert [x["game_uid"] for x in rocks.get_accounts(user_a)["accounts"]] == ["111111"]


def test_preferences_http_api_uses_the_bearer_session_owner(tmp_path, monkeypatch):
    from datetime import timedelta
    from fastapi.testclient import TestClient

    db = tmp_path / "api-rocks.sqlite3"
    users_dir = tmp_path / "api-users"
    avatars_dir = tmp_path / "api-avatars"
    users_dir.mkdir()
    avatars_dir.mkdir()
    monkeypatch.setattr(rocks, "DB_PATH", db)
    monkeypatch.setattr(rocks, "DATA_DIR", tmp_path)
    monkeypatch.setattr(rocks, "USERS_DIR", users_dir)
    monkeypatch.setattr(rocks, "AVATARS_DIR", avatars_dir)
    rocks.init_db()
    a = rocks.find_or_create_user(701101, "a", "User A")
    b = rocks.find_or_create_user(701102, "b", "User B")
    token_a, token_b = "test-session-for-a", "test-session-for-b"
    expiry = (rocks.utcnow() + timedelta(days=1)).isoformat(timespec="seconds")
    with rocks.connect() as con:
        con.executemany(
            "INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)",
            [
                (rocks.hash_value(token_a), a["id"], expiry, rocks.iso_now()),
                (rocks.hash_value(token_b), b["id"], expiry, rocks.iso_now()),
            ],
        )

    with TestClient(rocks.app) as client:
        assert client.get("/api/preferences").status_code == 401
        auth_a = {"Authorization": f"Bearer {token_a}"}
        auth_b = {"Authorization": f"Bearer {token_b}"}
        assert client.get("/api/preferences", headers=auth_a).json()["theme"] == "hacker"
        changed = client.put(
            "/api/preferences", headers=auth_a,
            json={"theme": "midnight", "region_general": "TW"},
        )
        assert changed.status_code == 200, changed.text
        assert client.get("/api/preferences", headers=auth_a).json()["theme"] == "midnight"
        other = client.get("/api/preferences", headers=auth_b).json()
        assert other["theme"] == "hacker"
        assert other["region_general"] == "IND"
