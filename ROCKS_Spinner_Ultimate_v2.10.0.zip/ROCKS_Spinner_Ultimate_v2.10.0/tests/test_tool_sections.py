"""Regression checks for the independent ROCKS app module sections."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_gen_evo_and_ghost_have_separate_screens_and_clear_navigation():
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    for screen_id in ("tab-gen", "tab-evo", "tab-ghost"):
        assert f'id="{screen_id}"' in html
    assert 'data-tab="gen"' in html  # Gen is a primary destination.
    assert 'data-open-tab="evo"' in html and 'data-open-tab="ghost"' in html  # Specialized modules live under More.
    assert 'class="tabs bottom-nav" id="tabs"' in html
    assert 'data-tab="more"' in html
    assert 'id="genOpenAccounts"' in html
    assert 'id="evoSpinBtn"' in html
    assert 'id="ghostSpinBtn"' in html
    assert 'id="evoCatalog"' in html
    assert 'id="ghostCatalog"' in html


def test_evo_and_ghost_have_fixed_separate_backend_routes():
    app = (ROOT / "backend/app.py").read_text(encoding="utf-8")
    js = (ROOT / "backend/static/app.js").read_text(encoding="utf-8")
    assert '@app.post("/api/tools/evo/spin")' in app
    assert '@app.post("/api/tools/ghost/spin")' in app
    assert '@app.get("/api/live/status")' in app
    assert 'LIVE_CONNECTOR_REQUIRED' in app
    assert "demo-spin" not in app and "demo-spin" not in js
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    assert "Live spin unavailable" in html
    assert "_run_demo_spin" not in app
    # Their categories are hidden from the generic spinner drop-down.
    assert "events.filter(e => !['evo', 'ghost'].includes(e.key))" in js


def test_gen_section_is_explicitly_not_executed_by_the_apk():
    app = (ROOT / "backend/app.py").read_text(encoding="utf-8")
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    assert '"execution_enabled": False' in app
    assert "does not execute the supplied Gen.py script" in html


def test_theme_picker_has_seven_themes_and_rocks_artwork():
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    js = (ROOT / "backend/static/app.js").read_text(encoding="utf-8")
    assert 'id="tab-themes"' in html
    for theme in ("hacker", "midnight", "rose", "crimson", "ocean", "amethyst", "arctic"):
        assert f'data-theme-option="{theme}"' in html
        assert f"{theme}:" in js
    assert html.index('data-theme-option="hacker"') < html.index('data-theme-option="midnight"') < html.index('data-theme-option="rose"')
    assert "applyTheme('hacker')" in js
    assert "persistUserPreference('theme', theme)" in js
    assert "saved to your account and loads independently" in html.lower()
    assert 'src="/static/rocks-emblem.svg"' in html
    assert "Anonymous-style mask artwork" not in html
    assert (ROOT / "backend/static/rocks-emblem.svg").exists()
    assert not (ROOT / "backend/static/anonymous-mask.webp").exists()
    assert 'id="hackerHomeBanner"' in html
    assert "matrixCanvas" in html and "正在连接" in html


def test_availability_ui_shows_all_regions_and_disables_unsupported_choices():
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    js = (ROOT / "backend/static/app.js").read_text(encoding="utf-8")
    app = (ROOT / "backend/app.py").read_text(encoding="utf-8")
    assert 'id="spinAvailability"' in html
    assert 'id="evoAvailability"' in html
    assert 'id="ghostAvailability"' in html
    assert "LIVE GAME CONNECTOR NOT CONFIGURED" in js
    assert "button.disabled = true" in js
    assert "payload_execution_enabled" in app or "payload_execution_enabled" in (ROOT / "backend/data/rocks_catalogue.json").read_text(encoding="utf-8")


def test_theme_preferences_are_stored_per_authenticated_user_id():
    app = (ROOT / "backend/app.py").read_text(encoding="utf-8")
    assert "CREATE TABLE IF NOT EXISTS user_preferences" in app
    assert "user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE" in app
    assert '@app.get("/api/preferences")' in app
    assert '@app.put("/api/preferences")' in app
    assert 'int(user["id"])' in app
    assert "client cannot choose another user ID" in app
