"""Regression tests for ROCKS v2 privacy, exports, favourites, and security controls."""
from datetime import timedelta
import json
from pathlib import Path
import sys

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from backend import app as rocks


def setup_db(tmp_path, monkeypatch):
    users_dir = tmp_path / "users"
    avatars_dir = tmp_path / "avatars"
    users_dir.mkdir(exist_ok=True)
    avatars_dir.mkdir(exist_ok=True)
    monkeypatch.setattr(rocks, "DB_PATH", tmp_path / "rocks.sqlite3")
    monkeypatch.setattr(rocks, "DATA_DIR", tmp_path)
    monkeypatch.setattr(rocks, "USERS_DIR", users_dir)
    monkeypatch.setattr(rocks, "AVATARS_DIR", avatars_dir)
    rocks.init_db()
    return users_dir, avatars_dir


def add_session(user, token):
    expires = (rocks.utcnow() + timedelta(days=1)).isoformat(timespec="seconds")
    with rocks.connect() as con:
        con.execute(
            "INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)",
            (rocks.hash_value(token), user["id"], expires, rocks.iso_now()),
        )




def insert_verified_result(account, user, event_key="cobra", item_id="710026009", item_name="Cobra Rage Bundle", region="TW"):
    with rocks.connect() as con:
        cur = con.execute(
            "INSERT INTO spins(user_id,account_id,event_key,event_name,item_id,item_name,draw_number,region_code,demo,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,0,?)",
            (user["id"], account["id"], event_key, "Token Tower", item_id, item_name, 1, region, rocks.iso_now()),
        )
        return int(cur.lastrowid)



def test_default_owner_is_seeded_when_admin_env_is_blank(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_TELEGRAM_IDS", "")
    setup_db(tmp_path, monkeypatch)
    assert rocks.is_owner_telegram(8664344820)
    assert rocks.is_admin_telegram(8664344820)


def test_favourites_are_scoped_to_each_authenticated_user(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    a = rocks.find_or_create_user(811001, "alpha", "Alpha")
    b = rocks.find_or_create_user(811002, "bravo", "Bravo")
    item = rocks.SEED_ITEMS[0]
    category, item_id = item[0], item[1]

    assert rocks.add_favorite(rocks.FavoriteBody(category=category, item_id=item_id), a) == {"ok": True}
    cat_a = rocks.get_catalog(category=category, user=a)["items"]
    cat_b = rocks.get_catalog(category=category, user=b)["items"]
    assert next(x for x in cat_a if x["item_id"] == item_id)["favorite"] == 1
    assert next(x for x in cat_b if x["item_id"] == item_id)["favorite"] == 0
    assert rocks.get_favorites(a)["favorites"]
    assert rocks.get_favorites(b)["favorites"] == []
    rocks.remove_favorite(category, item_id, a)
    assert rocks.get_favorites(a)["favorites"] == []


def test_result_search_filters_only_the_calling_users_rows(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    a = rocks.find_or_create_user(812001, "alpha", "Alpha")
    b = rocks.find_or_create_user(812002, "bravo", "Bravo")
    account_a = rocks.add_account(rocks.AccountBody(label="My profile", game_uid="A-111"), a)["account"]
    account_b = rocks.add_account(rocks.AccountBody(label="Other profile", game_uid="B-222"), b)["account"]
    insert_verified_result(account_a, a)
    insert_verified_result(account_b, b)
    results_a = rocks.get_results(user=a, q="Cobra", region_code="TW")
    assert results_a["total"] == 1
    assert results_a["results"][0]["game_uid"] == "A-111"
    assert rocks.get_results(user=a, q="B-222")["total"] == 0


def test_short_lived_download_ticket_is_private_and_single_use(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    a = rocks.find_or_create_user(813001, "alpha", "Alpha")
    b = rocks.find_or_create_user(813002, "bravo", "Bravo")
    account_a = rocks.add_account(rocks.AccountBody(label="Private A", game_uid="A-111"), a)["account"]
    account_b = rocks.add_account(rocks.AccountBody(label="Private B", game_uid="B-222"), b)["account"]
    insert_verified_result(account_a, a)
    insert_verified_result(account_b, b)
    add_session(a, "session-a")
    add_session(b, "session-b")

    with TestClient(rocks.app) as client:
        headers_a = {"Authorization": "Bearer session-a"}
        headers_b = {"Authorization": "Bearer session-b"}
        issued = client.post("/api/me/download-ticket", headers=headers_a, json={"format": "json"})
        assert issued.status_code == 200, issued.text
        url = issued.json()["url"]
        assert url.startswith("/api/download/")
        exported = client.get(url)
        assert exported.status_code == 200, exported.text
        data = exported.json()
        assert [row["game_uid"] for row in data["accounts"]] == ["A-111"]
        assert "B-222" not in exported.text
        assert exported.headers["cache-control"] == "no-store"
        assert client.get(url).status_code == 404

        # Ticket endpoints require an authenticated caller to mint, but the opaque ticket
        # is the only capability accepted by the one-time download endpoint.
        issued_b = client.post("/api/me/download-ticket", headers=headers_b, json={"format": "csv"})
        assert issued_b.status_code == 200
        csv_response = client.get(issued_b.json()["url"])
        assert csv_response.status_code == 200
        assert "B-222" in csv_response.text and "A-111" not in csv_response.text


def test_self_delete_removes_private_rows_and_revokes_session(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    user = rocks.find_or_create_user(814001, "erase", "Erase me")
    rocks.add_account(rocks.AccountBody(label="To delete", game_uid="123456"), user)
    add_session(user, "session-delete")
    with TestClient(rocks.app) as client:
        response = client.delete("/api/me", headers={"Authorization": "Bearer session-delete"})
        assert response.status_code == 200, response.text
        assert rocks.get_user_by_id(user["id"]) is None
        assert client.get("/api/me", headers={"Authorization": "Bearer session-delete"}).status_code == 401
        with rocks.connect() as con:
            assert con.execute("SELECT COUNT(*) FROM accounts WHERE user_id=?", (user["id"],)).fetchone()[0] == 0
            audit = con.execute("SELECT action,actor_telegram_id,target_type,details_json FROM audit_logs WHERE target_type='profile' AND target_id=?", (str(user["id"]),)).fetchone()
        assert audit["action"] == "self_delete_profile"
        assert audit["actor_telegram_id"] == 0
        assert json.loads(audit["details_json"]) == {"initiated_by": "self_service"}


def test_admin_audit_is_protected_and_records_catalog_changes(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    admin = rocks.find_or_create_user(815001, "staff", "Staff")
    user = rocks.find_or_create_user(815002, "regular", "Regular")
    with rocks.connect() as con:
        con.execute("INSERT INTO admins(telegram_id,role,added_by,created_at) VALUES(?,?,?,?)",
                    (admin["telegram_id"], "admin", 0, rocks.iso_now()))
    add_session(admin, "admin-session")
    add_session(user, "regular-session")
    rocks.write_audit(admin["telegram_id"], "catalog_add", "catalog", 999, {"category": "cobra"})

    with TestClient(rocks.app) as client:
        assert client.get("/api/admin/audit-logs", headers={"Authorization": "Bearer regular-session"}).status_code == 404
        response = client.get("/api/admin/audit-logs", headers={"Authorization": "Bearer admin-session"})
        assert response.status_code == 200, response.text
        assert response.json()["events"][0]["action"] == "catalog_add"
        headers = response.headers
        home = client.get("/")
        assert home.status_code == 200
        assert home.headers["x-content-type-options"] == "nosniff"
        assert home.headers["x-frame-options"] == "DENY"
        assert "default-src 'self'" in home.headers["content-security-policy"]


def test_live_spin_route_fails_closed_without_creating_a_result(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    user = rocks.find_or_create_user(816001, "one", "One")
    account = rocks.add_account(rocks.AccountBody(label="A", game_uid="AAAA11"), user)["account"]
    add_session(user, "live-only-session")
    with TestClient(rocks.app) as client:
        headers = {"Authorization": "Bearer live-only-session"}
        before = client.get("/api/results", headers=headers)
        response = client.post("/api/spins", headers=headers, json={
            "account_id": account["id"], "event_key": "cobra", "region_code": "TW", "count": 1
        })
        assert response.status_code == 503
        assert "No request was sent" in response.json()["detail"]
        after = client.get("/api/results", headers=headers)
        assert before.json()["total"] == after.json()["total"] == 0


def test_all_ui_preferences_are_persisted_per_user_and_included_in_private_export(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    a = rocks.find_or_create_user(817001, "prefs-a", "Preferences A")
    b = rocks.find_or_create_user(817002, "prefs-b", "Preferences B")
    add_session(a, "prefs-session-a")
    add_session(b, "prefs-session-b")

    update = {
        "theme": "rose",
        "region_general": "TW",
        "region_evo": "ME",
        "region_ghost": "TW",
        "catalog_category": "favorites",
        "catalog_search": "Cobra",
        "results_search": "Rage",
        "results_event": "cobra",
        "results_region": "TW",
        "vibration_enabled": False,
        "dashboard_widgets": "gen,spinner,catalog",
        "profile_widgets": "identity,draws",
        "result_view": "timeline",
    }
    with TestClient(rocks.app) as client:
        auth_a = {"Authorization": "Bearer prefs-session-a"}
        auth_b = {"Authorization": "Bearer prefs-session-b"}
        response = client.put("/api/preferences", headers=auth_a, json=update)
        assert response.status_code == 200, response.text
        returned = response.json()
        assert returned["theme"] == "rose"
        assert returned["catalog_category"] == "favorites"
        assert returned["catalog_search"] == "Cobra"
        assert returned["results_search"] == "Rage"
        assert returned["results_event"] == "cobra"
        assert returned["results_region"] == "TW"
        assert returned["vibration_enabled"] is False
        assert returned["dashboard_widgets"] == "gen,spinner,catalog"
        assert returned["profile_widgets"] == "identity,draws"
        assert returned["result_view"] == "timeline"

        other = client.get("/api/preferences", headers=auth_b).json()
        assert other["theme"] == "hacker"
        assert other["catalog_search"] == ""
        assert other["results_region"] == ""
        assert other["vibration_enabled"] is True
        assert other["dashboard_widgets"] == "accounts,gen,activator,evo,ghost,spinner,catalog,results"
        assert other["profile_widgets"] == "identity,usage,accounts,draws"
        assert other["result_view"] == "cards"

        exported = client.get("/api/me/export", headers=auth_a)
        assert exported.status_code == 200
        export_prefs = exported.json()["preferences"]
        for key, value in update.items():
            assert export_prefs[key] == value
        assert "prefs-session-a" not in exported.text
        assert "prefs-session-b" not in exported.text


def test_catalog_deletion_removes_orphaned_user_favorites(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    admin = rocks.find_or_create_user(818001, "catalog-admin", "Catalog Admin")
    user = rocks.find_or_create_user(818002, "catalog-user", "Catalog User")
    with rocks.connect() as con:
        con.execute("INSERT INTO admins(telegram_id,role,added_by,created_at) VALUES(?,?,?,?)",
                    (admin["telegram_id"], "owner", admin["telegram_id"], rocks.iso_now()))
        entry = con.execute("SELECT id,category,item_id FROM catalog WHERE enabled=1 LIMIT 1").fetchone()
    rocks.add_favorite(rocks.FavoriteBody(category=entry["category"], item_id=entry["item_id"]), user)
    result = rocks.admin_delete_catalog(int(entry["id"]), admin)
    assert result == {"ok": True}
    assert rocks.get_favorites(user)["favorites"] == []


def test_health_is_public_minimal_and_openapi_docs_are_disabled_by_default(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    with TestClient(rocks.app) as client:
        health = client.get("/health")
        assert health.status_code == 200
        assert health.json() == {"status": "ok", "brand": "ROCKS", "version": "2.0.0", "mode": "demo-only"}
        assert client.get("/docs").status_code == 404
        assert client.get("/openapi.json").status_code == 404


def test_admin_catalog_bulk_import_deduplicates_and_exports_with_single_use_ticket(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    admin = rocks.find_or_create_user(819001, "catalog-owner", "Catalog Owner")
    regular = rocks.find_or_create_user(819002, "catalog-viewer", "Catalog Viewer")
    with rocks.connect() as con:
        con.execute("INSERT INTO admins(telegram_id,role,added_by,created_at) VALUES(?,?,?,?)",
                    (admin["telegram_id"], "owner", admin["telegram_id"], rocks.iso_now()))
    add_session(admin, "catalog-owner-session")
    add_session(regular, "catalog-regular-session")

    payload = {"items": [
        {"category": "cobra", "item_id": "BULK-ONE", "name": "Bulk One", "rarity": "rare"},
        {"category": "cobra", "item_id": "BULK-ONE", "name": "Duplicate Must Not Overwrite", "rarity": "ultra_rare"},
        {"category": "evo", "item_id": "BULK-TWO", "name": "Bulk Two", "rarity": "featured"},
    ]}
    with TestClient(rocks.app) as client:
        auth_admin = {"Authorization": "Bearer catalog-owner-session"}
        auth_regular = {"Authorization": "Bearer catalog-regular-session"}
        denied = client.post("/api/admin/catalog/import", headers=auth_regular, json=payload)
        assert denied.status_code == 404
        imported = client.post("/api/admin/catalog/import", headers=auth_admin, json=payload)
        assert imported.status_code == 200, imported.text
        assert imported.json()["added"] == 2
        assert imported.json()["skipped"] == 1
        row = next(i for i in client.get("/api/catalog", headers=auth_admin).json()["items"] if i["item_id"] == "BULK-ONE")
        assert row["name"] == "Bulk One"

        denied_ticket = client.post("/api/admin/catalog/download-ticket", headers=auth_regular)
        assert denied_ticket.status_code == 404
        ticket = client.post("/api/admin/catalog/download-ticket", headers=auth_admin)
        assert ticket.status_code == 200, ticket.text
        exported = client.get(ticket.json()["url"])
        assert exported.status_code == 200, exported.text
        assert "BULK-ONE" in exported.text and "BULK-TWO" in exported.text
        assert exported.headers["cache-control"] == "no-store"
        assert client.get(ticket.json()["url"]).status_code == 404


def test_catalog_import_rejects_unbounded_or_invalid_items(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    admin = rocks.find_or_create_user(820001, "import-owner", "Import Owner")
    with rocks.connect() as con:
        con.execute("INSERT INTO admins(telegram_id,role,added_by,created_at) VALUES(?,?,?,?)",
                    (admin["telegram_id"], "owner", admin["telegram_id"], rocks.iso_now()))
    too_many = {"items": [{"category": "cobra", "item_id": f"BULK{i}", "name": f"Item {i}"} for i in range(201)]}
    with pytest.raises(Exception):
        rocks.CatalogImportBody.model_validate(too_many)
    with pytest.raises(Exception):
        rocks.CatalogImportBody.model_validate({"items": [{"category": "cobra", "item_id": "BAD", "name": "   "}]})



def test_csv_exports_neutralize_spreadsheet_formula_prefixes(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    user = rocks.find_or_create_user(821001, "csv-safe", "CSV Safe")
    account = rocks.add_account(
        rocks.AccountBody(label='=HYPERLINK("bad","label")', game_uid="UID-821001"), user
    )["account"]
    insert_verified_result(account, user)
    with TestClient(rocks.app) as client:
        csv_response = client.get("/api/results/export.csv", headers={"Authorization": "Bearer csv-session"})
        # No session is present by default; create one and retry to ensure the route is gated.
        assert csv_response.status_code == 401
        add_session(user, "csv-safe-session")
        csv_response = client.get("/api/results/export.csv", headers={"Authorization": "Bearer csv-safe-session"})
        assert csv_response.status_code == 200
        assert "'=HYPERLINK" in csv_response.text


def test_admin_catalog_csv_export_neutralizes_formula_names(tmp_path, monkeypatch):
    setup_db(tmp_path, monkeypatch)
    admin = rocks.find_or_create_user(822001, "csv-admin", "CSV Admin")
    with rocks.connect() as con:
        con.execute("INSERT INTO admins(telegram_id,role,added_by,created_at) VALUES(?,?,?,?)",
                    (admin["telegram_id"], "owner", admin["telegram_id"], rocks.iso_now()))
        con.execute("INSERT INTO catalog(category,item_id,name,rarity,enabled,created_at) VALUES(?,?,?,?,1,?)",
                    ("cobra", "CSV-SAFE", '=HYPERLINK("bad","label")', "rare", rocks.iso_now()))
    add_session(admin, "csv-admin-session")
    with TestClient(rocks.app) as client:
        headers = {"Authorization": "Bearer csv-admin-session"}
        ticket = client.post("/api/admin/catalog/download-ticket", headers=headers)
        assert ticket.status_code == 200
        csv_response = client.get(ticket.json()["url"])
        assert csv_response.status_code == 200
        assert "'=HYPERLINK" in csv_response.text
