from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def test_app_uses_original_rocks_visual_asset_and_neutral_theme_names():
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    js = (ROOT / "backend/static/app.js").read_text(encoding="utf-8")
    css = (ROOT / "backend/static/style.css").read_text(encoding="utf-8")
    assert "/static/rocks-emblem.svg" in html
    assert "ROCKS Grid" in html and "Midnight" in html and "Rose Quartz" in html
    assert "Anonymous-style" not in html and "Anonymous Hacker" not in html
    assert "Batman-inspired" not in html and "Barbie Pink" not in html
    assert "FF Item Library" not in js and "Alternate Lookup" not in js
    assert "content:'🦇'" not in css
    assert (ROOT / "backend/static/rocks-emblem.svg").exists()
    assert not (ROOT / "backend/static/anonymous-mask.webp").exists()

def test_rocks_version_is_consistent_in_app_and_android_project():
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    gradle = (ROOT / "android/app/build.gradle.kts").read_text(encoding="utf-8")
    catalog = json.loads((ROOT / "backend/data/rocks_catalogue.json").read_text(encoding="utf-8"))
    assert "v2.8.0" in html
    assert 'versionName = "2.8.0"' in gradle
    assert 'versionCode = 11' in gradle
    assert catalog["schema_version"] == "2.8.0"
    manifest = (ROOT / "android/app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
    assert 'android:icon="@drawable/rocks_launcher"' in manifest
    assert (ROOT / "android/app/src/main/res/drawable/rocks_launcher.xml").exists()


def test_old_theme_preferences_migrate_to_neutral_keys(tmp_path, monkeypatch):
    import sys
    sys.path.insert(0, str(ROOT))
    from backend import app as rocks
    monkeypatch.setattr(rocks, "DATA_DIR", tmp_path)
    monkeypatch.setattr(rocks, "DB_PATH", tmp_path / "rocks.sqlite3")
    monkeypatch.setattr(rocks, "USERS_DIR", tmp_path / "users")
    monkeypatch.setattr(rocks, "AVATARS_DIR", tmp_path / "avatars")
    rocks.DATA_DIR.mkdir(parents=True, exist_ok=True)
    rocks.init_db()
    user = rocks.find_or_create_user(99887766, "test", "Test")
    rocks.get_preferences(user)
    with rocks.connect() as con:
        con.execute("UPDATE user_preferences SET theme='batman' WHERE user_id=?", (user["id"],))
        con.commit()
    rocks.init_db()
    with rocks.connect() as con:
        theme = con.execute("SELECT theme FROM user_preferences WHERE user_id=?", (user["id"],)).fetchone()[0]
    assert theme == "midnight"

def test_supplied_reference_files_are_preserved_byte_for_byte():
    import hashlib
    manifest = json.loads((ROOT / "supplied_inputs/SOURCE_MANIFEST.json").read_text(encoding="utf-8"))
    for item in manifest["files"]:
        source = ROOT / "supplied_inputs" / item["filename"]
        assert source.is_file(), item["filename"]
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        assert digest == item["sha256"], item["filename"]
