"""v2.8.0 user-facing navigation, personalization and offline-mode checks."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_primary_navigation_is_mobile_first_and_specialist_sections_are_in_more():
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    assert 'class="tabs bottom-nav" id="tabs"' in html
    nav = html[html.index('id="tabs"'):html.index('</nav>', html.index('id="tabs"'))]
    expected = ['data-tab="profile"', 'data-tab="home"', 'data-tab="gen"', 'data-tab="spinner"', 'data-tab="more"']
    positions = [nav.index(x) for x in expected]
    assert positions == sorted(positions)
    for target in ("activator", "evo", "ghost", "themes", "accounts", "catalog", "results", "settings", "privacy"):
        assert f'data-open-tab="{target}"' in html
    assert 'id="openAdminDestination"' in html and 'class="quick-card panel hidden" data-open-tab="admin"' in html


def test_dashboard_and_profile_widgets_and_result_views_have_controls():
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    js = (ROOT / "backend/static/app.js").read_text(encoding="utf-8")
    for widget in ("accounts", "gen", "activator", "evo", "ghost", "spinner", "catalog", "results"):
        assert f'data-pref-list="dashboard_widgets" value="{widget}"' in html
        assert f'data-dashboard-widget="{widget}"' in html
    for widget in ("identity", "usage", "accounts", "draws"):
        assert f'data-pref-list="profile_widgets" value="{widget}"' in html
        assert f'data-profile-widget="{widget}"' in html
    for view in ("cards", "list", "timeline"):
        assert f'data-result-view="{view}"' in html
    assert "applyDashboardWidgets" in js and "applyProfileWidgets" in js and "applyResultsView" in js
    assert "persistUserPreference(key, value)" in js


def test_spinner_event_priority_and_event_specific_region_defaults_are_explicit():
    js = (ROOT / "backend/static/app.js").read_text(encoding="utf-8")
    priority = "['cobra', 'thailand_free', 'vietnam_free', 'emote_royale', 'm4a1', 'gold_royale']"
    assert priority in js
    assert "function applyEventDefaultRegion(eventKey, persist=true)" in js
    assert "cobra:'TW', thailand_free:'TH', vietnam_free:'VN', m4a1:'IND', emote_royale:'IND', gold_royale:'IND'" in js


def test_offline_view_has_retry_and_cached_catalogue_and_missing_art_is_hidden():
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    js = (ROOT / "backend/static/app.js").read_text(encoding="utf-8")
    assert 'id="offlineView"' in html and 'id="retryConnectionBtn"' in html
    assert 'id="offlineCatalogueList"' in html
    assert "rocks_catalog_cache" in js
    assert "img.hidden = true" in js and "art-unavailable" in js
