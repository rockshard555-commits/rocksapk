"""Tests for the new separate Gen and Auto Activator workspaces."""
from datetime import timedelta
from pathlib import Path
import sys

from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from backend import app as rocks


def setup_test_db(tmp_path, monkeypatch):
    (tmp_path / "users").mkdir(exist_ok=True)
    (tmp_path / "avatars").mkdir(exist_ok=True)
    monkeypatch.setattr(rocks, "DB_PATH", tmp_path / "rocks.sqlite3")
    monkeypatch.setattr(rocks, "DATA_DIR", tmp_path)
    monkeypatch.setattr(rocks, "USERS_DIR", tmp_path / "users")
    monkeypatch.setattr(rocks, "AVATARS_DIR", tmp_path / "avatars")
    rocks.init_db()
    user = rocks.find_or_create_user(930001, "rocks_user", "ROCKS User")
    token = "gen-activator-session"
    expires = (rocks.utcnow() + timedelta(days=1)).isoformat(timespec="seconds")
    with rocks.connect() as con:
        con.execute("INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)",
                    (rocks.hash_value(token), user["id"], expires, rocks.iso_now()))
    return user, token


def test_gen_and_activator_sections_are_separate_and_not_executed():
    html = (ROOT / "backend/static/index.html").read_text(encoding="utf-8")
    app = (ROOT / "backend/app.py").read_text(encoding="utf-8")
    assert 'data-tab="gen"' in html
    assert 'data-open-tab="activator"' in html
    assert 'id="tab-activator"' in html
    assert 'id="genOnlyModeBtn"' in html
    assert 'id="genAutoModeBtn"' in html
    assert 'id="refreshActivatorStatusBtn"' in html
    assert '"execution_enabled": False' in app
    assert "No activation request has been sent" in html


def test_gen_mode_preference_is_private_to_authenticated_user(tmp_path, monkeypatch):
    setup_test_db(tmp_path, monkeypatch)
    a = rocks.find_or_create_user(930011, "a", "A")
    b = rocks.find_or_create_user(930012, "b", "B")
    rocks.update_preferences(rocks.PreferencesBody(gen_mode="gen_plus_activator"), a)
    assert rocks.get_preferences(a)["gen_mode"] == "gen_plus_activator"
    assert rocks.get_preferences(b)["gen_mode"] == "gen_only"


def test_activator_status_does_not_call_external_api(tmp_path, monkeypatch):
    user, token = setup_test_db(tmp_path, monkeypatch)
    monkeypatch.setattr(rocks, "ROCKS_ACTIVATOR_API_URL", "https://example.invalid/activate")
    with TestClient(rocks.app) as client:
        response = client.get("/api/activator/status", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    data = response.json()
    assert data["endpoint_configured"] is True
    assert data["execution_enabled"] is False
    assert data["api_contract_verified"] is False


def test_gen_mode_rejects_unknown_values():
    import pytest
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        rocks.PreferencesBody(gen_mode="admin_runner")
