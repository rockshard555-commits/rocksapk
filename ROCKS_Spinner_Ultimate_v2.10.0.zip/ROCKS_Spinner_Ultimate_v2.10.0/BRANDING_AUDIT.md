# ROCKS v2.8.0 branding audit

## Active product surfaces

- Web app header, login screen, dashboard, theme studio, item reference links, footer, and Android launcher use ROCKS branding and the original ROCKS emblem.
- The prior third-party mask artwork was removed from `backend/static/`; no current app screen references it.
- Theme display names are ROCKS Grid, Midnight, Rose Quartz, Crimson Protocol, Ocean Matrix, Amethyst, and Arctic Light. Legacy externally-inspired theme preference values are migrated to neutral identifiers while preserving user choices.
- Catalogue lookup URLs remain in data so item references are traceable, but the app-facing anchors use generic labels instead of displaying source site names. Opening an external source page will naturally show that site's own branding.
- The configured one-time sign-in bot and its identity provider are still required operational dependencies; their logos are not used as ROCKS app branding.

## Source preservation boundary

The supplied `Gen.py`, event script archives, and reference APK are retained as supplied reference material. `Gen.py` is byte-for-byte unchanged and its original embedded author/copyright notice remains intact. The reference APK is not used as the ROCKS launcher or passed off as a ROCKS build. Rewriting or stripping notices from original source artifacts would conflict with the requirement to preserve source logic and provenance.

## Build and runtime status

This is a versioned source package, not a compiled APK. The Android project now declares version 2.8.0 and includes a ROCKS launcher vector asset. Building still requires JDK 17, Gradle 8.9, Android SDK platform 35/build-tools 35.0.0, and a deployed HTTPS backend URL. Spin/account-generation actions remain unavailable in this release because the supplied private game endpoints have not been integrated into an authorized, independently verified connector.
