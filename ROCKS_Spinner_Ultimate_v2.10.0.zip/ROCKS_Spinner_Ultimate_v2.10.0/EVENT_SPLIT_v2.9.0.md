# v2.9.0 — Separate Thailand/Vietnam free events

The single `thailand_free` combined event has been represented as two independent selectable entries:

- `thailand_free`: Thailand (`TH`), Event 8, Ballsy Skaterboi Royale; payload reference `083e100118ff2a200160006802`; item IDs `710028027`, `710000021`, `710000022`, `710046028`.
- `vietnam_free`: Vietnam (`VN`), Event 5, Infernosaur Royale; payload reference `083d100118842b200160006802`; item IDs `211055028`, `211055030`, `205055021`, `205055022`.

The event catalogue, general spinner selector, item categories, result filter, preference validation, and bot catalogue category validation now treat them separately. The payloads remain non-executable references; live spin submission is still disabled until a documented, authorized connector is implemented and tested.
