# Build a usable ROCKS APK

The Android client is a WebView shell that loads the deployed ROCKS backend over HTTPS. It cannot be a complete, usable APK without a reachable backend URL. This workspace does not include an APK built from v2.8.0; the provided older third-party APK is reference-only and is not rebranded or passed off as ROCKS.

## Build through GitHub Actions

1. Create a private GitHub repository and upload the contents of this ZIP (the project root should contain `.github/`, `android/`, `backend/`, `tests/`, and `requirements*.txt`).
2. Deploy `backend/` on a host that provides a stable HTTPS URL. Configure persistent storage for the SQLite database and user files; configure the Telegram bot token/admin IDs if using Telegram sign-in. Follow `README.md` and `SECURITY.md` before exposing the service publicly.
3. In GitHub, open **Actions → Test and build ROCKS Android APK → Run workflow**. Paste the backend's HTTPS base URL into the required `app_base_url` input.
4. Wait for both the test and build jobs to pass. Download the `rocks-spinner-debug-apk` artifact from that workflow run. It contains the debug APK built from this source.

A GitHub build will fail deliberately if no HTTPS backend URL is configured. Do not use `https://YOUR-DOMAIN` or another placeholder.

## Local build

Install JDK 17, Gradle 8.9, and Android SDK Platform 35 / Build Tools 35.0.0, then run from the project root:

```bash
gradle -p android assembleDebug -PAPP_BASE_URL=https://your-deployed-backend.example
```

Output: `android/app/build/outputs/apk/debug/app-debug.apk`. The app URL is compiled into the APK; changing it later requires another build.

## Scope of live game actions

The v2.8.0 data update includes 16 region endpoint mappings and all seven supplied event workspaces. A configured URL is not proof that an event payload is accepted or that a reward was granted. The current app intentionally does not submit private game requests or fabricate rewards; a documented, authorized integration remains a separate requirement.
