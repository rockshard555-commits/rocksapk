(() => {
  const $ = (id) => document.getElementById(id);
  let token = localStorage.getItem('rocks_session') || '';
  let me = null;
  let events = [];
  let regions = [];
  let catalog = [];
  let accounts = [];
  let toolModules = [];
  let isStaff = false;
  let canManageAdmins = false;
  let activeCatalogCategory = 'all';
  let resultOffset = 0;
  let resultTotal = 0;
  const resultLimit = 100;
  let resultSearchTimer = 0;
  let userPreferences = {theme:'hacker', region_general:'IND', region_evo:'ME', region_ghost:'TW', catalog_category:'all', catalog_search:'', results_search:'', results_event:'', results_region:'', vibration_enabled:true, gen_mode:'gen_only', dashboard_widgets:'accounts,gen,activator,evo,ghost,spinner,catalog,results', profile_widgets:'identity,usage,accounts,draws', result_view:'cards'};
  let preferencesSaveQueue = Promise.resolve();
  let preferenceDebounceTimer = 0;
  let pendingPreferenceChanges = {};
  let preferenceDebounceSession = null;
  const categoryLabels = {
    m4a1: 'M4A1 Ring', emote_royale: 'Emote Royale', gold_royale: 'Gold Royale',
    ghost: 'Ghost Bundle Ring', evo: 'Evo Guns Ring', thailand_free: 'Thailand Free — Ballsy Skaterboi', vietnam_free: 'Vietnam Free — Infernosaur', cobra: 'Token Tower'
  };
  const THEME_INFO = {
    hacker: {name:'ROCKS Grid', color:'#020804'},
    midnight: {name:'Midnight', color:'#07090e'},
    rose: {name:'Rose Quartz', color:'#ff2d95'},
    crimson: {name:'Crimson Protocol', color:'#120609'},
    ocean: {name:'Ocean Matrix', color:'#06111c'},
    amethyst: {name:'Amethyst', color:'#0e0718'},
    arctic: {name:'Arctic Light', color:'#edf4fa'}
  };
  let matrixRaf = 0;
  let matrixDrops = [];
  let matrixWidth = 0;
  let matrixHeight = 0;
  let matrixTick = 0;

  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  // Use numeric-ID matched item art when confirmed; all unknowns fall back to ROCKS artwork.
  document.addEventListener('error', (event) => {
    const img = event.target;
    if (!(img instanceof HTMLImageElement)) return;
    // Missing item art should never remove the catalogue/result entry itself.
    // Keep the card and hide only the failed image, as selected in the UX spec.
    if (img.matches('.catalog-art,.result-art,.draw-art,.admin-item-art,.reveal-art')) {
      img.hidden = true;
      img.classList.add('art-unavailable');
    }
  }, true);
  const ITEM_IMAGE_BY_ID = {
    '710026009':'https://www.freefiremania.com.br/images/itens/Icon_bundle_male_Cobra_Red_26.png',
    '907104202':'https://www.freefiremania.com.br/images/itens/Icon_M4A1_Light.png',
    '907104019':'https://www.freefiremania.com.br/images/itens/Icon_P90_Festivalme_22.png',
    '905000065':'https://www.freefiremania.com.br/images/itens/Icon_Avatar_PARACHUTE_Spirit.png',
    '909046001':'https://www.freefiremania.com.br/images/itens/Icon_Emote_Yinyang24.png',
    '909036001':'https://www.freefiremania.com.br/images/itens/Icon_Emote_Ghost_Move.png',
    '909055005':'https://www.freefiremania.com.br/images/itens/Icon_Emote_Halloween26_Cry.png',
    '909000049':'https://www.freefiremania.com.br/images/itens/Icon_Emote_Whirling.png',
    '710055013':'https://www.freefiremania.com.br/images/itens/Icon_bundle_male_Halloween26_Hollow_55.png',
    '710055014':'https://www.freefiremania.com.br/images/itens/Icon_bundle_female_Halloween26_Crawl_55.png',
    '907195111':'https://www.freefiremania.com.br/images/itens/Icon_M60_Dreamland_03.png',
    '907193501':'https://www.freefiremania.com.br/images/itens/Icon_M1887_Digitaluniverse03.png',
    '907192601':'https://www.freefiremania.com.br/images/itens/Icon_MP40_Cobra1.png',
    '907193511':'https://www.freefiremania.com.br/images/itens/Icon_AN94_Wildfire_Skeleton3.png',
    '710028027':'https://www.freefiremania.com.br/images/itens/Icon_bundle_male_Sportswear_BW_46.png',
    '710046028':'https://www.freefiremania.com.br/images/itens/Icon_bundle_Sportsuit_28.png',
    '211055028':'https://www.freefiremania.com.br/images/itens/Icon_avatar_male_cos_accessory_flamedino.png',
    '211055030':'https://www.freefiremania.com.br/images/itens/Icon_avatar_female_cos_accessory_flamedino.png'
  };
  const itemImageUrl = (id) => (catalog.find(item => String(item.item_id) === String(id))?.image_url || ITEM_IMAGE_BY_ID[String(id)] || '/static/item-placeholder.svg');
  const itemLookupLinks = (item) => {
    const itemId = String(item.item_id || '');
    const library = item.ff_item_library_url || 'https://ff-item.netlify.app/';
    const mania = item.freefiremania_item_url || item.freefiremania_search_url || 'https://www.freefiremania.com.br/free-fire-items.html';
    return `<div class="item-source-links"><a href="${esc(library)}" rel="noopener noreferrer" title="Open image reference for item ID ${esc(itemId)}">Image Reference ↗</a><a href="${esc(mania)}" rel="noopener noreferrer" title="Open alternate reference for item ID ${esc(itemId)}">More References ↗</a></div>`;
  };
  const itemArtworkNote = (item) => {
    const status = String(item.image_status || '');
    if (status === 'needs_id_lookup' || status === 'id_page_no_direct_icon_confirmed')
      return '<div class="tiny muted artwork-note">Artwork lookup pending</div>';
    if (status === 'id_verified_name_needs_review')
      return '<div class="tiny artwork-note artwork-note-warn">Please verify item label against this ID</div>';
    return '';
  };
  const rarityLabel = (value) => value === 'pending' ? 'Awaiting your choice' : String(value || 'rare').replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  let revealQueue = [];
  let revealIndex = 0;
  function showToast(text, bad=false) {
    const el = $('toast'); el.textContent = text; el.className = `toast ${bad ? 'toast-bad' : ''}`;
    clearTimeout(showToast.timer); showToast.timer = setTimeout(() => el.className = 'toast hidden', 3200);
  }
  function errorAt(id, text) {
    const el = $(id); el.textContent = text; el.classList.remove('hidden');
  }
  function clearError(id) { const el = $(id); if (el) { el.textContent=''; el.classList.add('hidden'); } }
  async function api(path, options={}) {
    const headers = {'Content-Type':'application/json', ...(options.headers || {})};
    if (token && !path.endsWith('/api/login') && !headers.Authorization) headers.Authorization = `Bearer ${token}`;
    const response = await fetch(path, {...options, headers});
    let data = {};
    try { data = await response.json(); } catch (_) {}
    if (!response.ok) {
      const error = new Error(data.detail || `Request failed (${response.status})`);
      error.status = response.status;
      if (response.status === 401 && token && !path.endsWith('/api/login')) signOut(false);
      throw error;
    }
    return data;
  }
  function showLogin() {
    $('offlineView')?.classList.add('hidden');
    $('loginView').classList.remove('hidden'); $('appView').classList.add('hidden');
  }
  function showApp() {
    $('offlineView')?.classList.add('hidden');
    $('loginView').classList.add('hidden'); $('appView').classList.remove('hidden');
  }
  function renderOfflineCatalogue() {
    let items = [];
    try { items = JSON.parse(localStorage.getItem('rocks_catalog_cache') || '[]'); } catch (_) { items = []; }
    const host = $('offlineCatalogueList');
    if (!host) return;
    setText('cachedCatalogueCount', `${items.length} cached item${items.length===1?'':'s'}`);
    host.innerHTML = items.length ? items.slice(0,24).map(item => {
      const art = item.image_url || ITEM_IMAGE_BY_ID[String(item.item_id)] || '/static/item-placeholder.svg';
      return `<article class="catalog-card panel"><div class="catalog-art-box"><img class="catalog-art" src="${esc(art)}" alt="${esc(item.name || 'Catalogue item')}" loading="lazy"></div><b>${esc(item.name || 'Catalogue item')}</b><div class="mono muted">ID · ${esc(item.item_id || 'N/A')}</div><div class="tiny muted">${esc(categoryLabels[item.category] || item.category || 'Reference')}</div></article>`;
    }).join('') : '<div class="empty-state panel"><b>No cached catalogue yet</b><p>Reconnect once to save a local reference snapshot.</p></div>';
  }
  function showOfflineView(error) {
    if (error?.message) setText('offlineStatusText', `Backend unavailable: ${error.message}. Your session is kept on this device; retry when connected.`);
    else setText('offlineStatusText', 'Backend unavailable. Private actions are paused until the connection returns.');
    renderOfflineCatalogue();
    $('loginView')?.classList.add('hidden'); $('appView')?.classList.add('hidden'); $('offlineView')?.classList.remove('hidden');
  }
  function isNetworkFailure(error) { return navigator.onLine === false || error instanceof TypeError; }
  function signOut(notify=true) {
    token = ''; me = null; localStorage.removeItem('rocks_session');
    accounts = []; catalog = []; events = []; regions = []; toolModules = [];
    isStaff = false; canManageAdmins = false;
    clearTimeout(preferenceDebounceTimer); preferenceDebounceTimer = 0; pendingPreferenceChanges = {}; preferenceDebounceSession = null;
    userPreferences = {theme:'hacker', region_general:'IND', region_evo:'ME', region_ghost:'TW', catalog_category:'all', catalog_search:'', results_search:'', results_event:'', results_region:'', vibration_enabled:true, gen_mode:'gen_only', dashboard_widgets:'accounts,gen,activator,evo,ghost,spinner,catalog,results', profile_widgets:'identity,usage,accounts,draws', result_view:'cards'};
    activeCatalogCategory = 'all'; resultOffset = 0; resultTotal = 0;
    ['catalogSearch','resultSearch'].forEach(id=>{if($(id))$(id).value='';});
    ['resultEventFilter','resultRegionFilter'].forEach(id=>{if($(id))$(id).value='';});
    if ($('vibrationEnabled')) $('vibrationEnabled').checked = true;
    if ($('resultTotal')) $('resultTotal').textContent = '';
    $('loginCode').value = '';
    ['accountList','catalogList','resultList','latestDraws','evoCatalog','ghostCatalog','evoLatestDraws','ghostLatestDraws','adminUsersList','adminResultsList','adminCatalogList','adminsList','auditLogList'].forEach(id=>{if($(id))$(id).replaceChildren();});
    $('adminPanel').classList.add('hidden');
    ['profileName','profileUsername','profileId','accountNumber','drawNumber','resultTotal','catalogCount'].forEach(id=>setText(id,''));
    $('avatar').src='/static/avatar-placeholder.svg';
    applyTheme('hacker'); showLogin();
    if (notify) showToast('Signed out');
  }
  async function doLogin() {
    clearError('loginError');
    const code = $('loginCode').value.trim().toUpperCase();
    if (!code) return errorAt('loginError', 'Enter your ROCKS one-time access key.');
    $('loginBtn').disabled = true; $('loginBtn').textContent = 'Checking key…';
    try {
      const data = await api('/api/login', {method:'POST', body:JSON.stringify({code})});
      token = data.token; localStorage.setItem('rocks_session', token);
      await loadDashboard();
      showToast('Welcome to ROCKS');
    } catch (e) { if (isNetworkFailure(e)) showOfflineView(e); else errorAt('loginError', e.message); }
    finally { $('loginBtn').disabled = false; $('loginBtn').innerHTML = 'Unlock ROCKS <span>↗</span>'; }
  }
  function setText(id, value) { $(id).textContent = value == null ? '' : String(value); }
  function formatDate(v) {
    if (!v) return '—';
    const d = new Date(v);
    return Number.isNaN(d.getTime()) ? v : d.toLocaleString([], {month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'});
  }
  function formatShortDate(v) {
    if (!v) return '—'; const d = new Date(v);
    return Number.isNaN(d.getTime()) ? v : d.toLocaleDateString([], {year:'numeric',month:'short',day:'numeric'});
  }
  function renderProfile(user) {
    me = user;
    setText('profileName', user.first_name || 'ROCKS user');
    setText('profileUsername', user.username ? '@' + user.username : 'Connected account');
    setText('profileId', 'ROCKS ACCOUNT ID · ' + user.telegram_id);
    const avatar = $('avatar'); avatar.dataset.allowFallback = 'true'; avatar.hidden = false; avatar.src = user.avatar_url || '/static/avatar-placeholder.svg';
    avatar.onerror = () => { avatar.onerror = null; avatar.hidden = false; avatar.src = '/static/avatar-placeholder.svg'; };
  }
  function renderUsage(usage) {
    const limit = Number(usage.limit || 1111), used = Number(usage.used || 0);
    setText('usageNumber', `${used} / ${limit}`);
    $('usageMeter').style.width = `${Math.min(100, limit ? used/limit*100 : 0)}%`;
    setText('usageCaption', `${Math.max(0, Number(usage.remaining || 0))} profiles remaining today`);
  }
  async function loadDashboard() {
    try {
      const data = await api('/api/me');
      renderProfile(data.user); renderUsage(data.usage);
      setText('sessionLifetime', `${Number(data.session_lifetime_days || 7)} days by default`);
      setText('accountNumber', data.account_count || 0); setText('drawNumber', data.verified_draw_count || 0);
      await loadUserPreferences();
      showApp();
      await Promise.all([loadAccounts(), loadEventsAndCatalog(), loadResults(), detectAdmin(), loadActivatorStatus()]);
      renderPersonalizationSettings();
      switchTab('home');
    } catch (error) {
      if (isNetworkFailure(error)) { showOfflineView(error); throw error; }
      throw error;
    }
  }
  async function loadAccounts() {
    const data = await api('/api/accounts'); accounts = data.accounts || [];
    renderUsage(data.usage); setText('accountNumber', accounts.length); setText('accountCountChip', `${accounts.length} saved`); applyProfileWidgets();
    const list = $('accountList');
    if (!accounts.length) list.innerHTML = '<div class="empty-state panel"><span>＋</span><b>Your directory is ready</b><p>Add a UID reference profile. Game actions remain unavailable until a live connector is configured.</p></div>';
    else list.innerHTML = accounts.map(a => `<article class="record-card panel"><div class="record-icon">ID</div><div class="record-main"><b>${esc(a.label)}</b><div class="mono muted">UID · ${esc(a.game_uid)}</div><div class="tiny muted">Saved ${esc(formatDate(a.created_at))}</div></div><button class="icon-btn danger" data-delete-account="${a.id}" aria-label="Delete account profile">×</button></article>`).join('');
    list.querySelectorAll('[data-delete-account]').forEach(btn => btn.addEventListener('click', () => deleteAccount(Number(btn.dataset.deleteAccount))));
    renderSpinAccounts();
  }
  async function addAccount() {
    clearError('accountError');
    const label = $('accountLabel').value.trim(), game_uid = $('accountUid').value.trim();
    if (!label || !game_uid) return errorAt('accountError', 'Enter both a label and a UID.');
    $('addAccountBtn').disabled = true;
    try {
      await api('/api/accounts', {method:'POST', body:JSON.stringify({label, game_uid})});
      $('accountLabel').value=''; $('accountUid').value=''; await loadAccounts(); showToast('Profile saved to your private directory');
    } catch (e) { errorAt('accountError', e.message); }
    finally { $('addAccountBtn').disabled = false; }
  }
  async function deleteAccount(id) {
    if (!confirm('Delete this UID profile and its saved result records?')) return;
    try { await api(`/api/accounts/${id}`, {method:'DELETE'}); await loadAccounts(); await loadResults(); showToast('Profile deleted'); }
    catch (e) { showToast(e.message, true); }
  }
  async function loadEventsAndCatalog() {
    const [eventData, regionData, catData, moduleData] = await Promise.all([
      api('/api/events'), api('/api/regions'), api('/api/catalog'), api('/api/modules')
    ]);
    events = eventData.events || []; regions = regionData.regions || eventData.regions || [];
    catalog = catData.items || []; toolModules = moduleData.modules || [];
    try { localStorage.setItem('rocks_catalog_cache', JSON.stringify(catalog.map(item => ({category:item.category,item_id:item.item_id,name:item.name,rarity:item.rarity,image_url:item.image_url || ''})))); } catch (_) { /* Cache is best-effort; never block the app. */ }
    fillRegionSelect('spinRegion', 'region_general');
    fillRegionSelect('evoRegion', 'region_evo');
    fillRegionSelect('ghostRegion', 'region_ghost');
    $('resultRegionFilter').innerHTML = '<option value="">All regions</option>' + regions.map(r=>`<option value="${esc(r.code)}">${esc(r.flag)} ${esc(r.name)}</option>`).join('');
    if ($('catalogSearch')) $('catalogSearch').value = userPreferences.catalog_search || '';
    if ($('resultSearch')) $('resultSearch').value = userPreferences.results_search || '';
    if ($('resultEventFilter')) $('resultEventFilter').value = userPreferences.results_event || '';
    if ($('resultRegionFilter')) $('resultRegionFilter').value = userPreferences.results_region || '';
    const validCategories = ['all','favorites',...new Set([...events.map(e=>e.key), ...catalog.map(x=>x.category)])];
    activeCatalogCategory = validCategories.includes(userPreferences.catalog_category) ? userPreferences.catalog_category : 'all';
    // Evo and Ghost have their own top-level modules; keep them out of the generic spinner selector.
    const eventPriority = ['cobra', 'thailand_free', 'vietnam_free', 'emote_royale', 'm4a1', 'gold_royale'];
    const generalEvents = events.filter(e => !['evo', 'ghost'].includes(e.key)).sort((a,b) => eventPriority.indexOf(a.key) - eventPriority.indexOf(b.key));
    const select = $('spinEvent'); select.innerHTML = generalEvents.map(e => {
      const n = (e.supported_regions || []).length;
      const tag = e.catalog_complete === false ? `${n} servers · reward IDs needed` : n ? `${n} configured servers` : 'no free-spin config';
      return `<option value="${esc(e.key)}">${esc(e.name)} · ${esc(tag)}</option>`;
    }).join('');
    $('newIdCategory').innerHTML = events.map(e => `<option value="${esc(e.key)}">${esc(e.name)}</option>`).join('');
    $('inlineIdCategory').innerHTML = events.map(e => `<option value="${esc(e.key)}">${esc(e.name)}</option>`).join('');
    renderModuleStatuses(); renderSpinAccounts(); syncDrawMode(); renderCatalog();
    applyEventDefaultRegion($('spinEvent').value, false);
    renderModuleCatalogue('evo', 'evoCatalog', 'evoItemCount');
    renderModuleCatalogue('ghost', 'ghostCatalog', 'ghostItemCount');
    refreshAvailability();
    await refreshModuleResults();
  }
  function applyEventDefaultRegion(eventKey, persist=true) {
    const configuredDefaults = {cobra:'TW', thailand_free:'TH', vietnam_free:'VN', m4a1:'IND', emote_royale:'IND', gold_royale:'IND'};
    const event = events.find(entry => entry.key === eventKey);
    let desired = event?.default_region || configuredDefaults[eventKey] || 'IND';
    if (event?.supported_regions?.length && !event.supported_regions.includes(desired)) desired = event.supported_regions[0];
    if (!regions.some(region => region.code === desired)) return;
    $('spinRegion').value = desired;
    if (persist) persistUserPreference('region_general', desired);
  }
  function fillRegionSelect(selectId, preferenceKey) {
    const regionSelect = $(selectId);
    const defaults = {region_general:'IND', region_evo:'ME', region_ghost:'TW'};
    const defaultRegion = defaults[preferenceKey] || 'IND';
    const savedRegion = userPreferences[preferenceKey] || defaultRegion;
    regionSelect.innerHTML = regions.map(r => `<option value="${esc(r.code)}">${esc(r.flag)} ${esc(r.name)} · ${esc(r.code)}</option>`).join('');
    regionSelect.value = regions.some(r => r.code === savedRegion) ? savedRegion : defaultRegion;
    regionSelect.onchange = () => { persistUserPreference(preferenceKey, regionSelect.value); refreshAvailability(); };
  }
  function renderModuleStatuses() {
    const byKey = Object.fromEntries(toolModules.map(m => [m.key, m]));
    const gen = byKey.gen;
    if (gen) {
      setText('genModuleStatus', gen.status || 'SOURCE ONLY');
      setText('genRuntimeStatus', gen.execution_enabled ? 'Enabled' : 'Not connected');
    }
    const genOnly = byKey.gen_only;
    const genAuto = byKey.gen_plus_activator;
    if ($('genOnlyModeBtn') && genOnly) $('genOnlyModeBtn').querySelector('.gen-mode-status').textContent = genOnly.status || 'SOURCE ONLY';
    if ($('genAutoModeBtn') && genAuto) $('genAutoModeBtn').querySelector('.gen-mode-status').textContent = genAuto.status || 'API CONTRACT REQUIRED';
    const evo = byKey.evo;
    if (evo) setText('evoModuleStatus', evo.status || 'NOT CONNECTED');
    const ghost = byKey.ghost;
    if (ghost) setText('ghostModuleStatus', ghost.status || 'NOT CONNECTED');
  }
  function renderSpinAccounts() {
    const ids = ['spinAccount', 'evoAccount', 'ghostAccount'];
    const html = !accounts.length
      ? '<option value="">Add an account profile first</option>'
      : accounts.map(a => `<option value="${a.id}">${esc(a.label)} · ${esc(a.game_uid)}</option>`).join('');
    ids.forEach(id => { $(id).innerHTML = html; });
    $('spinBtn').disabled = !accounts.length;
    $('evoSpinBtn').disabled = !accounts.length;
    $('ghostSpinBtn').disabled = !accounts.length;
    refreshAvailability();
  }
  function renderModuleCatalogue(category, targetId, countId) {
    const items = catalog.filter(item => item.category === category);
    setText(countId, `${items.length} ${items.length === 1 ? 'entry' : 'entries'}`);
    $(targetId).innerHTML = items.length ? items.map(item => `<article class="catalog-card panel"><div class="catalog-top"><span class="catalog-token">ID</span><span class="rarity-tag ${item.rarity==='featured'?'rarity-featured':item.rarity==='ultra_rare'?'rarity-ultra':''}">${esc(rarityLabel(item.rarity))}</span></div><div class="catalog-art-box"><img class="catalog-art" src="${itemImageUrl(item.item_id)}" alt="${esc(item.name)}" loading="lazy"></div><b>${esc(item.name)}</b><div class="mono muted">${esc(item.item_id)}</div>${itemArtworkNote(item)}<div class="catalog-foot"><span>${esc(categoryLabels[category])}</span><span class="tiny">ROCKS</span></div>${itemLookupLinks(item)}</article>`).join('') : '<div class="empty-state panel">No local catalogue entries configured for this module.</div>';
  }
  async function refreshModuleResults() {
    try {
      const data = await api('/api/results?limit=500');
      const rows = data.results || [];
      renderModuleResults('evo', rows.filter(r => r.event_key === 'evo'), 'evoLatestDraws');
      renderModuleResults('ghost', rows.filter(r => r.event_key === 'ghost'), 'ghostLatestDraws');
    } catch (_) {}
  }
  function renderModuleResults(eventKey, rows, targetId) {
    const list = $(targetId);
    list.innerHTML = rows.length ? rows.slice(0, 12).map(r => `<article class="record-card panel draw-row"><img class="draw-art" src="${itemImageUrl(r.item_id)}" alt="${esc(r.item_name)}" loading="lazy"><div class="record-main"><b>${esc(r.item_name)}</b><div class="tiny muted">${esc(r.event_name)} · ID ${esc(r.item_id)}</div><div class="tiny muted">${esc(r.region_flag || '🌐')} ${esc(r.region_name || r.region_code || 'Region')} · ${esc(formatDate(r.created_at))}</div></div><span class="verified-badge">VERIFIED</span></article>`).join('') : `<div class="empty-state panel">No verified ${eventKey === 'evo' ? 'Evo' : 'Ghost'} results are available. This workspace is waiting for an authorized live connector.</div>`;
  }
  async function runDedicatedModuleSpin(moduleKey) {
    const message = $(`${moduleKey === 'evo' ? 'evo' : 'ghost'}SpinMessage`);
    if (message) {
      message.classList.remove('hidden');
      message.classList.add('error');
      message.textContent = 'No authorized live game connector is configured. No request was sent and no result was created.';
    }
    showToast('Live connector required. No spin was sent.', true);
  }
  function availabilityDetails(eventKey, regionCode) {
    const event = events.find(e => e.key === eventKey);
    const region = regions.find(r => r.code === regionCode);
    if (!event || !region) return {available:false, event:null, region, names:[]};
    const supported = Array.isArray(event.supported_regions) ? event.supported_regions : [];
    const names = supported.map(code => regions.find(r => r.code === code)?.name || code);
    const regionConfigured = supported.includes(regionCode);
    const itemCount = catalog.filter(item => item.category === eventKey).length;
    const catalogComplete = event.catalog_complete !== false && itemCount > 0;
    return {available:regionConfigured && catalogComplete, regionConfigured, catalogComplete, itemCount, event, region, names};
  }
  function setAvailabilityPanel(panelId, buttonId, eventKey, regionCode, accountSelectId) {
    const panel = $(panelId), button = $(buttonId);
    if (!panel || !button) return;
    const info = availabilityDetails(eventKey, regionCode);
    const evtName = info.event?.event_name_by_region?.[regionCode] || info.event?.name || 'Selected event';
    const regionName = info.region?.name || regionCode || 'selected server';
    const eventNo = info.event?.event_number_by_region?.[regionCode] || info.event?.event_number || '';
    const eventExtra = eventNo ? ` · Event ${esc(eventNo)}` : '';
    button.disabled = true;
    button.setAttribute('aria-disabled', 'true');
    button.title = 'An authorized live connector is not configured';
    if (!info.event) {
      panel.className = 'availability-box availability-blocked';
      panel.innerHTML = '<b>EVENT METADATA UNAVAILABLE</b><p>Refresh the event catalogue before continuing.</p>';
      return;
    }
    panel.className = 'availability-box availability-blocked';
    const regionNote = info.regionConfigured
      ? `The supplied reference data lists <strong>${esc(regionName)}</strong> for <strong>${esc(evtName)}</strong>${eventExtra}.`
      : `The supplied reference data does not list a configuration for <strong>${esc(regionName)}</strong> for <strong>${esc(evtName)}</strong>.`;
    panel.innerHTML = `<div class="availability-status"><span class="availability-icon">!</span><div><b>LIVE GAME CONNECTOR NOT CONFIGURED</b><p>${regionNote}</p><p>The item catalogue and payload references are available for inspection, but the app will not fabricate a reward or send requests to private game endpoints.</p><small>Spin actions are disabled until a documented, authorized API adapter is configured and verified.</small></div></div>`;
  }
  function refreshAvailability() {
    if (!events.length || !regions.length) return;
    if ($('spinEvent') && $('spinRegion')) {
      setAvailabilityPanel('spinAvailability','spinBtn',$('spinEvent').value,$('spinRegion').value,'spinAccount');
    }
    if ($('evoRegion')) setAvailabilityPanel('evoAvailability','evoSpinBtn','evo',$('evoRegion').value,'evoAccount');
    if ($('ghostRegion')) setAvailabilityPanel('ghostAvailability','ghostSpinBtn','ghost',$('ghostRegion').value,'ghostAccount');
  }
  function syncDrawMode() {
    const m4a1 = $('spinEvent').value === 'm4a1';
    const bonus = $('spinCount').querySelector('option[value="11"]');
    bonus.disabled = !m4a1;
    if (!m4a1 && $('spinCount').value === '11') $('spinCount').value = '1';
  }
  async function doSpin() {
    const box = $('spinMessage');
    box.classList.remove('hidden');
    box.classList.add('error');
    box.textContent = 'No authorized live game connector is configured. No request was sent and no result was created.';
    showToast('Live connector required. No spin was sent.', true);
  }
  function openReveal(items) {
    revealQueue = Array.isArray(items) ? items : [];
    revealIndex = 0;
    if (!revealQueue.length) return;
    $('revealOverlay').classList.remove('hidden');
    document.body.classList.add('reveal-open');
    renderReveal();
  }
  function renderReveal() {
    const item = revealQueue[revealIndex];
    if (!item) return closeReveal();
    const ultra = item.rarity === 'ultra_rare';
    const overlay = $('revealOverlay');
    overlay.classList.toggle('reveal-ultra', ultra);
    const art = $('revealArt');
    art.onerror = () => { art.onerror = null; art.src = '/static/item-placeholder.svg'; };
    art.src = itemImageUrl(item.item_id); art.alt = item.item_name || 'Free Fire item';
    setText('revealHeadline', ultra ? 'CONGRATULATIONS!' : 'DROP REVEALED');
    setText('revealTier', ultra ? '✦ ULTRA RARE ✦' : rarityLabel(item.rarity).toUpperCase());
    setText('revealName', item.item_name || 'Unknown item');
    setText('revealId', `ITEM ID · ${item.item_id || 'N/A'}`);
    setText('revealEvent', item.event_name || 'ROCKS Spinner');
    setText('revealCounter', `DROP ${revealIndex + 1} / ${revealQueue.length} · VERIFIED`);
    setText('revealNext', revealIndex + 1 < revealQueue.length ? 'NEXT DROP  →' : 'DONE  ✓');
    if (ultra && userPreferences.vibration_enabled !== false && navigator.vibrate) { try { navigator.vibrate([130, 60, 130, 60, 300]); } catch (_) {} }
  }
  function nextReveal() {
    if (revealIndex + 1 < revealQueue.length) { revealIndex += 1; renderReveal(); }
    else closeReveal();
  }
  function closeReveal() {
    $('revealOverlay').classList.add('hidden');
    document.body.classList.remove('reveal-open');
    revealQueue = []; revealIndex = 0;
    if (navigator.vibrate) { try { navigator.vibrate(0); } catch (_) {} }
  }
  function renderCatalog() {
    const categories = ['all', 'favorites', ...new Set([...events.map(e => e.key), ...catalog.map(x => x.category)])];
    $('catalogFilters').innerHTML = categories.map(c => `<button class="filter-chip ${c===activeCatalogCategory?'selected':''}" data-filter-category="${esc(c)}">${c==='all'?'All IDs':c==='favorites'?'★ Favorites':esc(categoryLabels[c] || c)}</button>`).join('');
    $('catalogFilters').querySelectorAll('[data-filter-category]').forEach(b => b.addEventListener('click', () => {activeCatalogCategory=b.dataset.filterCategory; renderCatalog(); persistUserPreference('catalog_category',activeCatalogCategory);}));
    const search = ($('catalogSearch')?.value || '').trim().toLowerCase();
    const filtered = catalog.filter(item => {
      const categoryMatch = activeCatalogCategory==='all' || (activeCatalogCategory==='favorites' ? !!item.favorite : item.category===activeCatalogCategory);
      const searchMatch = !search || `${item.name} ${item.item_id} ${item.category}`.toLowerCase().includes(search);
      return categoryMatch && searchMatch;
    });
    const shown = filtered;
    setText('catalogCount', `${catalog.length} IDs`);
    setText('catalogSearchCount', `${shown.length} shown`);
    $('catalogAdminInline').classList.toggle('hidden', !isStaff);
    $('catalogList').innerHTML = shown.length ? shown.map(item => `<article class="catalog-card panel"><div class="catalog-top"><span class="catalog-token">ID</span><span class="rarity-tag ${item.rarity==='featured'?'rarity-featured':item.rarity==='ultra_rare'?'rarity-ultra':''}">${esc(rarityLabel(item.rarity))}</span></div><button class="favorite-btn ${item.favorite?'is-favorite':''}" data-favorite-category="${esc(item.category)}" data-favorite-item="${esc(item.item_id)}" aria-pressed="${item.favorite?'true':'false'}" aria-label="${item.favorite?'Remove from':'Add to'} favourites">${item.favorite?'★':'☆'}</button><div class="catalog-art-box"><img class="catalog-art" src="${itemImageUrl(item.item_id)}" alt="${esc(item.name)}" loading="lazy"></div><b>${esc(item.name)}</b><div class="mono muted">${esc(item.item_id)}</div>${itemArtworkNote(item)}<div class="catalog-foot"><span>${esc(categoryLabels[item.category] || item.category)}</span><span class="tiny">#${item.id}</span></div>${itemLookupLinks(item)}${isStaff ? `<button class="btn btn-mini btn-danger catalog-remove" data-delete-catalog="${item.id}">Remove ID</button>` : ''}</article>`).join('') : '<div class="empty-state panel">No catalogue IDs match your filters.</div>';
    $('catalogList').querySelectorAll('[data-delete-catalog]').forEach(b=>b.addEventListener('click',()=>deleteCatalog(Number(b.dataset.deleteCatalog))));
    $('catalogList').querySelectorAll('[data-favorite-item]').forEach(b=>b.addEventListener('click',()=>toggleFavorite(b.dataset.favoriteCategory,b.dataset.favoriteItem, b.getAttribute('aria-pressed')==='true')));
    if (isStaff) renderAdminCatalog();
  }
  async function toggleFavorite(category, itemId, alreadyFavorite) {
    try {
      if (alreadyFavorite) await api(`/api/favorites/${encodeURIComponent(category)}/${encodeURIComponent(itemId)}`, {method:'DELETE'});
      else await api('/api/favorites',{method:'POST',body:JSON.stringify({category,item_id:itemId})});
      const item = catalog.find(x=>x.category===category && String(x.item_id)===String(itemId));
      if (item) item.favorite = !alreadyFavorite;
      renderCatalog();
      showToast(alreadyFavorite ? 'Removed from favourites' : 'Added to favourites');
    } catch(e) { showToast(e.message,true); }
  }
  async function loadResults(append=false) {
    const params = new URLSearchParams({limit:String(resultLimit),offset:String(append?resultOffset:0)});
    const search = ($('resultSearch')?.value || '').trim();
    const eventKey = $('resultEventFilter')?.value || '';
    const regionCode = $('resultRegionFilter')?.value || '';
    if (search) params.set('q',search);
    if (eventKey) params.set('event_key',eventKey);
    if (regionCode) params.set('region_code',regionCode);
    const data = await api(`/api/results?${params.toString()}`); const rows = data.results || [];
    if (!append) resultOffset = 0;
    resultOffset += rows.length;
    resultTotal = Number(data.total || 0);
    setText('resultTotal', `${resultTotal} result${resultTotal===1?'':'s'}`);
    $('loadMoreResultsBtn').classList.toggle('hidden', resultOffset >= resultTotal || rows.length===0);
    const list = $('resultList');
    applyResultsView(userPreferences.result_view || 'cards');
    const cards = rows.map(r => `<article class="result-card panel"><img class="result-art" src="${itemImageUrl(r.item_id)}" alt="${esc(r.item_name)}" loading="lazy"><div class="result-main"><div class="result-title">${esc(r.item_name)}</div><div class="small muted">${esc(r.event_name)} · ${esc(r.label || 'Account')} (${esc(r.game_uid || '')})</div><div class="tiny muted">${esc(r.region_flag || '🌐')} ${esc(r.region_name || r.region_code || '')} · Item ID ${esc(r.item_id)} · ${esc(formatDate(r.created_at))}</div><div class="tiny ${r.rarity==='ultra_rare'?'ultra-label':'muted'}">${esc(rarityLabel(r.rarity))}</div></div><span class="verified-badge">VERIFIED</span></article>`).join('');
    if (!rows.length && !append) list.innerHTML = '<div class="empty-state panel"><span>▤</span><b>No verified results</b><p>Live results will appear here only after an authorized game connector is configured.</p></div>';
    else if (rows.length) { if (append) list.insertAdjacentHTML('beforeend', cards); else list.innerHTML=cards; }
    if (!append) await refreshModuleResults();
  }
  function switchTab(tab) {
    const validPanel = $(`tab-${tab}`);
    if (tab !== 'admin' && !validPanel) return;
    document.querySelectorAll('#tabs [data-tab]').forEach(button => {
      const target = button.dataset.tab;
      const isActive = target === tab || (target === 'more' && ['activator','evo','ghost','themes','accounts','catalog','results','settings','privacy','admin'].includes(tab));
      button.classList.toggle('active', isActive);
      button.setAttribute('aria-current', isActive ? 'page' : 'false');
    });
    document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.add('hidden'));
    if (tab === 'admin') {
      if (!isStaff) { showToast('Admin access is restricted.', true); return; }
      $('adminPanel').classList.remove('hidden');
      $('adminPanel').scrollIntoView({behavior:'smooth',block:'start'});
      return;
    }
    $('adminPanel')?.classList.add('hidden');
    validPanel.classList.remove('hidden');
    if (tab === 'results') applyResultsView(userPreferences.result_view || 'cards');
    if (tab === 'profile') applyProfileWidgets();
    if (tab === 'home') applyDashboardWidgets();
    if (tab === 'more') $('openAdminDestination')?.classList.toggle('hidden', !isStaff);
    window.scrollTo({top:0,behavior:'smooth'});
  }
  const splitPrefList = value => String(value || '').split(',').map(x=>x.trim()).filter(Boolean);
  function applyDashboardWidgets() {
    const chosen = new Set(splitPrefList(userPreferences.dashboard_widgets || 'accounts,gen,activator,evo,ghost,spinner,catalog,results'));
    document.querySelectorAll('[data-dashboard-widget]').forEach(card => card.classList.toggle('hidden', !chosen.has(card.dataset.dashboardWidget)));
    document.querySelectorAll('[data-pref-list="dashboard_widgets"]').forEach(box => { box.checked = chosen.has(box.value); });
  }
  function applyProfileWidgets() {
    const chosen = new Set(splitPrefList(userPreferences.profile_widgets || 'identity,usage,accounts,draws'));
    document.querySelectorAll('[data-profile-widget]').forEach(widget => widget.classList.toggle('hidden', !chosen.has(widget.dataset.profileWidget)));
    document.querySelectorAll('[data-pref-list="profile_widgets"]').forEach(box => { box.checked = chosen.has(box.value); });
  }
  function applyResultsView(view) {
    const normalized = ['cards','list','timeline'].includes(view) ? view : 'cards';
    userPreferences.result_view = normalized;
    const list = $('resultList');
    if (list) { list.classList.remove('results-view-cards','results-view-list','results-view-timeline'); list.classList.add(`results-view-${normalized}`); }
    document.querySelectorAll('[data-result-view]').forEach(button => {
      const selected = button.dataset.resultView === normalized;
      button.classList.toggle('selected', selected); button.setAttribute('aria-pressed', String(selected));
    });
  }
  function renderPersonalizationSettings() {
    applyDashboardWidgets(); applyProfileWidgets(); applyResultsView(userPreferences.result_view || 'cards');
  }
  function setupPersonalizationSettings() {
    document.querySelectorAll('[data-pref-list]').forEach(box => box.addEventListener('change', () => {
      const key = box.dataset.prefList;
      const selector = `[data-pref-list="${key}"]`;
      const chosen = [...document.querySelectorAll(selector)].filter(node=>node.checked).map(node=>node.value);
      if (!chosen.length) {
        box.checked = true; showToast('Keep at least one widget selected.', true); return;
      }
      const value = chosen.join(',');
      userPreferences[key] = value;
      if (key === 'dashboard_widgets') applyDashboardWidgets(); else applyProfileWidgets();
      persistUserPreference(key, value);
    }));
    document.querySelectorAll('[data-result-view]').forEach(button => button.addEventListener('click', () => {
      applyResultsView(button.dataset.resultView); persistUserPreference('result_view', button.dataset.resultView);
    }));
    $('resetDashboardWidgets')?.addEventListener('click', () => {
      const value='accounts,gen,activator,evo,ghost,spinner,catalog,results';
      userPreferences.dashboard_widgets=value; applyDashboardWidgets(); persistUserPreference('dashboard_widgets',value); showToast('Dashboard shortcuts restored');
    });
    $('resetProfileWidgets')?.addEventListener('click', () => {
      const value='identity,usage,accounts,draws';
      userPreferences.profile_widgets=value; applyProfileWidgets(); persistUserPreference('profile_widgets',value); showToast('All profile widgets shown');
    });
  }
  async function detectAdmin() {
    try {
      const data = await api('/api/admin/overview'); isStaff=true; canManageAdmins=!!data.can_manage_admins;
      $('adminPanel').classList.remove('hidden');
      $('openAdminDestination')?.classList.remove('hidden');
      renderCatalog();
      renderAdminStats(data);
      $('adminsTabBtn').classList.toggle('hidden', !canManageAdmins);
      await Promise.all([loadAdminUsers(), loadAdminResults(), renderAdminCatalog(), loadAuditLogs()]);
      if (canManageAdmins) await loadAdmins();
    } catch (_) { isStaff=false; canManageAdmins=false; $('adminPanel').classList.add('hidden'); $('openAdminDestination')?.classList.add('hidden'); }
  }
  function renderAdminStats(data) {
    const stats = [
      ['USERS',data.users_total],['ACTIVE',data.active_users],['BANNED',data.banned_users],
      ['SAVED PROFILES',data.saved_account_profiles],['TODAY · PROFILES',data.today_account_profiles],['TODAY · VERIFIED DRAWS',data.today_verified_draws]
    ];
    $('adminStats').innerHTML = stats.map(([name,num]) => `<div class="stat-card panel"><div class="stat-label">${esc(name)}</div><div class="stat-number">${esc(num)}</div></div>`).join('');
  }
  async function loadAdminUsers() {
    const data = await api('/api/admin/users'); const list = $('adminUsersList');
    list.innerHTML = data.users.length ? data.users.map(u => `<article class="record-card panel admin-user"><img class="admin-avatar" src="/api/avatar/${u.telegram_id}" alt="User avatar"><div class="record-main"><b>${esc(u.first_name || 'ROCKS user')} ${u.username?`<span class="muted small">@${esc(u.username)}</span>`:''}</b><div class="tiny muted">Account ${esc(u.telegram_id)} · user #${u.id}</div><div class="tiny muted">${u.accounts_count} profiles · ${u.draws_count} verified draws · seen ${esc(formatDate(u.last_seen_at))}</div><span class="user-state ${u.status==='banned'?'state-banned':''}">${esc(u.status)}${u.is_admin?' · admin':''}</span></div><div class="admin-actions"><button data-detail-user="${u.id}" class="btn btn-mini btn-ghost">Details</button>${u.is_admin?'':`<button data-user-action="${u.status==='banned'?'unban':'ban'}" data-user-id="${u.id}" class="btn btn-mini ${u.status==='banned'?'btn-primary':'btn-danger'}">${u.status==='banned'?'Unban':'Ban'}</button>`}</div></article>`).join('') : '<div class="empty-state panel">No users yet.</div>';
    list.querySelectorAll('.admin-avatar').forEach(img => { img.onerror = () => { img.src = '/static/avatar-placeholder.svg'; }; });
    list.querySelectorAll('[data-user-action]').forEach(b=>b.addEventListener('click',()=>moderateUser(Number(b.dataset.userId),b.dataset.userAction)));
    list.querySelectorAll('[data-detail-user]').forEach(b=>b.addEventListener('click',()=>showUserDetails(Number(b.dataset.detailUser))));
  }
  async function moderateUser(id, action) {
    if (!confirm(`${action==='ban'?'Ban':'Restore'} access for this user?`)) return;
    try { await api(`/api/admin/users/${id}/${action}`,{method:'POST'}); await loadAdminUsers(); const overview=await api('/api/admin/overview'); renderAdminStats(overview); showToast(`User ${action==='ban'?'banned':'restored'}`); }
    catch(e){showToast(e.message,true);}
  }
  async function showUserDetails(id) {
    try {
      const d = await api(`/api/admin/user/${id}`);
      const text = `${d.user.first_name||'User'}${d.user.username?' (@'+d.user.username+')':''}\nAccount ID: ${d.user.telegram_id}\nStatus: ${d.user.status}\nDaily profiles: ${d.usage.used}/${d.usage.limit}\nSaved profiles: ${d.accounts.length}\nDemo results: ${d.results.length}`;
      alert(text);
    } catch(e){showToast(e.message,true);}
  }
  async function loadAdminResults() {
    const data = await api('/api/admin/results'); const list=$('adminResultsList');
    list.innerHTML = data.results.length ? data.results.map(r=>`<article class="result-card panel"><img class="result-art" src="${itemImageUrl(r.item_id)}" alt="${esc(r.item_name)}" loading="lazy"><div class="result-main"><div class="result-title">${esc(r.item_name)}</div><div class="small muted">${esc(r.first_name||'User')} ${r.username?'@'+esc(r.username):''} · Account ${esc(r.telegram_id)}</div><div class="tiny muted">${esc(r.event_name)} · ${esc(r.region_flag || '🌐')} ${esc(r.region_name || r.region_code || 'India')} · ${esc(r.game_uid)} · ${esc(formatDate(r.created_at))}</div><div class="tiny ${r.rarity==='ultra_rare'?'ultra-label':'muted'}">${esc(rarityLabel(r.rarity))}</div></div><span class="verified-badge">VERIFIED</span></article>`).join(''):'<div class="empty-state panel">No verified results yet.</div>';
  }
  async function renderAdminCatalog() {
    if (!isStaff) return;
    const list=$('adminCatalogList');
    list.innerHTML = catalog.length ? catalog.map(i=>`<article class="record-card panel"><img class="admin-item-art" src="${itemImageUrl(i.item_id)}" alt="${esc(i.name)}" loading="lazy"><div class="record-main"><b>${esc(i.name)}</b><div class="mono muted">${esc(i.item_id)} · ${esc(categoryLabels[i.category]||i.category)}</div><div class="tiny ${i.rarity==='ultra_rare'?'ultra-label':'muted'}">${esc(rarityLabel(i.rarity))} · catalogue row #${i.id}</div></div><button class="btn btn-mini btn-danger" data-delete-catalog="${i.id}">Remove</button></article>`).join('') : '<div class="empty-state panel">No IDs.</div>';
    list.querySelectorAll('[data-delete-catalog]').forEach(b=>b.addEventListener('click',()=>deleteCatalog(Number(b.dataset.deleteCatalog))));
  }
  async function reloadCatalog() { const data=await api('/api/catalog'); catalog=data.items||[]; renderCatalog(); if(isStaff) renderAdminCatalog(); }
  async function addCatalog() {
    clearError('catalogAdminError');
    const category=$('newIdCategory').value, item_id=$('newItemId').value.trim(), name=$('newItemName').value.trim(), rarity=$('newItemRarity').value;
    if(!item_id||!name) return errorAt('catalogAdminError','Enter an item ID and display name.');
    try { await api('/api/admin/catalog',{method:'POST',body:JSON.stringify({category,item_id,name,rarity})}); $('newItemId').value=''; $('newItemName').value=''; await reloadCatalog(); showToast('Catalogue ID added'); }
    catch(e){errorAt('catalogAdminError',e.message);}
  }
  async function addInlineCatalog() {
    clearError('inlineCatalogError');
    const category=$('inlineIdCategory').value, item_id=$('inlineItemId').value.trim(), name=$('inlineItemName').value.trim(), rarity=$('inlineItemRarity').value;
    if(!item_id||!name) return errorAt('inlineCatalogError','Enter an item ID and display name.');
    try { await api('/api/admin/catalog',{method:'POST',body:JSON.stringify({category,item_id,name,rarity})}); $('inlineItemId').value=''; $('inlineItemName').value=''; await reloadCatalog(); showToast('Catalogue ID added'); }
    catch(e){errorAt('inlineCatalogError',e.message);}
  }
  async function importCatalogJson() {
    clearError('catalogImportError');
    const file = $('catalogImportFile').files?.[0];
    if (!file) return errorAt('catalogImportError', 'Choose a JSON file first.');
    if (file.size > 1024 * 1024) return errorAt('catalogImportError', 'The JSON file must be 1 MB or smaller.');
    const button = $('importCatalogBtn'); button.disabled = true;
    try {
      const parsed = JSON.parse(await file.text());
      const items = Array.isArray(parsed) ? parsed : parsed?.items;
      if (!Array.isArray(items) || !items.length) throw new Error('Use a non-empty JSON array or an object containing an items array.');
      if (items.length > 200) throw new Error('Import at most 200 entries at a time.');
      const data = await api('/api/admin/catalog/import', {method:'POST', body:JSON.stringify({items})});
      $('catalogImportFile').value = '';
      await reloadCatalog();
      showToast(data.message || `Imported ${data.added} entries`);
    } catch (e) {
      errorAt('catalogImportError', e instanceof SyntaxError ? 'Invalid JSON file.' : (e.message || 'Import failed.'));
    } finally { button.disabled = false; }
  }
  async function exportAdminCatalog() {
    const button = $('exportCatalogBtn'); button.disabled = true;
    try {
      const ticket = await api('/api/admin/catalog/download-ticket', {method:'POST'});
      const link = document.createElement('a');
      link.href = ticket.url; link.download = 'rocks-catalogue.csv'; link.rel = 'noopener';
      document.body.appendChild(link); link.click(); link.remove();
      showToast('Admin catalogue CSV export is ready');
    } catch (e) { showToast(e.message || 'Catalogue export failed', true); }
    finally { button.disabled = false; }
  }
  async function deleteCatalog(id) {
    if(!confirm('Remove this catalogue ID?')) return;
    try { await api(`/api/admin/catalog/${id}`,{method:'DELETE'}); await reloadCatalog(); showToast('Catalogue ID removed'); }
    catch(e){showToast(e.message,true);}
  }
  async function loadAdmins() {
    const data=await api('/api/admin/admins'); const list=$('adminsList');
    list.innerHTML=data.admins.length?data.admins.map(a=>`<article class="record-card panel"><div class="record-icon">♙</div><div class="record-main"><b>Account ID ${esc(a.telegram_id)}</b><div class="tiny muted">Role: ${esc(a.role)} · added ${esc(formatDate(a.created_at))}</div></div>${a.role==='owner'?'':`<button data-remove-admin="${a.telegram_id}" class="btn btn-mini btn-danger">Remove</button>`}</article>`).join(''):'<div class="empty-state panel">No administrators.</div>';
    list.querySelectorAll('[data-remove-admin]').forEach(b=>b.addEventListener('click',()=>removeAdmin(Number(b.dataset.removeAdmin))));
  }
  async function addAdmin() {
    clearError('adminManageError'); const val=$('newAdminId').value.trim();
    if(!/^\d+$/.test(val)) return errorAt('adminManageError','Enter a numeric sign-in provider ID.');
    try { await api('/api/admin/admins',{method:'POST',body:JSON.stringify({telegram_id:Number(val)})}); $('newAdminId').value=''; await loadAdmins(); showToast('Admin access updated'); }
    catch(e){errorAt('adminManageError',e.message);}
  }
  async function removeAdmin(id) {
    if(!confirm(`Remove admin access for account ID ${id}?`)) return;
    try { await api(`/api/admin/admins/${id}`,{method:'DELETE'}); await loadAdmins(); showToast('Admin access removed'); }
    catch(e){showToast(e.message,true);}
  }
  async function loadAuditLogs() {
    const list = $('auditLogList');
    if (!list || !isStaff) return;
    try {
      const data = await api('/api/admin/audit-logs?limit=100');
      const rows = data.events || [];
      list.innerHTML = rows.length ? rows.map(row => {
        const detail = row.details && Object.keys(row.details).length ? JSON.stringify(row.details) : '';
        return `<article class="record-card panel audit-row"><div class="record-icon">✓</div><div class="record-main"><b>${esc(row.action.replace(/_/g,' '))}</b><div class="tiny muted">Actor ${esc(row.actor_telegram_id)} · ${esc(row.target_type || 'system')} ${esc(row.target_id || '')}</div><div class="tiny muted">${esc(formatDate(row.created_at))}${detail?' · '+esc(detail):''}</div></div><span class="admin-tag">AUDIT</span></article>`;
      }).join('') : '<div class="empty-state panel"><b>No administrative actions logged yet</b><p>Future staff actions will appear here.</p></div>';
    } catch (e) { list.innerHTML = `<div class="empty-state panel">${esc(e.message)}</div>`; }
  }
  async function startPrivateDownload(format, buttonId) {
    const button = $(buttonId);
    if (button) button.disabled = true;
    try {
      const data = await api('/api/me/download-ticket', {method:'POST',body:JSON.stringify({format})});
      // The capability URL is single-use and expires after two minutes. A direct
      // navigation lets browsers and Android WebView's DownloadListener handle it.
      const link = document.createElement('a');
      link.href = data.url;
      link.download = format === 'csv' ? 'rocks-demo-results.csv' : 'rocks-user-export.json';
      link.rel = 'noopener';
      document.body.appendChild(link); link.click(); link.remove();
      showToast('Your private export is ready');
    } catch (e) { showToast(e.message || 'Export failed', true); }
    finally { if (button) button.disabled = false; }
  }
  async function deleteMyProfile() {
    const confirmation = prompt('This permanently deletes your ROCKS profile, saved UID profiles, favourites and demo history. Type DELETE to continue.');
    if (confirmation !== 'DELETE') { if (confirmation !== null) showToast('Deletion cancelled'); return; }
    const button = $('deleteMyProfileBtn'); button.disabled = true;
    try {
      await api('/api/me', {method:'DELETE'});
      signOut(false);
      showToast('Your ROCKS profile and app data were deleted');
    } catch (e) {
      errorAt('privacyError', e.message || 'Unable to delete the profile.');
    } finally { if ($('deleteMyProfileBtn')) $('deleteMyProfileBtn').disabled = false; }
  }
  const MATRIX_CHARS = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロ正在连接系统在线权限已验证';
  function resizeMatrix() {
    const canvas = $('matrixCanvas'); if (!canvas) return;
    const ctx = canvas.getContext('2d');
    matrixWidth = Math.max(1, window.innerWidth); matrixHeight = Math.max(1, window.innerHeight);
    canvas.width = matrixWidth; canvas.height = matrixHeight;
    ctx.font = '14px monospace';
    matrixDrops = Array.from({length:Math.ceil(matrixWidth/14)},()=>Math.random()*-matrixHeight/14);
  }
  function drawMatrix() {
    matrixRaf = 0;
    if (document.body.dataset.theme !== 'hacker' || document.hidden) return;
    const canvas = $('matrixCanvas'); if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = 'rgba(0, 7, 2, 0.12)'; ctx.fillRect(0,0,matrixWidth,matrixHeight);
    ctx.font = '14px monospace'; ctx.fillStyle = '#20ff72';
    for (let i=0; i<matrixDrops.length; i++) {
      const char = MATRIX_CHARS[Math.floor(Math.random()*MATRIX_CHARS.length)];
      ctx.fillText(char, i*14, matrixDrops[i]*14);
      if (matrixDrops[i]*14>matrixHeight && Math.random()>.975) matrixDrops[i]=0;
      matrixDrops[i]+=.55+Math.random()*.5;
    }
    matrixTick++;
    matrixRaf = window.requestAnimationFrame(drawMatrix);
  }
  function startMatrix() {
    const canvas = $('matrixCanvas'); if (!canvas) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    if (!matrixWidth) resizeMatrix();
    if (!matrixRaf) matrixRaf = window.requestAnimationFrame(drawMatrix);
  }
  function stopMatrix() {
    if (matrixRaf) window.cancelAnimationFrame(matrixRaf);
    matrixRaf = 0;
    const canvas = $('matrixCanvas');
    if (canvas) { const ctx=canvas.getContext('2d'); ctx.clearRect(0,0,canvas.width,canvas.height); }
  }
  async function loadUserPreferences() {
    try {
      const prefs = await api('/api/preferences');
      userPreferences = {...userPreferences, ...prefs};
      userPreferences.vibration_enabled = prefs.vibration_enabled !== false;
      userPreferences.dashboard_widgets = prefs.dashboard_widgets || 'accounts,gen,activator,evo,ghost,spinner,catalog,results';
      userPreferences.profile_widgets = prefs.profile_widgets || 'identity,usage,accounts,draws';
      userPreferences.result_view = ['cards','list','timeline'].includes(prefs.result_view) ? prefs.result_view : 'cards';
      activeCatalogCategory = userPreferences.catalog_category || 'all';
      if ($('catalogSearch')) $('catalogSearch').value = userPreferences.catalog_search || '';
      if ($('resultSearch')) $('resultSearch').value = userPreferences.results_search || '';
      if ($('resultEventFilter')) $('resultEventFilter').value = userPreferences.results_event || '';
      if ($('resultRegionFilter')) $('resultRegionFilter').value = userPreferences.results_region || '';
      if ($('vibrationEnabled')) $('vibrationEnabled').checked = userPreferences.vibration_enabled;
      applyTheme(userPreferences.theme || 'hacker');
      renderGenMode(userPreferences.gen_mode || 'gen_only');
      renderPersonalizationSettings();
    } catch (e) {
      // Preference loading is non-critical; keep safe account-local defaults if offline.
      userPreferences = {theme:'hacker', region_general:'IND', region_evo:'ME', region_ghost:'TW', catalog_category:'all', catalog_search:'', results_search:'', results_event:'', results_region:'', vibration_enabled:true, gen_mode:'gen_only', dashboard_widgets:'accounts,gen,activator,evo,ghost,spinner,catalog,results', profile_widgets:'identity,usage,accounts,draws', result_view:'cards'};
      activeCatalogCategory = 'all';
      if ($('vibrationEnabled')) $('vibrationEnabled').checked = true;
      applyTheme('hacker');
      renderGenMode('gen_only');
      renderPersonalizationSettings();
    }
  }
  function renderGenMode(mode) {
    const normalized = mode === 'gen_plus_activator' ? 'gen_plus_activator' : 'gen_only';
    userPreferences.gen_mode = normalized;
    const only = $('genOnlyModeBtn'), combo = $('genAutoModeBtn');
    if (only) { only.classList.toggle('selected', normalized === 'gen_only'); only.setAttribute('aria-pressed', String(normalized === 'gen_only')); }
    if (combo) { combo.classList.toggle('selected', normalized === 'gen_plus_activator'); combo.setAttribute('aria-pressed', String(normalized === 'gen_plus_activator')); }
    const notice = $('genModeNotice');
    if (notice) {
      if (normalized === 'gen_only') notice.innerHTML = '<span class="notice-icon">ⓘ</span><div><b>Gen Only selected</b><p>Standalone mode selected. The supplied Gen.py source is not executed by this APK.</p></div>';
      else notice.innerHTML = '<span class="notice-icon">🔗</span><div><b>Gen + Auto Activator selected</b><p>Combined mode selected. Generation and activation remain disabled until an authorized, documented API adapter is reviewed and implemented.</p></div>';
    }
  }
  async function loadActivatorStatus() {
    try {
      const data = await api('/api/activator/status');
      setText('activatorStatusBadge', data.status || 'NOT CONNECTED');
      setText('activatorEndpointState', data.endpoint_configured ? (data.endpoint_scheme_valid ? 'HTTPS configured' : 'Invalid scheme') : 'Not configured');
      setText('activatorContractState', data.api_contract_verified ? 'Verified' : 'Not verified');
      setText('activatorExecutionState', data.execution_enabled ? 'Enabled' : 'Disabled');
      setText('activatorStatusMessage', data.message || 'No activation request has been sent.');
      setText('activatorStatusDetail', 'Status checked · No UID, password, or JWT was sent to the endpoint.');
    } catch (e) {
      setText('activatorStatusBadge', 'STATUS UNKNOWN');
      setText('activatorEndpointState', 'Unknown');
      setText('activatorContractState', 'Not verified');
      setText('activatorExecutionState', 'Disabled');
      setText('activatorStatusMessage', 'Unable to check activator configuration. No activation request was sent.');
      setText('activatorStatusDetail', e.message || 'Status request failed.');
    }
  }
  function persistUserPreferences(changes, expectedSession=null) {
    const allowed = ['theme','region_general','region_evo','region_ghost','catalog_category','catalog_search','results_search','results_event','results_region','vibration_enabled','gen_mode','dashboard_widgets','profile_widgets','result_view'];
    const payload = {};
    for (const [key, value] of Object.entries(changes || {})) {
      if (allowed.includes(key)) { userPreferences[key] = value; payload[key] = value; }
    }
    if (!Object.keys(payload).length || !token || !me) return Promise.resolve();
    // Capture the session when changing preferences. A queued write from a prior
    // account can never be silently rebound to the next signed-in Telegram user.
    const sessionToken = expectedSession?.token || token;
    const sessionTelegramId = expectedSession?.telegramId || me.telegram_id;
    if (token !== sessionToken || !me || me.telegram_id !== sessionTelegramId) return Promise.resolve();
    preferencesSaveQueue = preferencesSaveQueue.catch(()=>{}).then(() => api('/api/preferences', {
      method:'PUT', headers:{Authorization:`Bearer ${sessionToken}`}, body:JSON.stringify(payload)
    }));
    return preferencesSaveQueue.catch(() => {
      if (token === sessionToken && me && me.telegram_id === sessionTelegramId) {
        showToast('Preference changed on this screen but could not be saved to your account.', true);
      }
    });
  }
  function persistUserPreference(key, value) { return persistUserPreferences({[key]:value}); }
  function scheduleSearchPreferenceSave(changes) {
    if (!token || !me) return;
    const session = {token, telegramId:me.telegram_id};
    if (!preferenceDebounceSession || preferenceDebounceSession.token !== session.token || preferenceDebounceSession.telegramId !== session.telegramId) {
      pendingPreferenceChanges = {};
      preferenceDebounceSession = session;
    }
    for (const [key, value] of Object.entries(changes || {})) { userPreferences[key] = value; pendingPreferenceChanges[key] = value; }
    clearTimeout(preferenceDebounceTimer);
    preferenceDebounceTimer = setTimeout(() => {
      const pending = pendingPreferenceChanges; const ownerSession = preferenceDebounceSession;
      pendingPreferenceChanges = {}; preferenceDebounceSession = null; preferenceDebounceTimer = 0;
      if (ownerSession && token === ownerSession.token && me && me.telegram_id === ownerSession.telegramId) {
        persistUserPreferences(pending, ownerSession);
      }
    }, 350);
  }
  function applyTheme(theme, notify=false) {
    if (!Object.prototype.hasOwnProperty.call(THEME_INFO, theme)) theme='hacker';
    document.body.dataset.theme = theme;
    const atmosphere=$('hackerAtmosphere');
    if (atmosphere) atmosphere.classList.toggle('hidden',theme!=='hacker');
    const hackerBanner=$('hackerHomeBanner');
    if (hackerBanner) hackerBanner.classList.toggle('hidden',theme!=='hacker');
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content',THEME_INFO[theme].color);
    setText('currentThemeName',THEME_INFO[theme].name.toUpperCase());
    const grid=$('themeGrid');
    if (grid) grid.querySelectorAll('[data-theme-option]').forEach(btn=>{
      const selected=btn.dataset.themeOption===theme;
      btn.classList.toggle('selected',selected); btn.setAttribute('aria-pressed',selected?'true':'false');
    });
    if (theme==='hacker') startMatrix(); else stopMatrix();
    if (notify) showToast(`${THEME_INFO[theme].name} theme applied`);
  }
  function setupThemes() {
    const grid=$('themeGrid'); if (!grid) return;
    grid.querySelectorAll('[data-theme-option]').forEach(btn=>btn.addEventListener('click',()=>{
      const theme = btn.dataset.themeOption;
      applyTheme(theme, true);
      persistUserPreference('theme', theme);
    }));
    applyTheme('hacker');
    window.addEventListener('resize',()=>{if(document.body.dataset.theme==='hacker')resizeMatrix();});
    document.addEventListener('visibilitychange',()=>{
      if(document.hidden) { if(matrixRaf) window.cancelAnimationFrame(matrixRaf); matrixRaf=0; }
      else if(document.body.dataset.theme==='hacker') startMatrix();
    });
  }
  function setupNavigation() {
    $('tabs').querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.tab)));
    document.querySelectorAll('[data-open-tab]').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.openTab)));
    document.querySelectorAll('[data-admin-tab]').forEach(b=>b.addEventListener('click',()=>{
      document.querySelectorAll('[data-admin-tab]').forEach(x=>x.classList.toggle('active',x===b));
      document.querySelectorAll('.admin-subpanel').forEach(x=>x.classList.add('hidden'));
      $(`admin-${b.dataset.adminTab}`).classList.remove('hidden');
      if (b.dataset.adminTab==='audit') loadAuditLogs();
    }));
  }
  $('loginBtn').addEventListener('click', doLogin);
  $('loginCode').addEventListener('keydown', e=>{if(e.key==='Enter')doLogin();});
  $('logoutBtn').addEventListener('click', async()=>{try{await api('/api/logout',{method:'POST'});}catch(_){} signOut();});
  $('addAccountBtn').addEventListener('click',addAccount);
  $('accountUid').addEventListener('keydown',e=>{if(e.key==='Enter')addAccount();});
  $('spinBtn').addEventListener('click',doSpin);
  $('evoSpinBtn').addEventListener('click', () => runDedicatedModuleSpin('evo'));
  $('ghostSpinBtn').addEventListener('click', () => runDedicatedModuleSpin('ghost'));
  $('genOpenAccounts').addEventListener('click', () => switchTab('accounts'));
  $('genOpenActivator').addEventListener('click', () => switchTab('activator'));
  $('genOnlyModeBtn').addEventListener('click', () => { renderGenMode('gen_only'); persistUserPreference('gen_mode','gen_only'); showToast('Gen Only selected'); });
  $('genAutoModeBtn').addEventListener('click', () => { renderGenMode('gen_plus_activator'); persistUserPreference('gen_mode','gen_plus_activator'); showToast('Gen + Auto Activator selected'); });
  $('refreshActivatorStatusBtn').addEventListener('click', () => loadActivatorStatus().then(() => showToast('Activator configuration checked')).catch(e => showToast(e.message, true)));
  $('genCopyName').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText('Gen.py'); setText('genCopyNote', 'Copied: Gen.py'); showToast('Module name copied'); }
    catch (_) { setText('genCopyNote', 'Module name: Gen.py'); showToast('Gen.py'); }
  });
  $('spinEvent').addEventListener('change',()=>{
    applyEventDefaultRegion($('spinEvent').value, true);
    syncDrawMode(); refreshAvailability();
  });
  $('revealNext').addEventListener('click',nextReveal);
  $('revealClose').addEventListener('click',closeReveal);
  $('revealOverlay').addEventListener('click',e=>{if(e.target===$('revealOverlay'))closeReveal();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('revealOverlay').classList.contains('hidden'))closeReveal();if(e.key==='ArrowRight'&&!$('revealOverlay').classList.contains('hidden'))nextReveal();});
  $('refreshResults').addEventListener('click',()=>loadResults().then(()=>showToast('Results refreshed')).catch(e=>showToast(e.message,true)));
  $('loadMoreResultsBtn').addEventListener('click',()=>loadResults(true).catch(e=>showToast(e.message,true)));
  const handleResultFilterChange = () => {
    clearTimeout(resultSearchTimer);
    resultSearchTimer = setTimeout(()=>loadResults().catch(e=>showToast(e.message,true)), 180);
  };
  $('resultSearch').addEventListener('input',()=>{
    handleResultFilterChange();
    scheduleSearchPreferenceSave({results_search:$('resultSearch').value.trim()});
  });
  $('resultEventFilter').addEventListener('change',()=>{
    handleResultFilterChange();
    persistUserPreference('results_event',$('resultEventFilter').value);
  });
  $('resultRegionFilter').addEventListener('change',()=>{
    handleResultFilterChange();
    persistUserPreference('results_region',$('resultRegionFilter').value);
  });
  $('catalogSearch').addEventListener('input',()=>{
    renderCatalog();
    scheduleSearchPreferenceSave({catalog_search:$('catalogSearch').value.trim()});
  });
  $('vibrationEnabled').addEventListener('change',()=>{
    const enabled = $('vibrationEnabled').checked;
    persistUserPreference('vibration_enabled',enabled);
    showToast(enabled ? 'Ultra Rare vibration enabled' : 'Ultra Rare vibration disabled');
  });
  $('exportDataBtn').addEventListener('click',()=>startPrivateDownload('json','exportDataBtn'));
  $('exportResultsBtn').addEventListener('click',()=>startPrivateDownload('csv','exportResultsBtn'));
  $('deleteMyProfileBtn').addEventListener('click',deleteMyProfile);
  $('privacyLogoutBtn').addEventListener('click',async()=>{try{await api('/api/logout',{method:'POST'});}catch(_){}signOut();});
  $('refreshAuditBtn').addEventListener('click',()=>loadAuditLogs().then(()=>showToast('Audit log refreshed')).catch(e=>showToast(e.message,true)));
  $('refreshUsers').addEventListener('click',()=>loadAdminUsers().catch(e=>showToast(e.message,true)));
  $('addCatalogBtn').addEventListener('click',addCatalog);
  $('importCatalogBtn').addEventListener('click',importCatalogJson);
  $('exportCatalogBtn').addEventListener('click',exportAdminCatalog);
  $('inlineAddCatalogBtn').addEventListener('click',addInlineCatalog);
  $('addAdminBtn').addEventListener('click',addAdmin);
  setupNavigation();
  setupThemes();
  setupPersonalizationSettings();
  $('retryConnectionBtn')?.addEventListener('click', async () => {
    const button = $('retryConnectionBtn'); button.disabled = true; button.textContent = 'Checking connection…';
    try {
      if (token) { await loadDashboard(); showToast('ROCKS is back online'); }
      else { await fetch('/api/regions', {cache:'no-store'}); showLogin(); showToast('Connection restored. Sign in to continue.'); }
    } catch (error) { showOfflineView(error); }
    finally { button.disabled = false; button.textContent = 'Retry connection ↻'; }
  });
  window.addEventListener('offline', () => showOfflineView());
  window.addEventListener('online', () => { if (!$('offlineView').classList.contains('hidden')) setText('offlineStatusText','Connection restored. Select Retry to reload your private workspace.'); });
  if (navigator.onLine === false) showOfflineView();
  else if (token) loadDashboard().catch(error=>{ if (isNetworkFailure(error)) showOfflineView(error); else signOut(false); });
  else showLogin();
})();
