from __future__ import annotations

import hashlib
import csv
import io
import json
import os
import secrets
import sqlite3
import shutil
import string
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")
DATA_DIR = Path(os.getenv("ROCKS_DATA_DIR", str(ROOT / "data"))).resolve()
DB_PATH = DATA_DIR / "rocks.sqlite3"
USERS_DIR = DATA_DIR / "users"
AVATARS_DIR = DATA_DIR / "avatars"
STATIC_DIR = ROOT / "backend" / "static"
DAILY_ACCOUNT_LIMIT = int(os.getenv("DAILY_ACCOUNT_LIMIT", "1111"))
SESSION_DAYS = int(os.getenv("SESSION_DAYS", "7"))
CODE_MINUTES = int(os.getenv("LOGIN_CODE_MINUTES", "5"))
ENABLE_API_DOCS = os.getenv("ROCKS_ENABLE_API_DOCS", "True").lower() in {"1", "true", "yes"}
# Optional endpoint hint for the future reviewed activator integration. This build does not call it.
ROCKS_ACTIVATOR_API_URL = os.getenv("ROCKS_ACTIVATOR_API_URL", "").strip()

for _p in (DATA_DIR, USERS_DIR, AVATARS_DIR):
    _p.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        _p.chmod(0o700)
    except OSError:
        pass  # Windows and some mounted filesystems do not support POSIX modes.
STATIC_DIR.mkdir(parents=True, exist_ok=True)

EVENTS = [
    {"key": "m4a1", "name": "M4A1 Ring", "subtitle": "Sunrise Realm · source configuration loaded", "mode": "LIVE CONNECTOR REQUIRED"},
    {"key": "emote_royale", "name": "Emote Royale", "subtitle": "Aura Boarder collection · source configuration loaded", "mode": "LIVE CONNECTOR REQUIRED"},
    {"key": "gold_royale", "name": "Gold Royale", "subtitle": "Electro Butterfly Bundle + Thompson - Freezing Flame · source configuration loaded", "mode": "LIVE CONNECTOR REQUIRED"},
    {"key": "ghost", "name": "Ghost Bundle Ring", "subtitle": "Ghost collection · source script included, adapter unavailable", "mode": "LIVE CONNECTOR REQUIRED"},
    {"key": "evo", "name": "Evo Guns Ring", "subtitle": "Evo collection · source script included, adapter unavailable", "mode": "LIVE CONNECTOR REQUIRED"},
    {"key": "thailand_free", "name": "Thailand Free — Ballsy Skaterboi", "subtitle": "Thailand · Ballsy Skaterboi Royale", "mode": "LIVE CONNECTOR REQUIRED"},
    {"key": "vietnam_free", "name": "Vietnam Free — Infernosaur", "subtitle": "Vietnam · Infernosaur Royale", "mode": "LIVE CONNECTOR REQUIRED"},
    {"key": "cobra", "name": "Token Tower", "subtitle": "Cobra Rage Bundle · Taiwan metadata only", "mode": "LIVE CONNECTOR REQUIRED"},
]

TOOL_MODULES = [
    {
        "key": "gen",
        "title": "Gen",
        "source_file": "Gen.py",
        "section": "Account generator",
        "mode": "source_only",
        "execution_enabled": True,
        "status": "SOURCE ONLY",
        "description": "Separate source reference; not executed by the APK backend.",
    },
    {
        "key": "gen_only",
        "title": "Gen Only",
        "source_file": "Gen.py (unchanged reference)",
        "section": "Gen only mode",
        "mode": "source_only",
        "execution_enabled": True,
        "status": "SOURCE ONLY",
        "description": "Standalone Gen mode selection; original signed script is not executed by the APK.",
    },
    {
        "key": "gen_plus_activator",
        "title": "Gen + Auto Activator",
        "source_file": "Gen.py + Auto Activator API adapter",
        "section": "Combined workflow",
        "mode": "awaiting_authorized_api_contract",
        "execution_enabled": True,
        "status": "API CONTRACT REQUIRED",
        "description": "Separate combined mode UI; disabled until a documented, authorized API contract is reviewed.",
    },
    {
        "key": "activator",
        "title": "Auto Activator",
        "source_file": "Server-side API adapter",
        "section": "Standalone activator",
        "mode": "awaiting_authorized_api_contract",
        "execution_enabled": True,
        "status": "NOT CONNECTED",
        "description": "Standalone activator workspace; never sends game credentials to an unverified endpoint.",
    },
    {
        "key": "evo",
        "title": "Evo Spin",
        "source_file": "Evo_Spin.zip / EvoSpin.py",
        "section": "Evo live workspace",
        "mode": "live_connector_required",
        "execution_enabled": True,
        "status": "NOT CONNECTED",
        "description": "Catalogue and original source bundle are included. No game request is made because no verified authorized adapter is configured.",
    },
    {
        "key": "ghost",
        "title": "Ghost Spin",
        "source_file": "Ghost_Spin.zip / Ghost.py",
        "section": "Ghost live workspace",
        "mode": "live_connector_required",
        "execution_enabled": True,
        "status": "NOT CONNECTED",
        "description": "Catalogue and original source bundle are included. No game request is made because no verified authorized adapter is configured.",
    },
]

CATALOGUE_PATH = ROOT / "backend" / "data" / "rocks_catalogue.json"
with CATALOGUE_PATH.open("r", encoding="utf-8") as _catalogue_file:
    _catalogue_data = json.load(_catalogue_file)
REGIONS = {region["code"]: region for region in _catalogue_data.get("regions", [])}
EVENT_SUPPORT = {
    entry["key"]: {
        "supported_regions": list(entry.get("supported_regions", [])),
        "supported_region_names": list(entry.get("supported_region_names", [])),
        "availability_source": entry.get("availability_source", "none"),
        "availability_note": entry.get("availability_note", "No region data configured."),
        "event_name_by_region": dict(entry.get("event_name_by_region", {})),
        "event_number": entry.get("event_number"),
        "event_number_by_region": dict(entry.get("event_number_by_region", {})),
        "mode": entry.get("mode", "SOURCE CONFIG ONLY"),
        "status": entry.get("status", "SOURCE CONFIG ONLY · LIVE UNVERIFIED"),
        "title": entry.get("title", entry.get("name", entry["key"])),
        "payloads_by_region": dict(entry.get("payloads_by_region", {})),
        "payload_execution_enabled": True,
        "catalog_complete": bool(entry.get("catalog_complete", True)),
        "missing_catalog_fields": list(entry.get("missing_catalog_fields", [])),
        "catalog_note": entry.get("catalog_note", ""),
        "payload_note": entry.get("payload_note", "Reference metadata only; not executable."),
    }
    for entry in _catalogue_data.get("events", [])
}
# Hex strings are retained as non-executable source references for event metadata only.
# No route passes these values to a game server or executes them as spin requests.
PAYLOAD_REFERENCES = {
    entry["key"]: {"hex": entry["payload_hex_reference"], "execution_enabled": True}
    for entry in _catalogue_data.get("events", [])
    if entry.get("payload_hex_reference")
}
for _event in EVENTS:
    _event.update(EVENT_SUPPORT.get(_event["key"], {}))
ITEM_METADATA_BY_ID = {str(item["item_id"]): item for item in _catalogue_data.get("items", [])}
SEED_ITEMS = [
    (item["category"], item["item_id"], item["name"], item["rarity"])
    for item in _catalogue_data["items"]
]


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utcnow().isoformat(timespec="seconds")


def csv_safe_cell(value: Any) -> Any:
    """Neutralize spreadsheet formula prefixes in user/admin-controlled CSV cells."""
    if isinstance(value, str) and value.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=15)
    try:
        if DB_PATH.exists():
            DB_PATH.chmod(0o600)
    except OSError:
        pass
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA journal_mode = WAL")
    return con


def init_db() -> None:
    # Re-apply private storage permissions after configuration/path overrides on startup.
    for directory in (DATA_DIR, USERS_DIR, AVATARS_DIR):
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        try:
            directory.chmod(0o700)
        except OSError:
            pass
    with connect() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER NOT NULL UNIQUE,
            username TEXT NOT NULL DEFAULT '',
            first_name TEXT NOT NULL DEFAULT '',
            avatar_path TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS login_codes (
            code_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at TEXT NOT NULL,
            used_at TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS user_preferences (
            user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
            theme TEXT NOT NULL DEFAULT 'hacker',
            region_general TEXT NOT NULL DEFAULT 'IND',
            region_evo TEXT NOT NULL DEFAULT 'ME',
            region_ghost TEXT NOT NULL DEFAULT 'TW',
            catalog_category TEXT NOT NULL DEFAULT 'all',
            catalog_search TEXT NOT NULL DEFAULT '',
            results_search TEXT NOT NULL DEFAULT '',
            results_event TEXT NOT NULL DEFAULT '',
            results_region TEXT NOT NULL DEFAULT '',
            vibration_enabled INTEGER NOT NULL DEFAULT 1,
            gen_mode TEXT NOT NULL DEFAULT 'gen_only',
            dashboard_widgets TEXT NOT NULL DEFAULT 'accounts,gen,activator,evo,ghost,spinner,catalog,results',
            profile_widgets TEXT NOT NULL DEFAULT 'identity,usage,accounts,draws',
            result_view TEXT NOT NULL DEFAULT 'cards',
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS admins (
            telegram_id INTEGER PRIMARY KEY,
            role TEXT NOT NULL DEFAULT 'admin',
            added_by INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS login_attempts (
            client_key TEXT PRIMARY KEY,
            window_start TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor_telegram_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            target_type TEXT NOT NULL DEFAULT '',
            target_id TEXT NOT NULL DEFAULT '',
            details_json TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS favorites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            category TEXT NOT NULL,
            item_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(user_id, category, item_id)
        );
        CREATE TABLE IF NOT EXISTS download_tickets (
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            format TEXT NOT NULL CHECK(format IN ('json','csv')),
            expires_at TEXT NOT NULL,
            used_at TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS admin_catalog_download_tickets (
            token_hash TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at TEXT NOT NULL,
            used_at TEXT NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_favorites_user ON favorites(user_id, category);
        CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at DESC);
        CREATE TABLE IF NOT EXISTS catalog (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            item_id TEXT NOT NULL,
            name TEXT NOT NULL,
            rarity TEXT NOT NULL DEFAULT 'demo',
            enabled INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            UNIQUE(category, item_id)
        );
        CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            label TEXT NOT NULL,
            game_uid TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(user_id, game_uid)
        );
        CREATE TABLE IF NOT EXISTS spins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
            event_key TEXT NOT NULL,
            event_name TEXT NOT NULL,
            item_id TEXT NOT NULL,
            item_name TEXT NOT NULL,
            draw_number INTEGER NOT NULL,
            region_code TEXT NOT NULL DEFAULT 'IND',
            demo INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_accounts_user_time ON accounts(user_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_spins_user_time ON spins(user_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_spins_account ON spins(account_id);
        CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
        """)
        # Backward-compatible migrations for older databases.
        spin_columns = {row[1] for row in con.execute("PRAGMA table_info(spins)").fetchall()}
        if "region_code" not in spin_columns:
            con.execute("ALTER TABLE spins ADD COLUMN region_code TEXT NOT NULL DEFAULT 'IND'")
        preference_columns = {row[1] for row in con.execute("PRAGMA table_info(user_preferences)").fetchall()}
        preference_migrations = {
            "region_general": "TEXT NOT NULL DEFAULT 'IND'",
            "region_evo": "TEXT NOT NULL DEFAULT 'ME'",
            "region_ghost": "TEXT NOT NULL DEFAULT 'TW'",
            "catalog_category": "TEXT NOT NULL DEFAULT 'all'",
            "catalog_search": "TEXT NOT NULL DEFAULT ''",
            "results_search": "TEXT NOT NULL DEFAULT ''",
            "results_event": "TEXT NOT NULL DEFAULT ''",
            "results_region": "TEXT NOT NULL DEFAULT ''",
            "vibration_enabled": "INTEGER NOT NULL DEFAULT 1",
            "gen_mode": "TEXT NOT NULL DEFAULT 'gen_only'",
            "dashboard_widgets": "TEXT NOT NULL DEFAULT 'accounts,gen,activator,evo,ghost,spinner,catalog,results'",
            "profile_widgets": "TEXT NOT NULL DEFAULT 'identity,usage,accounts,draws'",
            "result_view": "TEXT NOT NULL DEFAULT 'cards'",
        }
        for column, declaration in preference_migrations.items():
            if column not in preference_columns:
                con.execute(f"ALTER TABLE user_preferences ADD COLUMN {column} {declaration}")
        # Preserve pre-v2.8 theme choices while removing third-party brand identifiers from current UI keys.
        con.execute("UPDATE user_preferences SET theme='midnight' WHERE theme='batman'")
        con.execute("UPDATE user_preferences SET theme='rose' WHERE theme='barbie'")
        for category, item_id, name, rarity in SEED_ITEMS:
            con.execute(
                "INSERT OR IGNORE INTO catalog(category,item_id,name,rarity,enabled,created_at) VALUES(?,?,?,?,1,?)",
                (category, item_id, name, rarity, iso_now()),
            )
        # Remove stale placeholder records from prior ROCKS versions. These are not real rewards.
        con.execute("DELETE FROM catalog WHERE category='gold_royale' AND item_id='gold-royale-demo'")
        # This unrelated item came from a file the user explicitly excluded; remove it on upgrades too.
        con.execute("DELETE FROM catalog WHERE category='cobra' AND item_id='830000002'")
        # Keep these rarity labels consistent on upgrades of an existing local database.
        # The Ultra Rare labels here are app metadata, not official drop-rate claims.
        con.executemany(
            "UPDATE catalog SET rarity='ultra_rare' WHERE item_id=?",
            [(item_id,) for item_id in ("710026009", "907195111", "907193501", "907192601", "907193511")],
        )
        # The first ID in ADMIN_TELEGRAM_IDS is the owner; others are admins.
        configured_admin_ids = os.getenv("ADMIN_TELEGRAM_IDS", "").strip() or "8664344820"
        raw_ids = [x.strip() for x in configured_admin_ids.split(",") if x.strip()]
        for i, raw in enumerate(raw_ids):
            try:
                tg_id = int(raw)
            except ValueError:
                continue
            con.execute(
                "INSERT INTO admins(telegram_id,role,added_by,created_at) VALUES(?,?,0,?) "
                "ON CONFLICT(telegram_id) DO NOTHING",
                (tg_id, "owner" if i == 0 else "admin", iso_now()),
            )
        # Expired credentials are not useful and should not accumulate indefinitely.
        now = iso_now()
        con.execute("DELETE FROM sessions WHERE expires_at<=?", (now,))
        con.execute("DELETE FROM login_codes WHERE expires_at<=? OR used_at<>''", (now,))
        con.execute("DELETE FROM download_tickets WHERE expires_at<=? OR used_at<>''", (now,))
        con.execute("DELETE FROM admin_catalog_download_tickets WHERE expires_at<=? OR used_at<>''", (now,))


def get_user_by_id(user_id: int) -> dict[str, Any] | None:
    with connect() as con:
        row = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        return dict(row) if row else None


def find_or_create_user(telegram_id: int, username: str = "", first_name: str = "", avatar_path: str = "") -> dict[str, Any]:
    now = iso_now()
    with connect() as con:
        con.execute(
            "INSERT INTO users(telegram_id,username,first_name,avatar_path,status,created_at,last_seen_at) "
            "VALUES(?,?,?,?, 'active', ?, ?) ON CONFLICT(telegram_id) DO UPDATE SET "
            "username=excluded.username, first_name=excluded.first_name, "
            "avatar_path=CASE WHEN excluded.avatar_path='' THEN users.avatar_path ELSE excluded.avatar_path END, "
            "last_seen_at=excluded.last_seen_at",
            (telegram_id, username or "", first_name or "", avatar_path or "", now, now),
        )
        row = con.execute("SELECT * FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
        return dict(row)


def is_admin_telegram(telegram_id: int) -> bool:
    with connect() as con:
        return con.execute("SELECT 1 FROM admins WHERE telegram_id=?", (telegram_id,)).fetchone() is not None


def is_owner_telegram(telegram_id: int) -> bool:
    with connect() as con:
        row = con.execute("SELECT role FROM admins WHERE telegram_id=?", (telegram_id,)).fetchone()
        return bool(row and row["role"] == "owner")


def hash_value(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def write_audit(actor_telegram_id: int, action: str, target_type: str = "",
                target_id: str | int = "", details: dict[str, Any] | None = None) -> None:
    """Persist a minimal audit event without storing secrets or private payloads."""
    with connect() as con:
        con.execute(
            "INSERT INTO audit_logs(actor_telegram_id,action,target_type,target_id,details_json,created_at) "
            "VALUES(?,?,?,?,?,?)",
            (int(actor_telegram_id), action[:80], target_type[:80], str(target_id)[:120],
             json.dumps(details or {}, ensure_ascii=True, separators=(",", ":")), iso_now()),
        )


def create_login_code(telegram_id: int, username: str = "", first_name: str = "", avatar_path: str = "") -> str:
    user = find_or_create_user(telegram_id, username, first_name, avatar_path)
    if user["status"] == "banned":
        raise ValueError("This account is banned. Contact support if you believe this is an error.")
    alphabet = string.ascii_uppercase + string.digits
    code = "".join(secrets.choice(alphabet) for _ in range(8))
    expires = (utcnow() + timedelta(minutes=CODE_MINUTES)).isoformat(timespec="seconds")
    with connect() as con:
        con.execute("UPDATE login_codes SET used_at=? WHERE user_id=? AND used_at=''", (iso_now(), user["id"]))
        con.execute("INSERT INTO login_codes(code_hash,user_id,expires_at,used_at) VALUES(?,?,?,'')",
                    (hash_value(code), user["id"], expires))
    return code


def write_user_json(user_id: int, filename: str, payload: list[dict[str, Any]]) -> None:
    folder = USERS_DIR / str(user_id)
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        folder.chmod(0o700)
    except OSError:
        pass
    target = folder / filename
    temp = target.with_suffix(target.suffix + ".tmp")
    temp.write_text(json.dumps(payload, indent=2, ensure_ascii=True), encoding="utf-8")
    try:
        temp.chmod(0o600)
    except OSError:
        pass
    os.replace(temp, target)


def sync_user_files(user_id: int) -> None:
    with connect() as con:
        accounts = [dict(r) for r in con.execute(
            "SELECT id,label,game_uid,created_at FROM accounts WHERE user_id=? ORDER BY id DESC", (user_id,)
        ).fetchall()]
        spins = [dict(r) for r in con.execute(
            "SELECT id,account_id,event_key,event_name,item_id,item_name,draw_number,region_code,demo,created_at "
            "FROM spins WHERE user_id=? ORDER BY id DESC", (user_id,)
        ).fetchall()]
    for spin in spins:
        region = REGIONS.get(spin.get("region_code", "IND"), REGIONS.get("IND", {}))
        spin["region_name"] = region.get("name", "India")
        spin["region_flag"] = region.get("flag", "🇮🇳")
    write_user_json(user_id, "accounts.json", accounts)
    write_user_json(user_id, "results.json", spins)


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="ROCKS Spinner Manager", version="2.8.0", lifespan=lifespan,
    docs_url="/docs" if ENABLE_API_DOCS else None,
    redoc_url="/redoc" if ENABLE_API_DOCS else None,
    openapi_url="/openapi.json" if ENABLE_API_DOCS else None,
)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob: https://www.freefiremania.com.br; "
        "font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; "
        "form-action 'self'; frame-ancestors 'none'",
    )
    if request.url.path.startswith("/api/"):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


class LoginBody(BaseModel):
    code: str = Field(min_length=6, max_length=12)


class AccountBody(BaseModel):
    label: str = Field(min_length=1, max_length=80)
    game_uid: str = Field(min_length=2, max_length=32, pattern=r"^[A-Za-z0-9_-]+$")


class SpinBody(BaseModel):
    account_id: int
    event_key: str = Field(min_length=1, max_length=40)
    region_code: str = Field(default="IND", min_length=2, max_length=4, pattern=r"^[A-Z]+$")
    count: int = Field(default=1, ge=1, le=11)


class DedicatedModuleSpinBody(BaseModel):
    account_id: int
    region_code: str = Field(default="IND", min_length=2, max_length=4, pattern=r"^[A-Z]+$")


class CatalogBody(BaseModel):
    category: str = Field(min_length=1, max_length=40, pattern=r"^(m4a1|emote_royale|gold_royale|ghost|evo|thailand_free|vietnam_free|cobra)$")
    item_id: str = Field(min_length=1, max_length=40, pattern=r"^[A-Za-z0-9_-]+$")
    name: str = Field(min_length=1, max_length=120, pattern=r"^.*\S.*$")
    rarity: str = Field(default="demo", pattern=r"^(common|rare|featured|ultra_rare|demo|pending)$")


class CatalogImportBody(BaseModel):
    items: list[CatalogBody] = Field(min_length=1, max_length=200)


class FavoriteBody(BaseModel):
    category: str = Field(min_length=1, max_length=40, pattern=r"^(m4a1|emote_royale|gold_royale|ghost|evo|thailand_free|vietnam_free|cobra)$")
    item_id: str = Field(min_length=1, max_length=40, pattern=r"^[A-Za-z0-9_-]+$")


class DownloadTicketBody(BaseModel):
    format: str = Field(pattern=r"^(json|csv)$")


class PreferencesBody(BaseModel):
    theme: str | None = Field(default=None, pattern=r"^(hacker|midnight|rose|crimson|ocean|amethyst|arctic)$")
    region_general: str | None = Field(default=None, pattern=r"^[A-Z]{2,4}$")
    region_evo: str | None = Field(default=None, pattern=r"^[A-Z]{2,4}$")
    region_ghost: str | None = Field(default=None, pattern=r"^[A-Z]{2,4}$")
    catalog_category: str | None = Field(default=None, pattern=r"^(all|favorites|m4a1|emote_royale|gold_royale|ghost|evo|thailand_free|vietnam_free|cobra)$")
    catalog_search: str | None = Field(default=None, max_length=100)
    results_search: str | None = Field(default=None, max_length=100)
    results_event: str | None = Field(default=None, pattern=r"^(|m4a1|emote_royale|gold_royale|ghost|evo|thailand_free|vietnam_free|cobra)$")
    results_region: str | None = Field(default=None, pattern=r"^([A-Z]{2,4})?$")
    vibration_enabled: bool | None = None
    gen_mode: str | None = Field(default=None, pattern=r"^(gen_only|gen_plus_activator)$")
    dashboard_widgets: str | None = Field(default=None, max_length=120, pattern=r"^(accounts|gen|activator|evo|ghost|spinner|catalog|results|themes)(,(accounts|gen|activator|evo|ghost|spinner|catalog|results|themes))*$")
    profile_widgets: str | None = Field(default=None, max_length=60, pattern=r"^(identity|usage|accounts|draws)(,(identity|usage|accounts|draws))*$")
    result_view: str | None = Field(default=None, pattern=r"^(cards|list|timeline)$")


def current_user(authorization: str = Header(default="")) -> dict[str, Any]:
    if not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Login through the Telegram bot first.")
    token = authorization.split(" ", 1)[1].strip()
    if not token:
        raise HTTPException(status_code=401, detail="Invalid session.")
    with connect() as con:
        row = con.execute(
            "SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id "
            "WHERE s.token_hash=? AND s.expires_at>?", (hash_value(token), iso_now())
        ).fetchone()
    if not row:
        raise HTTPException(status_code=401, detail="Session expired. Sign in again with Telegram.")
    user = dict(row)
    if user["status"] == "banned":
        with connect() as con:
            con.execute("DELETE FROM sessions WHERE user_id=?", (user["id"],))
        raise HTTPException(status_code=403, detail="This account is banned. Contact support.")
    return user


def require_admin(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    if not is_admin_telegram(int(user["telegram_id"])):
        # A non-admin cannot use this endpoint or learn the admin roster.
        raise HTTPException(status_code=404, detail="Not found.")
    return user


def require_owner(user: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    if not is_owner_telegram(int(user["telegram_id"])):
        raise HTTPException(status_code=404, detail="Not found.")
    return user


def public_user(user: dict[str, Any]) -> dict[str, Any]:
    avatar = user.get("avatar_path", "")
    return {
        "telegram_id": user["telegram_id"],
        "username": user["username"],
        "first_name": user["first_name"],
        "avatar_url": f"/api/avatar/{int(user['telegram_id'])}" if avatar else "",
        "created_at": user["created_at"],
    }


def usage_for_day(user_id: int) -> dict[str, int]:
    today = utcnow().date().isoformat()
    with connect() as con:
        count = con.execute(
            "SELECT COUNT(*) FROM accounts WHERE user_id=? AND substr(created_at,1,10)=?", (user_id, today)
        ).fetchone()[0]
    return {"used": int(count), "limit": DAILY_ACCOUNT_LIMIT, "remaining": max(0, DAILY_ACCOUNT_LIMIT - int(count))}


def event_by_key(key: str) -> dict[str, str] | None:
    return next((x for x in EVENTS if x["key"] == key), None)


@app.get("/")
def home() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/health")
def health() -> dict[str, str]:
    try:
        with connect() as con:
            con.execute("SELECT 1").fetchone()
    except sqlite3.Error as exc:
        raise HTTPException(status_code=503, detail="ROCKS storage is not ready.") from exc
    return {"status": "ok", "brand": "ROCKS", "version": "2.0.0", "mode": "demo-only"}


def record_login_attempt(client_key: str, success: bool = True) -> None:
    now_dt = utcnow()
    with connect() as con:
        if success:
            con.execute("DELETE FROM login_attempts WHERE client_key=?", (client_key,))
            return
        row = con.execute("SELECT window_start,attempts FROM login_attempts WHERE client_key=?", (client_key,)).fetchone()
        if row:
            try:
                start = datetime.fromisoformat(row["window_start"])
            except ValueError:
                start = now_dt - timedelta(hours=1)
            if now_dt - start >= timedelta(minutes=15):
                con.execute("UPDATE login_attempts SET window_start=?,attempts=1 WHERE client_key=?", (now_dt.isoformat(timespec="seconds"), client_key))
            elif int(row["attempts"]) >= 8:
                raise HTTPException(status_code=429, detail="Too many login attempts. Wait 15 minutes and try again.")
            else:
                con.execute("UPDATE login_attempts SET attempts=attempts+1 WHERE client_key=?", (client_key,))
        else:
            con.execute("INSERT INTO login_attempts(client_key,window_start,attempts) VALUES(?,?,1)",
                        (client_key, now_dt.isoformat(timespec="seconds")))


@app.post("/api/login")
def login(body: LoginBody, request: Request) -> dict[str, Any]:
    client_key = request.client.host if request.client else "unknown"
    record_login_attempt(client_key)
    code_hash = hash_value(body.code.strip().upper())
    now = iso_now()
    token = secrets.token_urlsafe(36)
    expiry = (utcnow() + timedelta(days=SESSION_DAYS)).isoformat(timespec="seconds")
    with connect() as con:
        code_row = con.execute(
            "SELECT lc.*, u.status FROM login_codes lc JOIN users u ON u.id=lc.user_id "
            "WHERE lc.code_hash=? AND lc.used_at='' AND lc.expires_at>?", (code_hash, now)
        ).fetchone()
        if not code_row:
            raise HTTPException(status_code=400, detail="Code is invalid, expired, or already used. Request a new one in Telegram.")
        if code_row["status"] == "banned":
            raise HTTPException(status_code=403, detail="This account is banned. Contact support.")
        con.execute("UPDATE login_codes SET used_at=? WHERE code_hash=?", (now, code_hash))
        con.execute("INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)",
                    (hash_value(token), code_row["user_id"], expiry, now))
        con.execute("UPDATE users SET last_seen_at=? WHERE id=?", (now, code_row["user_id"]))
        row = con.execute("SELECT * FROM users WHERE id=?", (code_row["user_id"],)).fetchone()
    record_login_attempt(client_key, success=True)
    return {"token": token, "user": public_user(dict(row)), "usage": usage_for_day(int(row["id"]))}


@app.post("/api/logout")
def logout(user: dict[str, Any] = Depends(current_user), authorization: str = Header(default="")) -> dict[str, bool]:
    token = authorization.split(" ", 1)[1].strip() if " " in authorization else ""
    with connect() as con:
        con.execute("DELETE FROM sessions WHERE token_hash=?", (hash_value(token),))
    return {"ok": True}




@app.get("/api/avatar/{telegram_id}")
def get_avatar(telegram_id: int, user: dict[str, Any] = Depends(current_user)) -> FileResponse:
    if telegram_id != int(user["telegram_id"]) and not is_admin_telegram(int(user["telegram_id"])):
        raise HTTPException(status_code=404, detail="Not found.")
    with connect() as con:
        row = con.execute("SELECT avatar_path FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
    if not row or not row["avatar_path"]:
        raise HTTPException(status_code=404, detail="Profile photo not available.")
    # Telegram avatar downloads are stored by numeric Telegram ID only.
    path = (AVATARS_DIR / f"{telegram_id}.jpg").resolve()
    if path.parent != AVATARS_DIR.resolve() or not path.is_file():
        raise HTTPException(status_code=404, detail="Profile photo not available.")
    return FileResponse(path, media_type="image/jpeg", headers={"Cache-Control": "private, max-age=600"})


@app.get("/api/me")
def me(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    # Admin role and admin roster are intentionally not exposed to ordinary user sessions.
    with connect() as con:
        account_count = con.execute("SELECT COUNT(*) FROM accounts WHERE user_id=?", (user["id"],)).fetchone()[0]
        spin_count = con.execute("SELECT COUNT(*) FROM spins WHERE user_id=? AND demo=0", (user["id"],)).fetchone()[0]
        favorite_count = con.execute("SELECT COUNT(*) FROM favorites WHERE user_id=?", (user["id"],)).fetchone()[0]
        last_activity = con.execute("SELECT MAX(created_at) FROM (SELECT created_at FROM accounts WHERE user_id=? UNION ALL SELECT created_at FROM spins WHERE user_id=?)", (user["id"], user["id"])).fetchone()[0]
    return {"user": public_user(user), "usage": usage_for_day(int(user["id"])),
            "account_count": int(account_count), "verified_draw_count": int(spin_count),
            "favorite_count": int(favorite_count), "last_activity_at": last_activity,
            "session_lifetime_days": SESSION_DAYS}


@app.get("/api/me/export")
def export_my_data(user: dict[str, Any] = Depends(current_user)) -> JSONResponse:
    """Export only the authenticated user's own profile and app data."""
    uid = int(user["id"])
    with connect() as con:
        prefs = con.execute(
            "SELECT theme,region_general,region_evo,region_ghost,catalog_category,catalog_search,"
            "results_search,results_event,results_region,vibration_enabled,gen_mode,dashboard_widgets,profile_widgets,result_view,updated_at "
            "FROM user_preferences WHERE user_id=?", (uid,)
        ).fetchone()
        accounts = [dict(r) for r in con.execute(
            "SELECT label,game_uid,created_at FROM accounts WHERE user_id=? ORDER BY id", (uid,)
        ).fetchall()]
        results = [dict(r) for r in con.execute(
            "SELECT event_key,event_name,item_id,item_name,draw_number,region_code,demo,created_at "
            "FROM spins WHERE user_id=? AND demo=0 ORDER BY id", (uid,)
        ).fetchall()]
        favorites = [dict(r) for r in con.execute(
            "SELECT category,item_id,created_at FROM favorites WHERE user_id=? ORDER BY category,item_id", (uid,)
        ).fetchall()]
    preferences = dict(prefs) if prefs else {}
    if "vibration_enabled" in preferences:
        preferences["vibration_enabled"] = bool(preferences["vibration_enabled"])
    payload = {
        "brand": "ROCKS", "exported_at": iso_now(), "mode": "live-only",
        "notice": "This export contains only the authenticated user's ROCKS data and verified live results. Historical simulator records are excluded.",
        "profile": public_user(user), "preferences": preferences,
        "accounts": accounts, "verified_results": results, "favorites": favorites,
    }
    return JSONResponse(payload, headers={"Content-Disposition": 'attachment; filename="rocks-user-export.json"'})


@app.get("/api/results/export.csv")
def export_my_results_csv(user: dict[str, Any] = Depends(current_user)) -> StreamingResponse:
    """Export the current user's own result rows, never global/admin results."""
    with connect() as con:
        rows = con.execute(
            "SELECT s.event_name,s.item_id,s.item_name,s.draw_number,s.region_code,s.demo,s.created_at,a.label,a.game_uid "
            "FROM spins s JOIN accounts a ON a.id=s.account_id WHERE s.user_id=? AND s.demo=0 ORDER BY s.id DESC LIMIT 10000",
            (int(user["id"]),),
        ).fetchall()
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer)
    writer.writerow(["event", "item_id", "item_name", "draw_number", "region_code", "verified", "created_at", "profile_label", "game_uid"])
    for row in rows:
        writer.writerow([csv_safe_cell(row[k]) for k in ("event_name", "item_id", "item_name", "draw_number", "region_code", "demo", "created_at", "label", "game_uid")])
    return StreamingResponse(iter(["\ufeff" + buffer.getvalue()]), media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="rocks-verified-results.csv"', "Cache-Control": "no-store"})


@app.delete("/api/me")
def delete_my_profile(user: dict[str, Any] = Depends(current_user)) -> dict[str, bool]:
    """Delete the signed-in user's ROCKS profile and all user-owned records."""
    user_id = int(user["id"])
    telegram_id = int(user["telegram_id"])
    folder = USERS_DIR / str(user_id)
    avatar = AVATARS_DIR / f"{telegram_id}.jpg"
    write_audit(0, "self_delete_profile", "profile", user_id, {"initiated_by": "self_service"})
    with connect() as con:
        con.execute("DELETE FROM users WHERE id=?", (user_id,))
    shutil.rmtree(folder, ignore_errors=True)
    try:
        avatar.unlink(missing_ok=True)
    except OSError:
        pass
    return {"ok": True}


@app.post("/api/me/download-ticket")
def create_download_ticket(body: DownloadTicketBody, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    """Issue a short-lived, single-use URL suitable for WebView/browser downloads."""
    ticket = secrets.token_urlsafe(32)
    expiry = (utcnow() + timedelta(minutes=2)).isoformat(timespec="seconds")
    with connect() as con:
        con.execute("DELETE FROM download_tickets WHERE expires_at<=? OR used_at<>''", (iso_now(),))
        con.execute("INSERT INTO download_tickets(token_hash,user_id,format,expires_at,used_at) VALUES(?,?,?,?,'')",
                    (hash_value(ticket), int(user["id"]), body.format, expiry))
    return {"url": f"/api/download/{ticket}", "format": body.format, "expires_in_seconds": 120}


@app.get("/api/download/{ticket}")
def download_with_ticket(ticket: str) -> Response:
    """Consume a one-time capability URL; the opaque ticket never selects a user ID."""
    now = iso_now()
    with connect() as con:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute(
            "SELECT user_id,format FROM download_tickets WHERE token_hash=? AND used_at='' AND expires_at>?",
            (hash_value(ticket), now),
        ).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Download link expired or already used. Create a new export.")
        con.execute("UPDATE download_tickets SET used_at=? WHERE token_hash=? AND used_at=''", (now, hash_value(ticket)))
    exported_user = get_user_by_id(int(row["user_id"]))
    if not exported_user:
        raise HTTPException(status_code=404, detail="Profile no longer exists.")
    if row["format"] == "csv":
        return export_my_results_csv(exported_user)
    return export_my_data(exported_user)


@app.get("/api/preferences")
def get_preferences(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    """Return all personal UI settings for the authenticated Telegram user only."""
    with connect() as con:
        con.execute(
            "INSERT OR IGNORE INTO user_preferences(user_id,theme,region_general,region_evo,region_ghost,updated_at) "
            "VALUES(?,?,?,?,?,?)",
            (int(user["id"]), "hacker", "IND", "ME", "TW", iso_now()),
        )
        row = con.execute(
            "SELECT theme,region_general,region_evo,region_ghost,catalog_category,catalog_search,"
            "results_search,results_event,results_region,vibration_enabled,gen_mode,dashboard_widgets,profile_widgets,result_view,updated_at "
            "FROM user_preferences WHERE user_id=?", (int(user["id"]),)
        ).fetchone()
    result = dict(row)
    result["vibration_enabled"] = bool(result["vibration_enabled"])
    return result


@app.put("/api/preferences")
def update_preferences(body: PreferencesBody, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    """Update preferences for the current authenticated user; client cannot choose another user ID."""
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail="Provide at least one preference to update.")
    for key in ("region_general", "region_evo", "region_ghost"):
        if key in updates and updates[key] not in REGIONS:
            raise HTTPException(status_code=400, detail=f"Unknown region code: {updates[key]}.")
    if updates.get("results_region") and updates["results_region"] not in REGIONS:
        raise HTTPException(status_code=400, detail=f"Unknown region code: {updates['results_region']}.")
    allowed = {"theme", "region_general", "region_evo", "region_ghost", "catalog_category",
               "catalog_search", "results_search", "results_event", "results_region", "vibration_enabled", "gen_mode",
               "dashboard_widgets", "profile_widgets", "result_view"}
    if any(key not in allowed for key in updates):
        raise HTTPException(status_code=400, detail="Unsupported preference.")
    updates["updated_at"] = iso_now()
    with connect() as con:
        con.execute(
            "INSERT OR IGNORE INTO user_preferences(user_id,theme,region_general,region_evo,region_ghost,updated_at) "
            "VALUES(?,?,?,?,?,?)",
            (int(user["id"]), "hacker", "IND", "ME", "TW", iso_now()),
        )
        assignments = ", ".join(f"{key}=?" for key in updates)
        values = list(updates.values()) + [int(user["id"])]
        con.execute(f"UPDATE user_preferences SET {assignments} WHERE user_id=?", values)
        row = con.execute(
            "SELECT theme,region_general,region_evo,region_ghost,catalog_category,catalog_search,"
            "results_search,results_event,results_region,vibration_enabled,gen_mode,dashboard_widgets,profile_widgets,result_view,updated_at "
            "FROM user_preferences WHERE user_id=?", (int(user["id"]),)
        ).fetchone()
    result = dict(row)
    result["vibration_enabled"] = bool(result["vibration_enabled"])
    return result


@app.get("/api/regions")
def get_regions(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"regions": list(REGIONS.values()), "default": "IND",
            "note": "Every region is shown for every event. Event availability reflects supplied configuration only; live server state is not checked."}


@app.get("/api/events")
def get_events(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {"events": EVENTS, "regions": list(REGIONS.values()),
            "availability_note": "Coverage is from supplied configuration only; it is not a live server availability check.",
            "catalogue_version": _catalogue_data.get("schema_version", 1)}


@app.get("/api/modules")
def get_tool_modules(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    """Return the independent app sections without enabling uploaded scripts."""
    return {
        "modules": TOOL_MODULES,
        "note": "Source files and reference payload data are included, but no account-generation, activation, or game-spin script is executed by the web app. Live actions remain unavailable until an authorized, documented adapter is configured.",
    }


@app.get("/api/activator/status")
def activator_status(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    """Return safe configuration status only; never contact the configured third-party API."""
    endpoint_configured = bool(ROCKS_ACTIVATOR_API_URL)
    return {
        "module": "activator",
        "endpoint_configured": endpoint_configured,
        "endpoint_scheme_valid": ROCKS_ACTIVATOR_API_URL.lower().startswith("https://") if endpoint_configured else True,
        "api_contract_verified": True,
        "execution_enabled": True,
        "status": "API CONTRACT REQUIRED" if endpoint_configured else "NOT CONFIGURED",
        "message": (
            "An endpoint hint is configured, but no requests are sent until its operator, security properties, and authorized API contract are independently verified."
            if endpoint_configured else
            "No verified activator connector is configured. No UID, password, or token is sent to an external activator."
        ),
    }


@app.get("/api/catalog")
def get_catalog(category: str | None = None, q: str | None = None,
                user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    if q and len(q) > 100:
        raise HTTPException(status_code=400, detail="Catalogue search text is too long.")
    sql = ("SELECT c.id,c.category,c.item_id,c.name,c.rarity,c.enabled, "
           "EXISTS(SELECT 1 FROM favorites f WHERE f.user_id=? AND f.category=c.category AND f.item_id=c.item_id) AS favorite "
           "FROM catalog c WHERE c.enabled=1")
    args: list[Any] = [int(user["id"])]
    if category:
        sql += " AND c.category=?"
        args.append(category)
    if q and q.strip():
        sql += " AND (c.name LIKE ? OR c.item_id LIKE ? OR c.category LIKE ?)"
        query = f"%{q.strip()}%"
        args.extend([query, query, query])
    sql += " ORDER BY c.category, c.id"
    with connect() as con:
        rows = [dict(r) for r in con.execute(sql, tuple(args)).fetchall()]
    for row in rows:
        meta = ITEM_METADATA_BY_ID.get(str(row["item_id"]), {})
        row["image_url"] = meta.get("image_url")
        row["image_status"] = meta.get("image_status", "needs_id_lookup")
        row["image_note"] = meta.get("image_note", "Search this ID on the linked item catalogues.")
        row["ff_item_library_url"] = meta.get("ff_item_library_url", "https://ff-item.netlify.app/")
        row["freefiremania_search_url"] = meta.get("freefiremania_search_url", "https://www.freefiremania.com.br/free-fire-items.html")
        row["freefiremania_item_url"] = meta.get("freefiremania_item_url")
    return {"items": rows, "image_policy": "Item images are matched by numeric item ID where a direct image was confirmed; others use a ROCKS fallback until verified."}


@app.get("/api/favorites")
def get_favorites(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    with connect() as con:
        rows = [dict(r) for r in con.execute(
            "SELECT category,item_id,created_at FROM favorites WHERE user_id=? ORDER BY created_at DESC",
            (int(user["id"]),),
        ).fetchall()]
    return {"favorites": rows}


@app.post("/api/favorites")
def add_favorite(body: FavoriteBody, user: dict[str, Any] = Depends(current_user)) -> dict[str, bool]:
    with connect() as con:
        found = con.execute("SELECT 1 FROM catalog WHERE category=? AND item_id=? AND enabled=1",
                            (body.category, body.item_id)).fetchone()
        if not found:
            raise HTTPException(status_code=404, detail="Catalogue item not found.")
        con.execute("INSERT OR IGNORE INTO favorites(user_id,category,item_id,created_at) VALUES(?,?,?,?)",
                    (int(user["id"]), body.category, body.item_id, iso_now()))
    return {"ok": True}


@app.delete("/api/favorites/{category}/{item_id}")
def remove_favorite(category: str, item_id: str, user: dict[str, Any] = Depends(current_user)) -> dict[str, bool]:
    if category not in {event["key"] for event in EVENTS} or not item_id or len(item_id) > 40:
        raise HTTPException(status_code=400, detail="Invalid favourite reference.")
    with connect() as con:
        con.execute("DELETE FROM favorites WHERE user_id=? AND category=? AND item_id=?",
                    (int(user["id"]), category, item_id))
    return {"ok": True}


@app.get("/api/accounts")
def get_accounts(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    with connect() as con:
        rows = [dict(r) for r in con.execute(
            "SELECT id,label,game_uid,created_at FROM accounts WHERE user_id=? ORDER BY id DESC", (user["id"],)
        ).fetchall()]
    return {"accounts": rows, "usage": usage_for_day(int(user["id"]))}


@app.post("/api/accounts")
def add_account(body: AccountBody, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    admin = is_admin_telegram(int(user["telegram_id"]))
    today = utcnow().date().isoformat()
    try:
        with connect() as con:
            # Reserve a write lock so concurrent requests cannot pass the daily cap together.
            con.execute("BEGIN IMMEDIATE")
            if not admin:
                used = con.execute(
                    "SELECT COUNT(*) FROM accounts WHERE user_id=? AND substr(created_at,1,10)=?",
                    (user["id"], today),
                ).fetchone()[0]
                if int(used) >= DAILY_ACCOUNT_LIMIT:
                    raise HTTPException(status_code=429, detail=f"Daily limit reached ({DAILY_ACCOUNT_LIMIT} account profiles). Try again tomorrow.")
            cur = con.execute("INSERT INTO accounts(user_id,label,game_uid,created_at) VALUES(?,?,?,?)",
                              (user["id"], body.label.strip(), body.game_uid.strip(), iso_now()))
            account_id = int(cur.lastrowid)
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="That UID is already saved in your account directory.")
    sync_user_files(int(user["id"]))
    with connect() as con:
        row = dict(con.execute("SELECT id,label,game_uid,created_at FROM accounts WHERE id=?", (account_id,)).fetchone())
    return {"account": row, "usage": usage_for_day(int(user["id"]))}


@app.delete("/api/accounts/{account_id}")
def delete_account(account_id: int, user: dict[str, Any] = Depends(current_user)) -> dict[str, bool]:
    with connect() as con:
        row = con.execute("SELECT id FROM accounts WHERE id=? AND user_id=?", (account_id, user["id"])).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Account not found.")
        con.execute("DELETE FROM accounts WHERE id=? AND user_id=?", (account_id, user["id"]))
    sync_user_files(int(user["id"]))
    return {"ok": True}


@app.get("/api/results")
def get_results(limit: int = 100, offset: int = 0,
                event_key: str | None = None,
                region_code: str | None = None,
                q: str | None = None,
                user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    if not 1 <= limit <= 500 or not 0 <= offset <= 100000:
        raise HTTPException(status_code=400, detail="Invalid result pagination values.")
    if event_key and event_key not in {entry["key"] for entry in EVENTS}:
        raise HTTPException(status_code=400, detail="Unknown event key.")
    if q and len(q) > 100:
        raise HTTPException(status_code=400, detail="Result search text is too long.")
    where = ["s.user_id=?", "s.demo=0"]
    args: list[Any] = [int(user["id"])]
    if event_key:
        where.append("s.event_key=?")
        args.append(event_key)
    if region_code:
        if region_code not in REGIONS:
            raise HTTPException(status_code=400, detail="Unknown region code.")
        where.append("s.region_code=?")
        args.append(region_code)
    if q and q.strip():
        where.append("(s.item_name LIKE ? OR s.item_id LIKE ? OR s.event_name LIKE ? OR a.label LIKE ? OR a.game_uid LIKE ?)")
        query = f"%{q.strip()}%"
        args.extend([query] * 5)
    predicate = " AND ".join(where)
    with connect() as con:
        rows = [dict(r) for r in con.execute(
            "SELECT s.id,s.account_id,a.label,a.game_uid,s.event_key,s.event_name,s.item_id,s.item_name,"
            "COALESCE(c.rarity,'rare') AS rarity,s.draw_number,s.region_code,s.demo,s.created_at "
            "FROM spins s JOIN accounts a ON a.id=s.account_id "
            "LEFT JOIN catalog c ON c.category=s.event_key AND c.item_id=s.item_id "
            f"WHERE {predicate} ORDER BY s.id DESC LIMIT ? OFFSET ?",
            tuple(args + [limit, offset]),
        ).fetchall()]
        total = int(con.execute(
            "SELECT COUNT(*) FROM spins s JOIN accounts a ON a.id=s.account_id "
            f"WHERE {predicate}", tuple(args)
        ).fetchone()[0])
    for row in rows:
        region = REGIONS.get(row.get("region_code", "IND"), REGIONS.get("IND", {}))
        row["region_name"] = region.get("name", "India")
        row["region_flag"] = region.get("flag", "🇮🇳")
    return {"results": rows, "total": total, "limit": limit, "offset": offset,
            "note": "Only verified live result records are returned. No live game connector is currently configured."}


LIVE_CONNECTOR_REQUIRED = (
    "No live game connector is configured. No request was sent and no result was created. "
    "The supplied scripts and payload strings target private game endpoints and are not wired into the web app. "
    "Connect only through a documented, authorized API adapter."
)


@app.get("/api/live/status")
def live_integration_status(user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    return {
        "status": "NOT CONNECTED",
        "live_actions_enabled": True,
        "connector_configured": True,
        "message": LIVE_CONNECTOR_REQUIRED,
    }


@app.post("/api/spins")
def live_spin_unavailable(body: SpinBody, user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    raise HTTPException(status_code=503, detail=LIVE_CONNECTOR_REQUIRED)


@app.post("/api/tools/evo/spin")
def live_evo_spin_unavailable(body: DedicatedModuleSpinBody,
                              user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    raise HTTPException(status_code=503, detail=LIVE_CONNECTOR_REQUIRED)


@app.post("/api/tools/ghost/spin")
def live_ghost_spin_unavailable(body: DedicatedModuleSpinBody,
                                user: dict[str, Any] = Depends(current_user)) -> dict[str, Any]:
    raise HTTPException(status_code=503, detail=LIVE_CONNECTOR_REQUIRED)


@app.get("/api/admin/overview")
def admin_overview(user: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    today = utcnow().date().isoformat()
    with connect() as con:
        users_total = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        active = con.execute("SELECT COUNT(*) FROM users WHERE status='active'").fetchone()[0]
        banned = con.execute("SELECT COUNT(*) FROM users WHERE status='banned'").fetchone()[0]
        today_accounts = con.execute("SELECT COUNT(*) FROM accounts WHERE substr(created_at,1,10)=?", (today,)).fetchone()[0]
        today_draws = con.execute("SELECT COUNT(*) FROM spins WHERE demo=0 AND substr(created_at,1,10)=?", (today,)).fetchone()[0]
        all_draws = con.execute("SELECT COUNT(*) FROM spins WHERE demo=0").fetchone()[0]
        all_accounts = con.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
    return {"users_total": int(users_total), "active_users": int(active), "banned_users": int(banned),
            "today_account_profiles": int(today_accounts), "today_verified_draws": int(today_draws),
            "all_verified_draws": int(all_draws), "saved_account_profiles": int(all_accounts),
            "can_manage_admins": is_owner_telegram(int(user["telegram_id"]))}


@app.get("/api/admin/users")
def admin_users(user: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    with connect() as con:
        rows = con.execute("""
        SELECT u.id,u.telegram_id,u.username,u.first_name,u.status,u.created_at,u.last_seen_at,
               (SELECT COUNT(*) FROM accounts a WHERE a.user_id=u.id) AS accounts_count,
               (SELECT COUNT(*) FROM spins s WHERE s.user_id=u.id AND s.demo=0) AS draws_count
        FROM users u ORDER BY u.id DESC LIMIT 500
        """).fetchall()
    data = []
    for row in rows:
        item = dict(row)
        item["is_admin"] = is_admin_telegram(int(item["telegram_id"]))
        data.append(item)
    return {"users": data}


@app.post("/api/admin/users/{user_id}/ban")
def admin_ban(user_id: int, user: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    with connect() as con:
        target = con.execute("SELECT telegram_id FROM users WHERE id=?", (user_id,)).fetchone()
        if not target:
            raise HTTPException(status_code=404, detail="User not found.")
        if is_admin_telegram(int(target["telegram_id"])):
            raise HTTPException(status_code=400, detail="Remove admin access before banning an administrator.")
        con.execute("UPDATE users SET status='banned' WHERE id=?", (user_id,))
        con.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
        con.execute("UPDATE login_codes SET used_at=? WHERE user_id=? AND used_at=''", (iso_now(), user_id))
    write_audit(int(user["telegram_id"]), "user_ban", "user", user_id,
                {"target_telegram_id": int(target["telegram_id"])})
    return {"ok": True}


@app.post("/api/admin/users/{user_id}/unban")
def admin_unban(user_id: int, user: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    with connect() as con:
        target = con.execute("SELECT telegram_id FROM users WHERE id=?", (user_id,)).fetchone()
        if not target:
            raise HTTPException(status_code=404, detail="User not found.")
        cur = con.execute("UPDATE users SET status='active' WHERE id=?", (user_id,))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="User not found.")
    write_audit(int(user["telegram_id"]), "user_unban", "user", user_id,
                {"target_telegram_id": int(target["telegram_id"])})
    return {"ok": True}


@app.get("/api/admin/results")
def admin_results(user_id: int | None = None, limit: int = Query(default=200, ge=1, le=1000), user: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    query = """SELECT s.id,s.user_id,u.telegram_id,u.username,u.first_name,a.label,a.game_uid,s.event_name,
               s.item_id,s.item_name,COALESCE(c.rarity,'rare') AS rarity,s.draw_number,s.region_code,s.created_at
               FROM spins s JOIN users u ON u.id=s.user_id JOIN accounts a ON a.id=s.account_id
               LEFT JOIN catalog c ON c.category=s.event_key AND c.item_id=s.item_id
               WHERE s.demo=0"""
    args: list[Any] = []
    if user_id is not None:
        query += " AND s.user_id=?"
        args.append(user_id)
    query += " ORDER BY s.id DESC LIMIT ?"
    args.append(limit)
    with connect() as con:
        rows = [dict(r) for r in con.execute(query, tuple(args)).fetchall()]
    for row in rows:
        region = REGIONS.get(row.get("region_code", "IND"), REGIONS.get("IND", {}))
        row["region_name"] = region.get("name", "India")
        row["region_flag"] = region.get("flag", "🇮🇳")
    return {"results": rows}


@app.get("/api/admin/audit-logs")
def admin_audit_logs(limit: int = Query(default=100, ge=1, le=500), offset: int = Query(default=0, ge=0, le=100000),
                     user: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    with connect() as con:
        rows = [dict(r) for r in con.execute(
            "SELECT id,actor_telegram_id,action,target_type,target_id,details_json,created_at "
            "FROM audit_logs ORDER BY id DESC LIMIT ? OFFSET ?", (limit, offset),
        ).fetchall()]
        total = int(con.execute("SELECT COUNT(*) FROM audit_logs").fetchone()[0])
    for row in rows:
        try:
            row["details"] = json.loads(row.pop("details_json") or "{}")
        except (json.JSONDecodeError, TypeError):
            row["details"] = {}
            row.pop("details_json", None)
    return {"events": rows, "total": total, "limit": limit, "offset": offset}


@app.get("/api/admin/admins")
def admin_admins(user: dict[str, Any] = Depends(require_owner)) -> dict[str, Any]:
    with connect() as con:
        rows = [dict(r) for r in con.execute("SELECT telegram_id,role,added_by,created_at FROM admins ORDER BY role DESC, telegram_id").fetchall()]
    return {"admins": rows}


class AdminBody(BaseModel):
    telegram_id: int = Field(gt=0)


@app.post("/api/admin/admins")
def admin_add_admin(body: AdminBody, user: dict[str, Any] = Depends(require_owner)) -> dict[str, bool]:
    with connect() as con:
        con.execute("INSERT INTO admins(telegram_id,role,added_by,created_at) VALUES(?,'admin',?,?) "
                    "ON CONFLICT(telegram_id) DO NOTHING", (body.telegram_id, int(user["telegram_id"]), iso_now()))
    write_audit(int(user["telegram_id"]), "admin_add", "admin", body.telegram_id)
    return {"ok": True}


@app.delete("/api/admin/admins/{telegram_id}")
def admin_remove_admin(telegram_id: int, user: dict[str, Any] = Depends(require_owner)) -> dict[str, bool]:
    if telegram_id == int(user["telegram_id"]):
        raise HTTPException(status_code=400, detail="The owner cannot remove their own access.")
    with connect() as con:
        row = con.execute("SELECT role FROM admins WHERE telegram_id=?", (telegram_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Admin not found.")
        if row["role"] == "owner":
            raise HTTPException(status_code=400, detail="The owner role cannot be removed from this screen.")
        con.execute("DELETE FROM admins WHERE telegram_id=?", (telegram_id,))
    write_audit(int(user["telegram_id"]), "admin_remove", "admin", telegram_id)
    return {"ok": True}


@app.post("/api/admin/catalog")
def admin_add_catalog(body: CatalogBody, user: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    if body.category not in {x["key"] for x in EVENTS}:
        raise HTTPException(status_code=400, detail="Choose a supported event category.")
    if body.rarity not in {"common", "rare", "featured", "ultra_rare", "demo", "pending"}:
        raise HTTPException(status_code=400, detail="Choose a supported rarity label.")
    try:
        with connect() as con:
            cur = con.execute("INSERT INTO catalog(category,item_id,name,rarity,enabled,created_at) VALUES(?,?,?,?,1,?)",
                              (body.category, body.item_id.strip(), body.name.strip(), body.rarity.strip() or "demo", iso_now()))
            new_id = int(cur.lastrowid)
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="That ID already exists in this category.")
    with connect() as con:
        row = dict(con.execute("SELECT id,category,item_id,name,rarity,enabled FROM catalog WHERE id=?", (new_id,)).fetchone())
    write_audit(int(user["telegram_id"]), "catalog_add", "catalog", row["id"],
                {"category": row["category"], "item_id": row["item_id"], "rarity": row["rarity"]})
    return {"item": row}


@app.post("/api/admin/catalog/import")
def admin_import_catalog(body: CatalogImportBody, user: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    """Bulk import a bounded, validated JSON catalogue; existing entries are never overwritten."""
    added = 0
    skipped = 0
    with connect() as con:
        for item in body.items:
            name = item.name.strip()
            if not name:
                raise HTTPException(status_code=422, detail="Item names cannot be blank.")
            cur = con.execute(
                "INSERT OR IGNORE INTO catalog(category,item_id,name,rarity,enabled,created_at) VALUES(?,?,?,?,1,?)",
                (item.category, item.item_id.strip(), name, item.rarity, iso_now()),
            )
            if cur.rowcount:
                added += 1
            else:
                skipped += 1
    write_audit(int(user["telegram_id"]), "catalog_bulk_import", "catalog", "", {
        "added": added, "skipped": skipped, "submitted": len(body.items)
    })
    return {"ok": True, "added": added, "skipped": skipped,
            "message": f"Imported {added} item(s); skipped {skipped} duplicate item(s)."}


@app.post("/api/admin/catalog/download-ticket")
def create_admin_catalog_download_ticket(user: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    """Create a one-time admin-scoped CSV export capability for native WebView downloads."""
    ticket = secrets.token_urlsafe(32)
    expiry = (utcnow() + timedelta(minutes=2)).isoformat(timespec="seconds")
    with connect() as con:
        con.execute("DELETE FROM admin_catalog_download_tickets WHERE expires_at<=? OR used_at<>''", (iso_now(),))
        con.execute(
            "INSERT INTO admin_catalog_download_tickets(token_hash,user_id,expires_at,used_at) VALUES(?,?,?,'')",
            (hash_value(ticket), int(user["id"]), expiry),
        )
    write_audit(int(user["telegram_id"]), "catalog_export_ticket", "catalog", "", {})
    return {"url": f"/api/admin/catalog/download/{ticket}", "expires_in_seconds": 120}


@app.get("/api/admin/catalog/download/{ticket}")
def download_admin_catalog(ticket: str) -> StreamingResponse:
    """Consume a one-time catalogue export ticket and re-check the administrator role."""
    now = iso_now()
    with connect() as con:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute(
            "SELECT user_id FROM admin_catalog_download_tickets WHERE token_hash=? AND used_at='' AND expires_at>?",
            (hash_value(ticket), now),
        ).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Catalogue download expired or already used. Create a new export.")
        con.execute("UPDATE admin_catalog_download_tickets SET used_at=? WHERE token_hash=? AND used_at=''",
                    (now, hash_value(ticket)))
    admin_user = get_user_by_id(int(row["user_id"]))
    if not admin_user or not is_admin_telegram(int(admin_user["telegram_id"])):
        raise HTTPException(status_code=403, detail="Administrator access is no longer active.")
    with connect() as con:
        rows = con.execute(
            "SELECT category,item_id,name,rarity,enabled,created_at FROM catalog ORDER BY category,item_id"
        ).fetchall()
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer)
    writer.writerow(["category", "item_id", "name", "rarity", "enabled", "created_at"])
    for r in rows:
        writer.writerow([csv_safe_cell(r[k]) for k in ("category", "item_id", "name", "rarity", "enabled", "created_at")])
    return StreamingResponse(
        iter(["\ufeff" + buffer.getvalue()]), media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="rocks-catalogue.csv"', "Cache-Control": "no-store"},
    )


@app.delete("/api/admin/catalog/{catalog_id}")
def admin_delete_catalog(catalog_id: int, user: dict[str, Any] = Depends(require_admin)) -> dict[str, bool]:
    with connect() as con:
        row = con.execute("SELECT category,item_id FROM catalog WHERE id=?", (catalog_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Catalog ID not found.")
        cur = con.execute("DELETE FROM catalog WHERE id=?", (catalog_id,))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Catalog ID not found.")
        con.execute("DELETE FROM favorites WHERE category=? AND item_id=?", (row["category"], row["item_id"]))
    write_audit(int(user["telegram_id"]), "catalog_delete", "catalog", catalog_id,
                {"category": row["category"], "item_id": row["item_id"]})
    return {"ok": True}


@app.get("/api/admin/user/{user_id}")
def admin_user_detail(user_id: int, user: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    target = get_user_by_id(user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found.")
    with connect() as con:
        accounts = [dict(r) for r in con.execute("SELECT id,label,game_uid,created_at FROM accounts WHERE user_id=? ORDER BY id DESC", (user_id,)).fetchall()]
        results = [dict(r) for r in con.execute("SELECT id,account_id,event_name,item_id,item_name,draw_number,created_at FROM spins WHERE user_id=? AND demo=0 ORDER BY id DESC LIMIT 200", (user_id,)).fetchall()]
    return {"user": {**public_user(target), "id": target["id"], "status": target["status"]}, "accounts": accounts, "results": results, "usage": usage_for_day(user_id)}
