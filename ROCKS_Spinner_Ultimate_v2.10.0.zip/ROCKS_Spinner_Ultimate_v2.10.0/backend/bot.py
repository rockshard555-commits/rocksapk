from __future__ import annotations

import os
import re
from pathlib import Path

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

from app import (
    AVATARS_DIR, connect, create_login_code, find_or_create_user, iso_now,
    is_admin_telegram, is_owner_telegram, write_audit,
)

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "8988565588:AAFI8R6XV_afPCp6dGlWUkfPP_x5DUCHfq4").strip()


def _user_id(update: Update) -> int:
    return int(update.effective_user.id)  # type: ignore[union-attr]


async def save_profile_avatar(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    tg_user = update.effective_user
    if not tg_user:
        return ""
    try:
        photos = await context.bot.get_user_profile_photos(tg_user.id, limit=1)
        if not photos.photos:
            return ""
        best = photos.photos[0][-1]
        file = await context.bot.get_file(best.file_id)
        path = AVATARS_DIR / f"{tg_user.id}.jpg"
        await file.download_to_drive(custom_path=str(path))
        return f"/avatars/{path.name}"
    except Exception:
        return ""


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg = update.effective_user
    message = update.effective_message
    if not tg or not message:
        return
    avatar = await save_profile_avatar(update, context)
    try:
        code = create_login_code(tg.id, tg.username or "", tg.first_name or "", avatar)
    except ValueError as exc:
        await message.reply_text(f"ROCKS access unavailable: {exc}")
        return
    await message.reply_text(
        "ROCKS login key\n\n"
        f"Your one-time key: `{code}`\n"
        f"It expires in {os.getenv('LOGIN_CODE_MINUTES', '5')} minutes and can be used once.\n\n"
        "Open the ROCKS app, enter this key, and sign in.\n"
        "Use /key to request a new key.\n\n"
        "Demo mode only: this app does not connect to the game service or grant game items.",
        parse_mode="Markdown",
    )


async def key_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await start(update, context)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    if not msg:
        return
    common = "/start or /key — get a one-time app login key\n/help — show help"
    admin = "\n\nAdmin commands:\n/stats\n/users\n/user TELEGRAM_ID\n/ban TELEGRAM_ID\n/unban TELEGRAM_ID\n/addadmin TELEGRAM_ID (owner only)\n/removeadmin TELEGRAM_ID (owner only)\n/buyids\n/addid CATEGORY ITEM_ID ITEM_NAME\n/removeid CATALOG_ROW_ID"
    await msg.reply_text("ROCKS Bot\n" + common + (admin if is_admin_telegram(_user_id(update)) else ""))


async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    if not msg:
        return
    if not is_admin_telegram(_user_id(update)):
        return
    with connect() as con:
        users = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        active = con.execute("SELECT COUNT(*) FROM users WHERE status='active'").fetchone()[0]
        banned = con.execute("SELECT COUNT(*) FROM users WHERE status='banned'").fetchone()[0]
        accounts = con.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
        draws = con.execute("SELECT COUNT(*) FROM spins").fetchone()[0]
    await msg.reply_text(f"ROCKS stats\nUsers: {users}\nActive: {active}\nBanned: {banned}\nSaved account profiles: {accounts}\nDemo draws: {draws}")


async def users_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    if not msg or not is_admin_telegram(_user_id(update)):
        return
    with connect() as con:
        rows = con.execute("SELECT telegram_id,username,first_name,status FROM users ORDER BY id DESC LIMIT 15").fetchall()
    if not rows:
        await msg.reply_text("No app users yet.")
        return
    lines = [f"{r['first_name'] or 'User'} (@{r['username'] or 'no_username'}) · {r['telegram_id']} · {r['status']}" for r in rows]
    await msg.reply_text("Recent users\n" + "\n".join(lines))


async def user_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    if not msg or not is_admin_telegram(_user_id(update)):
        return
    if not context.args or not context.args[0].isdigit():
        await msg.reply_text("Usage: /user TELEGRAM_ID")
        return
    telegram_id = int(context.args[0])
    with connect() as con:
        row = con.execute("SELECT * FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
        if not row:
            await msg.reply_text("User not found.")
            return
        counts = con.execute("SELECT (SELECT COUNT(*) FROM accounts WHERE user_id=?), (SELECT COUNT(*) FROM spins WHERE user_id=?)", (row['id'], row['id'])).fetchone()
        recent = con.execute("SELECT event_name,item_name,created_at FROM spins WHERE user_id=? ORDER BY id DESC LIMIT 8", (row['id'],)).fetchall()
    lines = [f"User: {row['first_name']} (@{row['username'] or 'none'})", f"Telegram ID: {telegram_id}", f"Status: {row['status']}", f"Account profiles: {counts[0]}", f"Demo draws: {counts[1]}", "Recent demo results:"]
    lines.extend([f"• {x['event_name']}: {x['item_name']} ({x['created_at']})" for x in recent] or ["• none"])
    await msg.reply_text("\n".join(lines))


async def _set_status(update: Update, context: ContextTypes.DEFAULT_TYPE, status: str) -> None:
    msg = update.effective_message
    if not msg or not is_admin_telegram(_user_id(update)):
        return
    if not context.args or not context.args[0].isdigit():
        await msg.reply_text(f"Usage: /{ 'ban' if status == 'banned' else 'unban' } TELEGRAM_ID")
        return
    tg_id = int(context.args[0])
    with connect() as con:
        target = con.execute("SELECT id FROM users WHERE telegram_id=?", (tg_id,)).fetchone()
        if not target:
            await msg.reply_text("User not found.")
            return
        if status == "banned" and is_admin_telegram(tg_id):
            await msg.reply_text("Remove admin access before banning an administrator.")
            return
        con.execute("UPDATE users SET status=? WHERE telegram_id=?", (status, tg_id))
        if status == "banned":
            con.execute("DELETE FROM sessions WHERE user_id=?", (target['id'],))
            con.execute("UPDATE login_codes SET used_at=? WHERE user_id=? AND used_at=''", (iso_now(), target['id']))
    write_audit(_user_id(update), "user_ban" if status == "banned" else "user_unban", "user", target['id'],
                {"target_telegram_id": tg_id})
    await msg.reply_text(f"ROCKS user {tg_id}: {status}.")


async def ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _set_status(update, context, "banned")


async def unban_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _set_status(update, context, "active")


async def addadmin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    tg_id_caller = _user_id(update)
    if not msg or not is_owner_telegram(tg_id_caller):
        return
    if not context.args or not context.args[0].isdigit():
        await msg.reply_text("Usage: /addadmin TELEGRAM_ID")
        return
    target = int(context.args[0])
    with connect() as con:
        con.execute("INSERT INTO admins(telegram_id,role,added_by,created_at) VALUES(?,'admin',?,?) ON CONFLICT(telegram_id) DO NOTHING",
                    (target, tg_id_caller, iso_now()))
    write_audit(tg_id_caller, "admin_add", "admin", target)
    await msg.reply_text(f"Admin access updated for Telegram ID {target}.")


async def removeadmin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    caller = _user_id(update)
    if not msg or not is_owner_telegram(caller):
        return
    if not context.args or not context.args[0].isdigit():
        await msg.reply_text("Usage: /removeadmin TELEGRAM_ID")
        return
    target = int(context.args[0])
    if target == caller or is_owner_telegram(target):
        await msg.reply_text("The owner cannot be removed by this command.")
        return
    with connect() as con:
        con.execute("DELETE FROM admins WHERE telegram_id=?", (target,))
    write_audit(caller, "admin_remove", "admin", target)
    await msg.reply_text(f"Admin access removed for Telegram ID {target} (if it existed).")


async def buyids_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    if not msg or not is_admin_telegram(_user_id(update)):
        return
    with connect() as con:
        rows = con.execute("SELECT id,category,item_id,name FROM catalog ORDER BY category,id LIMIT 80").fetchall()
    lines = [f"#{r['id']} · {r['category']} · {r['item_id']} · {r['name']}" for r in rows]
    await msg.reply_text("ROCKS ID catalogue (demo catalogue only)\n" + ("\n".join(lines) if lines else "No IDs yet."))


async def addid_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    if not msg or not is_admin_telegram(_user_id(update)):
        return
    if len(context.args) < 3:
        await msg.reply_text("Usage: /addid CATEGORY ITEM_ID ITEM_NAME\nCategories: m4a1, emote_royale, gold_royale, ghost, evo, thailand_free, vietnam_free, cobra")
        return
    category, item_id = context.args[0], context.args[1]
    name = " ".join(context.args[2:])
    if category not in {"m4a1", "emote_royale", "gold_royale", "ghost", "evo", "thailand_free", "vietnam_free", "cobra"}:
        await msg.reply_text("Unknown category.")
        return
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", item_id) or not name.strip() or len(name) > 120:
        await msg.reply_text("Item ID must use letters, numbers, _ or -; name must be 1–120 characters.")
        return
    try:
        with connect() as con:
            con.execute("INSERT INTO catalog(category,item_id,name,rarity,enabled,created_at) VALUES(?,?,?,'demo',1,?)",
                        (category, item_id, name, iso_now()))
    except Exception:
        await msg.reply_text("Could not add ID; it may already exist.")
        return
    write_audit(_user_id(update), "catalog_add", "catalog", f"{category}:{item_id}", {"category": category, "item_id": item_id})
    await msg.reply_text(f"Added catalogue item: {item_id} — {name}")


async def removeid_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    if not msg or not is_admin_telegram(_user_id(update)):
        return
    if not context.args or not context.args[0].isdigit():
        await msg.reply_text("Usage: /removeid CATALOG_ROW_ID (see /buyids)")
        return
    with connect() as con:
        catalog_id = int(context.args[0])
        row = con.execute("SELECT category,item_id FROM catalog WHERE id=?", (catalog_id,)).fetchone()
        cur = con.execute("DELETE FROM catalog WHERE id=?", (catalog_id,))
        if row and cur.rowcount:
            con.execute("DELETE FROM favorites WHERE category=? AND item_id=?", (row["category"], row["item_id"]))
    if row and cur.rowcount:
        write_audit(_user_id(update), "catalog_delete", "catalog", catalog_id,
                    {"category": row["category"], "item_id": row["item_id"]})
    await msg.reply_text("Catalogue row removed." if cur.rowcount else "Catalogue row not found.")


def main() -> None:
    if not TOKEN:
        raise SystemExit("Set TELEGRAM_BOT_TOKEN in your environment or .env first.")
    # Initialise tables and the bootstrap owner/admin list before polling.
    from app import init_db
    init_db()
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("key", key_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("users", users_command))
    application.add_handler(CommandHandler("user", user_command))
    application.add_handler(CommandHandler("ban", ban_command))
    application.add_handler(CommandHandler("unban", unban_command))
    application.add_handler(CommandHandler("addadmin", addadmin_command))
    application.add_handler(CommandHandler("removeadmin", removeadmin_command))
    application.add_handler(CommandHandler("buyids", buyids_command))
    application.add_handler(CommandHandler("addid", addid_command))
    application.add_handler(CommandHandler("removeid", removeid_command))
    print("ROCKS Telegram bot is polling. Use Ctrl+C to stop.")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
