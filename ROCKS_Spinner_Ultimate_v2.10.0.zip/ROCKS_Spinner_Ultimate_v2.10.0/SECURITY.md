# ROCKS security notes

ROCKS stores Telegram-linked profile metadata, user-created UID labels, preferences, favourites, verified result records, sessions, login codes, and administrative audit events. The current build has no live game connector; spin/activation actions are disabled rather than simulated.

## Deployment requirements

- Terminate public traffic at HTTPS. The Android wrapper rejects non-HTTPS base URLs.
- Keep `.env`, Telegram bot tokens, database files, avatar files, and the `ROCKS_DATA_DIR` directory private. Do not mount the data directory under a public static path.
- Set `ADMIN_TELEGRAM_IDS` before starting the bot. The first ID becomes the owner; only the owner can manage admins.
- Leave `ROCKS_ENABLE_API_DOCS=false` in public deployments.
- The app best-effort restricts the private data, user, avatar, per-user file, and SQLite database permissions on POSIX systems. Keep the default single-instance SQLite deployment on durable local storage with backups. Do not share SQLite files across unrelated hosts or network filesystems.
- Rotate bot tokens immediately if they are exposed. Use restricted access to CI variables and release artifacts.
- Back up the database before upgrades. Schema migrations run when the API or bot initializes.

## Privacy and authorization

- API routes bind account/result/preferences/favourites/export data to the authenticated session's internal user ID; clients do not submit an owner ID for those operations.
- Admin endpoints have separate authorization checks. Hiding the admin UI is not the access-control mechanism.
- Download tickets are scoped to a server-side user record, single-use, and expire after two minutes.
- The user's delete-profile endpoint permanently removes the user's ROCKS record and rows with cascading ownership, their local profile folder, and cached avatar. A minimal anonymized self-service audit record is retained. It does not affect their Telegram account or game account.
- User exports include only that authenticated user's ROCKS records and verified live results (legacy simulator records are excluded). They do not include session tokens, login codes, admin credentials, or another user's data.

## Reporting an issue

Do not publish secrets, bearer tokens, private database files, or personal user data in bug reports. Provide a sanitized reproduction, affected version, and relevant error text to the project maintainer through a private channel.


## Gen, Spin and Auto Activator sources

The UI includes separate **Gen Only**, **Gen + Auto Activator**, and **Auto Activator** workspaces. Mode selection is a per-user UI preference only; it does not launch the supplied signed `Gen.py`. Its `/bind` request accepts a UID/password and expects a JWT, but the service contract/operator could not be independently verified. The v2.8.0 build archives the supplied code and reports configuration status only; it does not execute Gen/Evo/Ghost source scripts or make external activator requests. Do not enter game passwords or bearer/JWT tokens into an unverified service. The supplied spin scripts call private PurchaseGacha endpoints and external JWT services while disabling TLS verification; do not embed these flows in the backend without independent authorization, a documented contract, TLS verification, redacted logs, explicit rate limits, and user consent.
