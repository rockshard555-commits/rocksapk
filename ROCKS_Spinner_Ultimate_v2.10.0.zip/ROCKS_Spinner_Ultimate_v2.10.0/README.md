# ROCKS Spinner — v2.10.0 Admin and Feature-Readiness Source Workspace

ROCKS is a mobile-first Android WebView app, FastAPI backend, and Telegram bot. This release uses the provided event configuration and item catalogue while removing user-facing random/demo draw outcomes.

> **Live status:** the application does not currently have a verified, authorized Free Fire API connector. Spin/activation endpoints are disabled and return a clear unavailable response; no result is fabricated or claimed as a real reward. The provided `Gen.py`, `Evo_Spin.zip`, and `Ghost_Spin.zip` are preserved in `supplied_inputs/` for reference and are not executed by the web app. No APK has been compiled as part of this package.

## What's new in v2.10.0

- Default owner Telegram ID is `8664344820` when `ADMIN_TELEGRAM_IDS` is blank or unset. Explicit configuration overrides this default.
- Regression coverage increased to 54 passing tests.
- Safe local app features remain available; live game spin and activation actions remain disabled until an authorized connector is verified.

### Previous v2.8.0 changes

- Region registry expanded to 16 entries (the original 15 plus `RU` Russia). All 16 region endpoint URLs are saved from the user-provided map and explicitly marked not live-verified.
- M4A1 Ring, Emote Royale and Gold Royale map their source-listed Russia entries to `RU` instead of the former `CIS` fallback. Event-specific availability stays tied to the supplied event files; the app does not invent missing per-region payloads.
- Evo and Ghost retain their source-derived payload references for ME and TW respectively. All seven event workspaces are catalogued, but live spin execution stays off until the live connector can be independently authorized and verified.

- Imported and retained source event metadata from the supplied regional text files and source bundles, including item IDs, server mapping, and payload reference values.
- Preserved `Gen.py` byte-for-byte; `Cobra.txt` remains excluded as requested.
- Changed general, Evo, and Ghost spin controls to live-only guarded actions: no random demo reward is returned, and the UI identifies the missing connector.
- Added `/api/live/status`; public spin routes return HTTP 503 until a documented, authorized connector is configured.
- Result/history endpoints and exports show only verified live records (`demo=0`), not prior simulated rows.
- Kept user profiles/preferences, catalogue and admin flows, offline cached catalogue, themes, and mobile-first navigation.
- Added `supplied_inputs/` as a source/reference archive. The provided third-party APK and screenshots are references only; this ZIP is not a compiled APK.

## Existing v2.0 foundation

### Android/app experience

- Seven coordinated, selectable themes: **ROCKS Grid** (default), **Midnight**, **Rose Quartz**, **Crimson Protocol**, **Ocean Matrix**, **Amethyst**, and **Arctic Light**.
- The default ROCKS Grid theme uses an original ROCKS emblem, green terminal rain, scanlines, and terminal-style status text. Item artwork may load from the linked catalogue image host; failed or unknown images fall back to local ROCKS artwork.
- Independent top-level **Gen**, **Evo Spin**, and **Ghost Spin** sections. They remain separate rather than merging their controls or histories.
- General spinner for M4A1 Ring, Emote Royale, Gold Royale, Thailand Free, and Token Tower (Cobra Rage Bundle).
- Private user workspace with profile, personal UID directory, favourites, searchable/paginated result history, CSV/JSON export, and profile deletion.
- Server-side personal preferences: theme, general/Evo/Ghost regions, catalogue category/search, result search/event/region filters, Ultra Rare vibration preference, and the selected Gen workflow (Gen Only or Gen + Auto Activator).
- Result reveal styling remains available for verified connector responses; it is not triggered by local random results.
- Numeric-ID artwork uses the verified source URLs recorded in the catalogue. App-facing lookup links use neutral labels; source URL metadata is retained for traceability. Failed item images are hidden while their item entry remains visible. Network access is needed for remote item images.
- Android shell has HTTPS-only navigation, safe browsing, mixed-content blocking, external-link handoff, progress/error/retry screen, and scoped download handling for expiring private export links. App version is 2.8.0.

### User data and security

- Telegram one-time login keys (five-minute default expiry) and seven-day default sessions.
- Every user's saved UID references, verified results, favourites, preferences, exports, and module history are scoped to that authenticated user's internal database ID.
- APIs never trust a client-supplied owner ID for personal data. Account ownership is checked on draw, read, and delete operations.
- Search/filter/theme preferences are saved server-side. The browser clears pending preference saves at logout and binds delayed saves to the session that initiated them.
- User-controlled JSON export, CSV result export, and permanent deletion of that user's ROCKS profile.
- Download links are server-issued, single-use, user-bound, and expire after two minutes.
- API security headers, API docs disabled by default, input validation, one-time login-code checks, login throttling, and bounded request controls reserved for any future authorized connector.
- Admin-only API checks, owner-only admin management, and an administrative audit log. Catalogue imports are bounded/validated and duplicate IDs are skipped instead of overwriting existing data.
- User-data directory and SQLite runtime database are not shipped in this source ZIP.

### Admin and catalogue operations

- User status management (ban/unban), staff-only activity and result reviews, role-aware admin management, catalogue add/remove tools, and audit history.
- Catalogue favourites are stored per user, not globally. Deleting an item also clears stale references from user favourites.
- Administrators can import a JSON array/object of up to 200 catalogue rows per request; each row is validated and duplicate category/item IDs are skipped rather than overwritten. The admin catalogue CSV export uses its own single-use, short-lived download ticket.
- Catalogue import/export is admin-only, validates the input size and fields, neutralizes spreadsheet formula cells in CSV output, and writes an audit entry.
- Telegram bot commands include `/start`, `/key`, `/help`, `/stats`, `/users`, `/user TELEGRAM_ID`, `/ban TELEGRAM_ID`, `/unban TELEGRAM_ID`, `/addadmin TELEGRAM_ID`, `/removeadmin TELEGRAM_ID`, `/buyids`, `/addid CATEGORY ITEM_ID ITEM_NAME`, and `/removeid CATALOG_ROW_ID`.
- Normal users are limited to 1,111 new account profiles per UTC day by default; admins bypass this profile-creation cap. This is not a live-game account generator.

## Region and event rules

All 16 regions remain visible: IND (India), BD (Bangladesh), PK (Pakistan), ME (Middle East), BR (Brazil), US (United States), ID (Indonesia), SG (Singapore), TH (Thailand), VN (Vietnam), TW (Taiwan), CIS, EU, SAC (South America), NA (North America), and RU (Russia).

Event/region metadata is imported from the provided reference files and is **not a live check of current game servers**. The app shows the imported coverage, but all spin controls are disabled and write endpoints return HTTP 503 until a documented, authorized live connector is configured. The configured coverage in this bundle is:

| Event | Configured regions |
|---|---|
| M4A1 Ring | IND, BD, PK, ID, TH, VN, SG, ME, EU, RU, NA, SAC |
| Gold Royale | IND, BD, PK, ID, TH, VN, SG, ME, EU, RU, NA, SAC |
| Emote Royale | BD, SG, EU, RU, NA |
| Thailand Free | TH and VN, with region-specific item metadata |
| Evo Spin | ME |
| Ghost Spin | TW |
| Token Tower (Cobra Rage Bundle) | TW only |

The user-provided Event 10 configuration is **Token Tower — Cobra Rage Bundle** (ID `710026009`), marked `FREE (0 Diamonds)` in the supplied data, Taiwan (`TW`) only; this status has not been live-verified. Its hex `0822100118ff2a200160006802` is retained only as non-executable metadata. `Cobra.txt` remains excluded as requested. The other supplied payload strings are not executed by this app either.

## Live functionality status

- **Catalogue and app workspace:** the web UI, per-user profile/preferences, catalogue browsing, favorites, admin tools, backend, and Telegram login flow are actual application code and can run after deployment/configuration.
- **Gen:** the supplied `Gen.py` is preserved byte-for-byte in `supplied_inputs/Gen.py`. The web app does not execute it or forward game credentials to the external token/activator endpoints it references.
- **Evo/Ghost:** the supplied archives are preserved in `supplied_inputs/`. The web app does not execute their private game-endpoint requests. Their controls are disabled rather than returning fake items.
- **General spinner:** uses the user's regional text/configuration data for browsing only. `POST /api/spins` returns HTTP 503 and does not write a result.
- **Auto Activator:** status/configuration only. It remains disconnected until an authorized and documented API contract is available.
- **Results/history:** only records marked as verified live (`demo=0`) are returned. Old simulator records, if any exist in an upgraded database, are not shown as real rewards or included in results exports.
- **Payloads:** hex strings are preserved as reference data only; the app does not submit them to game endpoints.

### Supplied input handling

`supplied_inputs/` keeps the relevant original files for audit and reference. `Gen.py` is byte-for-byte unchanged, including its original embedded author notice. The event catalogue incorporates the item IDs, region notes, and payload reference values from `M4a1.txt`, `Emote Royale.txt`, `Gold Royale.txt`, `Thailand Free.txt`, and the supplied Evo/Ghost bundles. The existing APK and screenshots are stored as references only; they are not silently passed off as a newly compiled ROCKS APK. `Cobra.txt` is intentionally omitted because you previously asked to ignore it. Any UID/password list is not bundled into the distributable. All supplied non-excluded input files currently available in the workspace are retained under `supplied_inputs/`; only `Cobra.txt` is excluded by your earlier instruction.

A live implementation needs an authorized API specification/credentials supplied through a secure backend integration; the current user-provided scripts alone do not establish authorization or a safe connector contract. This package does not pretend that the connection exists.

## Android APK build

See [`BUILD_APK.md`](BUILD_APK.md) for the GitHub Actions build steps. A usable APK requires a deployed HTTPS backend URL; no v2.8.0 APK is included in this source archive.

## Repository layout

```text
backend/app.py                         FastAPI API, database, authentication, policies
backend/bot.py                         Telegram login-key bot and authorized admin commands
backend/data/rocks_catalogue.json      Bundled item, region, event configuration
backend/static/index.html              ROCKS app screens
backend/static/app.js                 Frontend state, navigation and API calls
backend/static/style.css               Themes and responsive UI
android/                               Android Studio WebView shell
scripts/backup_db.py                   Verified private SQLite backup with retention
scripts/restore_db.py                  Verified restore with pre-restore snapshot
tests/                                 Regression, region, privacy, and access tests
.github/workflows/android-apk.yml      Test first, then build APK artifact
SECURITY.md                            Deployment/privacy/security notes
```

## Run locally (backend + bot)

Requirements: Python 3.10+, pip, and a Telegram bot token. The runtime uses SQLite.

1. Create a bot with Telegram `@BotFather`.
2. Copy `.env.example` to `.env`; fill in `TELEGRAM_BOT_TOKEN` and `ADMIN_TELEGRAM_IDS`. The **first numeric ID is the owner**; later IDs are regular admins. The default owner ID is `8664344820`; replace it with your own numeric Telegram ID if needed. Never share the token.
3. Install requirements and tests:

   ```bash
   python -m venv .venv
   # Linux/macOS/Termux:
   source .venv/bin/activate
   pip install -r requirements-dev.txt
   ```

4. Start the backend:

   ```bash
   ./run_backend.sh
   ```

5. In a separate terminal, start the Telegram bot:

   ```bash
   ./run_bot.sh
   ```

6. Open `http://127.0.0.1:8000` for local development and obtain a one-time key in the bot using `/start`. Keep HTTP development local/private. Public deployment requires HTTPS and a configured Android `APP_BASE_URL`.

### Docker Compose

After setting the `.env` file, run:

```bash
docker compose up --build -d
```

The API and bot run separately and share the durable SQLite volume. Keep the runtime database and avatar directory private and outside any public static directory. This SQLite setup is intended for a single host/app deployment, not multiple unrelated hosts sharing a database file.

### Backup and restore

Create a consistent SQLite online backup and keep the newest seven backup files by default:

```bash
python scripts/backup_db.py --keep 7
```

The default backup directory is `./backups/` (or `ROCKS_BACKUP_DIR`). Backups are integrity-checked and checked for the required ROCKS schema before being copied. Files are made private on POSIX systems, and retention only removes matching `rocks-*.sqlite3` files from that output directory.

For a Docker Compose deployment, store backups on the persistent data volume:

```bash
docker compose exec api python /app/scripts/backup_db.py --source /data/rocks.sqlite3 --output-dir /data/backups --keep 7
```

To restore, **stop the API and Telegram bot first**. The source is checked for SQLite integrity and the required ROCKS core tables/columns. `--force` is required to replace an existing database; the restore utility first snapshots the current database into `data/backups/`.

```bash
python scripts/restore_db.py ./backups/rocks-YYYYMMDDTHHMMSSffffffZ.sqlite3 --data-dir ./data --force
```

For Docker, after stopping services, run a one-off container against the same volume using the full backup filename:

```bash
docker compose run --rm api python /app/scripts/restore_db.py /data/backups/rocks-BACKUP-FILENAME.sqlite3 --data-dir /data --force
```

Always verify the path before restoring; a restore replaces the active database. The utilities protect against accidental overwrite but cannot determine whether the API or bot is still running.

## Run tests and checks

From the project root:

```bash
pip install -r requirements-dev.txt
pytest -q
python -m py_compile backend/app.py backend/bot.py
node --check backend/static/app.js
```

The GitHub workflow performs those checks before attempting the Android APK build.

## Build the Android APK

The `android/` directory contains a Gradle Android Studio project. The APK requires the backend to be deployed and reachable over HTTPS; it is not a self-contained offline spinner.

### Android Studio

1. Deploy the backend and Telegram bot behind a trusted HTTPS endpoint.
2. Open `android/` in Android Studio and install Android SDK platform/build tools for API 35.
3. Add `APP_BASE_URL=https://your-real-domain.example` to `android/gradle.properties` (or pass it with `-PAPP_BASE_URL=...`).
4. Build with **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

### GitHub Actions build

1. Push the project to a GitHub repository.
2. Deploy the API over HTTPS.
3. Go to **Settings → Secrets and variables → Actions → Variables** and add repository variable `APP_BASE_URL` with the HTTPS base URL.
4. Run **Actions → Test and build ROCKS Android APK → Run workflow**.
5. Download the `rocks-spinner-debug-apk` artifact from the completed run.

The workflow runs backend tests and syntax checks first; it refuses to build the app if `APP_BASE_URL` is missing or not HTTPS. The resulting APK still requires the configured backend and Telegram bot to be running.

## Environment settings

| Setting | Default | Purpose |
|---|---:|---|
| `TELEGRAM_BOT_TOKEN` | required for bot | Telegram bot credential; keep secret |
| `ADMIN_TELEGRAM_IDS` | `8664344820` | Comma-separated numeric IDs; first is owner |
| `DAILY_ACCOUNT_LIMIT` | `1111` | Non-admin profile creations per UTC day |
| `LOGIN_CODE_MINUTES` | `5` | Login key expiry in minutes |
| `SESSION_DAYS` | `7` | Session lifetime in days |
| `ROCKS_ENABLE_API_DOCS` | `false` | Enable `/docs` only for controlled development |
| `ROCKS_DATA_DIR` | project `data/` | Private persistent backend data directory |

Read `SECURITY.md` before deploying publicly. Never ship `.env`, runtime SQLite databases, avatar files, bearer sessions, Telegram tokens, or other user's data inside the APK or source archive.


## v2.1.0 catalogue audit

See [`CATALOGUE_AUDIT.md`](CATALOGUE_AUDIT.md) for regional hex-reference coverage, item-ID artwork links, and remaining verification gaps. Cobra is configured as Event 10 — Token Tower, FREE (0 Diamonds), Taiwan only, reward ID 710026009. Gold Royale catalogue entries use the user-provided rewards Electro Butterfly Bundle (710054027) and Thompson- Freezing Flame (907102829), marked FREE (0 Gold) in the supplied data but not live-verified. Both are classified Ultra Rare according to the user-confirmed ROCKS rarity groups. All hex values are non-executable reference metadata. Live spin controls remain disabled until a documented, authorized live connector is configured.


## Catalogue readiness

Gold Royale now has Electro Butterfly Bundle (710054027) and Thompson- Freezing Flame (907102829), FREE (0 Gold); `Gold Royale.txt` supplies region-specific reference hexes, which remain non-executable. Item IDs `907103324` and `205055022` still use the ROCKS placeholder until an exact direct icon is confirmed. ID `205055021` has a name mismatch between supplied data and a lookup result, so no potentially incorrect icon is used. Lookup links remain available on their item cards. Some translated names returned by image lookup do not match the labels in supplied data; details are noted in `CATALOGUE_AUDIT.md`.


## v2.3.0 Gold Royale update

- Added **Electro Butterfly Bundle** (ID `710054027`) and **Thompson- Freezing Flame** (ID `907102829`) to Gold Royale based on user-provided details.
- Mode: **FREE (0 Gold)**; status is user-provided and not live-verified.
- Both direct images are linked from source item pages matching the numeric IDs; item cards provide neutral image-reference and alternate-reference links.
- Both rewards are classified **Ultra Rare** using the user-confirmed ROCKS rarity list. All 25 item rarity classifications are included in the catalogue.
- Event hexes remain non-executable reference metadata; no spin controls generate random or simulated rewards, and live actions are disabled until an authorized connector is configured.


## ROCKS rarity classifications (v2.3.0)

All 25 item rarity values were updated from the user-confirmed classification list dated 2026-10-20. `ultra_rare` items use the Ultra Rare reveal treatment; Parachute - Spirit of War (`905000065`) remains `rare`. These are ROCKS-specific classifications and do not claim to be official in-game rarity labels.


## v2.8.0 — ROCKS visual identity update

- Replaced the active app's third-party mask artwork with an original ROCKS emblem and a ROCKS launcher icon.
- Renamed theme labels to ROCKS Grid, Midnight, and Rose Quartz; kept the underlying stored theme keys so existing preferences continue to work.
- Replaced third-party catalogue-site names in app-facing link labels with neutral reference labels while retaining the original source URLs and item lookups.
- Updated the Android package version to 2.8.0 (versionCode 11). No account, event, or spin logic was removed.
- Original source archives are preserved unchanged as reference materials. Their embedded attribution/copyright notices and third-party APK branding are not modified; those materials are not used as the ROCKS app's active visual identity.
- This is a source package. The Android APK still needs to be built with a configured HTTPS backend URL. Live game endpoints remain disabled in this release.
