# ROCKS Spinner v2.10.0 — Default owner and safe feature readiness

- Default owner Telegram ID: `8664344820` when `ADMIN_TELEGRAM_IDS` is unset or blank.
- An explicit `ADMIN_TELEGRAM_IDS` value still takes precedence; the first numeric ID is the owner and subsequent IDs are admins.
- The app's supported local features remain available: account profiles, preferences/themes, catalog browsing and management, favorites, results/history views, event/region metadata, and admin controls.
- Live Free Fire spins and activation are **not enabled**. The project has no verified, authorized live connector, and reference payloads remain non-executable. The UI must not claim a live reward or send account credentials to undocumented/private endpoints.
- No APK was built in this environment.
