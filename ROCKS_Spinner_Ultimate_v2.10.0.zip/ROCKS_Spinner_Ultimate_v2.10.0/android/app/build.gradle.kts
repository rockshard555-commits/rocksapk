plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val appBaseUrl = (project.findProperty("APP_BASE_URL") as String?) ?: "https://YOUR-DOMAIN"

android {
    namespace = "com.rocks.spinner"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rocks.spinner"
        minSdk = 26
        targetSdk = 35
        versionCode = 11
        versionName = "2.8.0"
        buildConfigField("String", "APP_BASE_URL", "\"$appBaseUrl\"")
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
