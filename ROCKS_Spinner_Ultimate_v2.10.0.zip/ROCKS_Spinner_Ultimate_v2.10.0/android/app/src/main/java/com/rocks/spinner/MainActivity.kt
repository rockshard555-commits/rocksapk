package com.rocks.spinner

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.graphics.Color
import android.net.http.SslError
import android.os.Environment
import android.os.Bundle
import android.view.ViewGroup
import android.view.Gravity
import android.webkit.SslErrorHandler
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.CookieManager
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Button
import android.widget.Toast
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var rootLayout: FrameLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var errorPanel: LinearLayout
    private var baseUri: Uri? = null
    private var pageFailed = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 13, 18)
        window.navigationBarColor = Color.rgb(9, 13, 18)
        window.decorView.systemUiVisibility = 0

        val rawUrl = BuildConfig.APP_BASE_URL.trim().trimEnd('/')
        val uri = runCatching { Uri.parse(rawUrl) }.getOrNull()
        if (uri == null || uri.scheme != "https" || uri.host.isNullOrBlank() || uri.host == "YOUR-DOMAIN") {
            showConfigurationMessage()
            return
        }
        baseUri = uri
        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(9, 13, 18))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        webView.settings.safeBrowsingEnabled = true
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false)
        rootLayout = FrameLayout(this)
        rootLayout.setBackgroundColor(Color.rgb(9, 13, 18))
        rootLayout.addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            progress = 0
        }
        rootLayout.addView(progressBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 4, Gravity.TOP))
        errorPanel = buildNetworkErrorPanel()
        errorPanel.visibility = ViewGroup.GONE
        rootLayout.addView(errorPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress >= 100 || pageFailed) ViewGroup.GONE else ViewGroup.VISIBLE
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                pageFailed = false
                errorPanel.visibility = ViewGroup.GONE
                progressBar.progress = 0
                progressBar.visibility = ViewGroup.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = ViewGroup.GONE
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val dest = request?.url ?: return true
                val root = baseUri ?: return true
                val sameOrigin = dest.scheme == "https" && dest.host == root.host && dest.port == root.port
                if (sameOrigin) return false
                if (dest.scheme != "https" && dest.scheme != "http") {
                    Toast.makeText(this@MainActivity, "Blocked unsupported link type", Toast.LENGTH_SHORT).show()
                    return true
                }
                Toast.makeText(this@MainActivity, "External links open in your browser", Toast.LENGTH_SHORT).show()
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, dest)) }
                return true
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    pageFailed = true
                    progressBar.visibility = ViewGroup.GONE
                    errorPanel.visibility = ViewGroup.VISIBLE
                }
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel()
                pageFailed = true
                progressBar.visibility = ViewGroup.GONE
                errorPanel.visibility = ViewGroup.VISIBLE
            }
        }
        webView.setDownloadListener { url, _, _, mimeType, _ ->
            val dest = runCatching { Uri.parse(url) }.getOrNull()
            val root = baseUri
            val valid = dest != null && root != null && dest.scheme == "https" && dest.host == root.host &&
                dest.port == root.port && (dest.path ?: "").matches(Regex("/api/(?:download|admin/catalog/download)/[A-Za-z0-9_-]+"))
            if (!valid || dest == null) {
                Toast.makeText(this, "Blocked untrusted download", Toast.LENGTH_LONG).show()
                return@setDownloadListener
            }
            try {
                val ext = if ((mimeType ?: "").contains("csv", ignoreCase = true)) "csv" else "json"
                val request = DownloadManager.Request(dest)
                    .setTitle("ROCKS private export.$ext")
                    .setDescription("Your one-time ROCKS data export")
                    .setMimeType(mimeType ?: "application/octet-stream")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setAllowedOverMetered(true)
                    .setAllowedOverRoaming(false)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "ROCKS-export-${System.currentTimeMillis()}.$ext")
                val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                manager.enqueue(request)
                Toast.makeText(this, "Export downloading to Downloads", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                Toast.makeText(this, "Unable to start download. Try again.", Toast.LENGTH_LONG).show()
            }
        }
        setContentView(rootLayout, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (savedInstanceState == null) webView.loadUrl(rawUrl) else webView.restoreState(savedInstanceState)
    }

    private fun buildNetworkErrorPanel(): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 40, 36, 40)
            setBackgroundColor(Color.rgb(9, 13, 18))
        }
        val title = TextView(this).apply {
            text = "ROCKS is temporarily unavailable"
            setTextColor(Color.rgb(226, 189, 116))
            textSize = 23f
            gravity = Gravity.CENTER
        }
        val body = TextView(this).apply {
            text = "Check your connection or try again. Your private data remains on the backend."
            setTextColor(Color.rgb(174, 189, 190))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 24)
        }
        val retry = Button(this).apply {
            text = "Retry connection"
            setOnClickListener {
                errorPanel.visibility = ViewGroup.GONE
                pageFailed = false
                progressBar.visibility = ViewGroup.VISIBLE
                webView.reload()
            }
        }
        layout.addView(title)
        layout.addView(body)
        layout.addView(retry)
        return layout
    }

    private fun showConfigurationMessage() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
            setBackgroundColor(Color.rgb(9, 13, 18))
        }
        val title = TextView(this).apply {
            text = "ROCKS Spinner"
            setTextColor(Color.rgb(226, 189, 116))
            textSize = 27f
        }
        val body = TextView(this).apply {
            text = "Configure the deployed HTTPS backend URL when building the app.\n\nExample:\n./gradlew assembleDebug -PAPP_BASE_URL=https://your-domain.example\n\nThe backend must be running and reachable before login."
            setTextColor(Color.rgb(220, 226, 222))
            textSize = 15f
            setPadding(0, 22, 0, 0)
        }
        layout.addView(title)
        layout.addView(body)
        setContentView(layout)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
