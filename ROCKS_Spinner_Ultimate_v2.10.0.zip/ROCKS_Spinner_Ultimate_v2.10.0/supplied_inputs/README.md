# Supplied input archive

These files are retained to preserve source context. `Gen.py` is unchanged byte-for-byte. The regional text files were imported into `../backend/data/rocks_catalogue.json`. Evo/Ghost archives are retained but not executed by the web app. The original APK and screenshots are reference material only. `Cobra.txt` is intentionally not included, following the prior instruction to ignore it. No account/password database is bundled here.

See `SOURCE_MANIFEST.json` for byte sizes and SHA-256 hashes.
