# ROCKS v2.8.0 — Event, region endpoint and item-data audit

## Confirmed user-provided Cobra configuration

- Event: **10 — Token Tower**
- Reward: **Cobra Rage Bundle**
- Item ID: `710026009`
- Mode: `FREE (0 Diamonds)`
- Status: `FREE AVAILABLE` (user-provided configuration, not live-verified)
- Region: Taiwan (`TW`) only
- Reference hex: `0822100118ff2a200160006802`
- The reference hex is metadata only; the project does not execute it as a live game request.
- The excluded `Cobra.txt` is not used; its unrelated item entry was removed from the catalogue and is removed from older databases on upgrade.

## Confirmed item IDs from the provided event data/scripts and Gold Royale update

| Category | Item ID | Label in supplied data | Artwork status |
|---|---:|---|---|
| M4A1 | 907104202 | M4A1 - Sunrise Realm | direct source image linked |
| M4A1 | 907104019 | P90 - Bunny's Order | direct ID-page image linked; localized name may differ |
| M4A1 | 907103324 | MAG-7 - Shadow Rogue | exact item page link; direct image not confirmed |
| M4A1 | 905000065 | Parachute - Spirit of War | direct source image linked |
| Emote Royale | 909046001 | Aura Boarder | direct source image linked |
| Emote Royale | 909036001 | Ghost Float | direct source image linked |
| Emote Royale | 909055005 | Broken Cry | direct source image linked |
| Emote Royale | 909000049 | Fancy Hands | direct ID-page image linked; translated label may differ |
| Ghost | 710055013 | Hollow Man Bundle | direct source image linked |
| Ghost | 710055014 | Crimson Glitches Bundle | direct source image linked |
| Evo | 907195111 | M60 - Dreambreaker | direct source image linked |
| Evo | 907193501 | M1887 - Sterling Conqueror | direct ID-page image linked; source title/name needs confirmation |
| Evo | 907192601 | MP40 - Predatory Cobra | direct source image linked |
| Evo | 907193511 | AN94 - Evil Howler | direct source image linked |
| Thailand Free | 710028027 | Ballsy Skaterboi Bundle | direct ID-page image linked; source title/name needs confirmation |
| Thailand Free | 710000021 | English Uniform Bundle (Male) | direct ID-matched source image linked |
| Thailand Free | 710000022 | English Uniform Bundle (Female) | direct ID-matched source image linked |
| Thailand Free | 710046028 | Aero Flex Bundle | direct source image linked |
| Thailand Free | 211055028 | Infernosaur (Mask) | direct source image linked |
| Thailand Free | 211055030 | Firesaur (Mask) | direct source image linked |
| Thailand Free | 205055021 | Infernosaur (Shoes) | source name conflict; image withheld pending confirmation |
| Thailand Free | 205055022 | Firesaur (Shoes) | direct image not yet confirmed |
| Cobra / Token Tower | 710026009 | Cobra Rage Bundle | direct source image linked |
| Gold Royale | 710054027 | Electro Butterfly Bundle | direct image linked; app rarity awaiting user choice |
| Gold Royale | 907102829 | Thompson- Freezing Flame | direct image linked; app rarity awaiting user choice |

## Gold Royale rewards supplied by the user

Gold Royale is configured from the user-provided data as **FREE (0 Gold)** (not live-verified) with these rewards:

| Item ID | Item name | Source rarity | ROCKS group | Artwork status |
|---:|---|---|---|---|
| 710054027 | Electro Butterfly Bundle | Epic++ | Ultra Rare (user-confirmed ROCKS group) | direct image linked from ID-matched page |
| 907102829 | Thompson- Freezing Flame | Epic | Ultra Rare (user-confirmed ROCKS group) | direct image linked from ID-matched page |

Detail pages: [Electro Butterfly Bundle (710054027)](https://www.freefiremania.com.br/items/electro-butterfly-bundle.html) and [Thompson- Freezing Flame (907102829)](https://www.freefiremania.com.br/items/thompson-freezing-flame.html). Source-listed rarities are taken from the linked item records; the ROCKS Rare/Ultra Rare grouping is a separate user choice.

`Gold Royale.txt` contributes regional hex strings only. Reward names and IDs are now populated; the event remains user-provided rather than live-verified. Spin actions are disabled; the app does not generate simulated reward results.

For image matching, the following listed IDs still use the ROCKS placeholder because an exact ID-matched direct icon was not confirmed: `907103324` and `205055022`. ID `205055021` has a source-name conflict: an item lookup returned “REXclusivo (shoes)” for that number, while the supplied catalogue calls it “Infernosaur Shoes”; no potentially incorrect image was applied. The two specified source lookup links remain available on the item card/API.

Two source-page item names differ from the supplied labels for IDs `907193501` and `710028027`. The source images were selected by numeric ID as requested, but please confirm if those display labels should be updated to match the source catalogue. `907104019` and `909000049` also use localized source names.

## Payload reference coverage

The regional values supplied in `M4a1.txt`, `Emote Royale.txt`, `Gold Royale.txt`, and `Thailand Free.txt` are preserved in the JSON catalogue. Evo and Ghost reference values are retained from their supplied modules. All entries have `payload_execution_enabled: false`; the app displays catalogue/reference metadata only and refuses spin actions until a live connector is configured.

Artwork source lookup URLs are recorded per item for traceability. The app uses neutral link labels; when an exact source page is known, the corresponding item-detail URL is retained.


## v2.8.0 live-connector note

The current app is no longer presented as a functioning demo spinner. Spin endpoints return HTTP 503 and the UI does not generate local random reward records. Event hexes and original source bundles are retained for review only. Gen.py is preserved byte-for-byte; Evo/Ghost and activator code are not executed by the web app. A documented, authorized live connector is required before any actual game request can be enabled.


## v2.8.0 — 16 region endpoint registry

The region registry contains the original 15 region entries plus `RU` (Russia), for 16 entries total. The `endpoint_url` values are copied from the user-provided `REGION_URLS` map, and are marked `endpoint_live_verified: false`. These are routing configuration values only: they do not establish that a particular event is active in that region, that a payload is accepted, or that a reward is granted.

The supplied M4A1, Emote Royale, and Gold Royale lists use a Russia entry; v2.8.0 maps those entries to the explicit `RU` region rather than the older fallback `CIS` label. `CIS` remains selectable in the region registry, but it is not added to an event's supported region list unless the supplied event file explicitly lists it. All seven event workspaces remain present: M4A1 Ring, Emote Royale, Gold Royale, Thailand Free, Token Tower (Cobra), Evo Guns Ring, and Ghost Bundle Ring. `Evo` and `Ghost` payloads remain source-derived references scoped to their supplied regions (ME and TW, respectively). No payload is transmitted by this build; no spin result is fabricated.
