#!/usr/bin/env python3
"""Restore a verified ROCKS SQLite backup; requires an explicit --force to replace data."""
from __future__ import annotations

import argparse
import os
import sqlite3

from dotenv import load_dotenv
from datetime import datetime, timezone
from pathlib import Path

try:
    from .backup_db import backup_database, verify_database, verify_rocks_schema
except ImportError:  # Running as `python scripts/restore_db.py`.
    from backup_db import backup_database, verify_database, verify_rocks_schema

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")


def restore_database(source: Path, destination: Path, force: bool = False) -> Path:
    source = Path(source).expanduser().resolve()
    destination = Path(destination).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"Backup file does not exist: {source}")
    if source == destination:
        raise ValueError("Restore source and target must differ.")
    verify_rocks_schema(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and not force:
        raise FileExistsError("The current database exists. Stop ROCKS services and pass --force to replace it.")

    pre_restore = None
    if destination.exists():
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        backup_dir = destination.parent / "backups"
        pre_restore = backup_database(destination, backup_dir / f"rocks-pre-restore-{stamp}.sqlite3")

    temporary = destination.with_name(f".{destination.name}.restore.tmp")
    temporary.unlink(missing_ok=True)
    try:
        source_connection = sqlite3.connect(str(source), timeout=30)
        target_connection = sqlite3.connect(str(temporary), timeout=30)
        try:
            source_connection.backup(target_connection)
            result = target_connection.execute("PRAGMA integrity_check").fetchone()
            if not result or result[0] != "ok":
                raise RuntimeError(f"Restored copy integrity check failed: {result[0] if result else 'no result'}")
        finally:
            target_connection.close()
            source_connection.close()
        try:
            temporary.chmod(0o600)
        except OSError:
            pass
        # Services must be stopped first so stale WAL/SHM files cannot be reused.
        for suffix in ("-wal", "-shm"):
            Path(str(destination) + suffix).unlink(missing_ok=True)
        os.replace(temporary, destination)
        if pre_restore:
            print(f"Previous database backed up to: {pre_restore}")
        return destination
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("backup", type=Path, help="source rocks-*.sqlite3 backup file")
    parser.add_argument("--data-dir", type=Path, default=Path(os.getenv("ROCKS_DATA_DIR", ROOT / "data")),
                        help="target ROCKS data directory (default: ROCKS_DATA_DIR or ./data)")
    parser.add_argument("--force", action="store_true", help="replace the existing DB after taking a pre-restore backup")
    args = parser.parse_args()
    target = args.data_dir / "rocks.sqlite3"
    print("STOP the ROCKS API and Telegram bot before restoring.")
    restored = restore_database(args.backup, target, force=args.force)
    print(f"Verified ROCKS database restored: {restored}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
