#!/usr/bin/env python3
"""Create and verify a private, consistent SQLite online backup for ROCKS."""
from __future__ import annotations

import argparse
import os
import sqlite3

from dotenv import load_dotenv
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")


def verify_database(path: Path) -> None:
    path = Path(path).expanduser()
    if not path.is_file():
        raise FileNotFoundError(f"SQLite database does not exist: {path}")
    connection = sqlite3.connect(str(path), timeout=15)
    try:
        result = connection.execute("PRAGMA integrity_check").fetchone()
        if not result or result[0] != "ok":
            raise RuntimeError(f"SQLite integrity check failed for {path}: {result[0] if result else 'no result'}")
    finally:
        connection.close()


ROCKS_REQUIRED_COLUMNS = {
    "users": {"id", "telegram_id", "username", "first_name", "avatar_path", "status", "created_at", "last_seen_at"},
    "catalog": {"id", "category", "item_id", "name", "rarity", "enabled", "created_at"},
    "accounts": {"id", "user_id", "label", "game_uid", "created_at"},
    "spins": {"id", "user_id", "account_id", "event_key", "event_name", "item_id", "item_name", "draw_number", "created_at"},
}


def verify_rocks_schema(path: Path) -> None:
    """Reject unrelated or incomplete SQLite files before operational backup/restore."""
    verify_database(path)
    connection = sqlite3.connect(str(path), timeout=15)
    try:
        tables = {
            row[0] for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        }
        missing_tables = set(ROCKS_REQUIRED_COLUMNS) - tables
        if missing_tables:
            raise RuntimeError(
                "Not a ROCKS database: missing required tables " + ", ".join(sorted(missing_tables))
            )
        missing_columns = []
        for table, required in ROCKS_REQUIRED_COLUMNS.items():
            columns = {row[1] for row in connection.execute(f'PRAGMA table_info("{table}")').fetchall()}
            missing = required - columns
            if missing:
                missing_columns.append(f"{table} ({', '.join(sorted(missing))})")
        if missing_columns:
            raise RuntimeError(
                "Not a compatible ROCKS database: missing required columns " + "; ".join(missing_columns)
            )
    finally:
        connection.close()


def backup_database(source: Path, destination: Path) -> Path:
    source = Path(source).expanduser().resolve()
    destination = Path(destination).expanduser().resolve()
    if source == destination:
        raise ValueError("Backup destination must differ from the source database.")
    if not source.is_file():
        raise FileNotFoundError(f"Source SQLite database does not exist: {source}")
    parent_existed = destination.parent.exists()
    destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not parent_existed:
        try:
            destination.parent.chmod(0o700)
        except OSError:
            pass
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite an existing backup: {destination}")
    source_connection = None
    backup_connection = None
    try:
        source_connection = sqlite3.connect(str(source), timeout=30)
        backup_connection = sqlite3.connect(str(destination), timeout=30)
        source_connection.backup(backup_connection)
        result = backup_connection.execute("PRAGMA integrity_check").fetchone()
        if not result or result[0] != "ok":
            raise RuntimeError(f"Backup integrity check failed: {result[0] if result else 'no result'}")
        backup_connection.close(); backup_connection = None
        source_connection.close(); source_connection = None
        try:
            destination.chmod(0o600)
        except OSError:
            pass  # Windows filesystems may not implement POSIX permission bits.
        return destination
    except Exception:
        if backup_connection is not None:
            backup_connection.close()
        if source_connection is not None:
            source_connection.close()
        destination.unlink(missing_ok=True)
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(os.getenv("ROCKS_DATA_DIR", ROOT / "data")) / "rocks.sqlite3",
                        help="source database path (default: ROCKS_DATA_DIR/rocks.sqlite3)")
    parser.add_argument("--output-dir", type=Path, default=Path(os.getenv("ROCKS_BACKUP_DIR", ROOT / "backups")),
                        help="private backup directory (default: ROCKS_BACKUP_DIR or ./backups)")
    parser.add_argument("--keep", type=int, default=7, help="retain this many newest rocks-*.sqlite3 backups (default: 7)")
    args = parser.parse_args()
    if args.keep < 1:
        parser.error("--keep must be at least 1")
    now = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    destination = args.output_dir / f"rocks-{now}.sqlite3"
    verify_rocks_schema(args.source)
    created = backup_database(args.source, destination)
    backups = sorted(args.output_dir.glob("rocks-*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[args.keep:]:
        old.unlink(missing_ok=True)
    print(f"Verified ROCKS backup created: {created}")
    print(f"Integrity check: ok; retention: {args.keep}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
